#include "constants/abilities.h"
#include "constants/species.h"
#include "constants/sndseq.h"
#include "constants/items.h"
#include "constants/pokemon.h"
#include "constants/std_script.h"
	.include "macros.inc"
	.include "overlay_02.inc"
	.include "global.inc"

	.text

	thumb_func_start ov02_02248728
ov02_02248728: ; 0x02248728
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	add r6, r2, #0
	ldr r0, [sp, #0x1c]
	add r7, r3, #0
	strb r6, [r5]
	ldr r4, [sp, #0x18]
	strb r7, [r5, #1]
	strb r4, [r5, #2]
	str r0, [sp, #0x1c]
	strb r0, [r5, #3]
	ldr r0, [sp, #0x20]
	mov r2, #4
	strb r0, [r5, #4]
	ldr r0, [sp, #0x24]
	strb r0, [r5, #5]
	ldr r0, [sp, #0x28]
	strb r0, [r5, #6]
	ldr r0, [sp, #0x2c]
	strb r0, [r5, #7]
	add r0, r1, #0
	add r1, r5, #0
	add r1, #0xc
	bl G2dRenderer_Init
	str r0, [r5, #8]
	add r0, r5, #0
	mov r2, #2
	add r0, #0xc
	mov r1, #0
	lsl r2, r2, #0x14
	bl G2dRenderer_SetSubSurfaceCoords
	add r0, r6, #0
	mov r1, #0
	mov r2, #4
	bl Create2DGfxResObjMan
	mov r1, #0x4d
	lsl r1, r1, #2
	str r0, [r5, r1]
	add r0, r7, #0
	mov r1, #1
	mov r2, #4
	bl Create2DGfxResObjMan
	mov r1, #0x4e
	lsl r1, r1, #2
	str r0, [r5, r1]
	add r0, r4, #0
	mov r1, #2
	mov r2, #4
	bl Create2DGfxResObjMan
	mov r1, #0x4f
	lsl r1, r1, #2
	str r0, [r5, r1]
	ldr r0, [sp, #0x1c]
	mov r1, #3
	mov r2, #4
	bl Create2DGfxResObjMan
	mov r1, #5
	lsl r1, r1, #6
	str r0, [r5, r1]
	mov r0, #4
	lsl r1, r6, #3
	bl ov02_0224B690
	mov r1, #0x51
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #4
	lsl r1, r7, #3
	bl ov02_0224B690
	mov r1, #0x52
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #4
	lsl r1, r4, #3
	bl ov02_0224B690
	mov r1, #0x53
	lsl r1, r1, #2
	str r0, [r5, r1]
	ldr r1, [sp, #0x1c]
	mov r0, #4
	lsl r1, r1, #3
	bl ov02_0224B690
	mov r1, #0x15
	lsl r1, r1, #4
	str r0, [r5, r1]
	mov r1, #0
	cmp r6, #0
	ble _02248804
	ble _02248804
	ldr r0, [sp, #0x20]
	add r2, r1, #0
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
_022487F4:
	mov r3, #0x51
	lsl r3, r3, #2
	ldr r3, [r5, r3]
	add r1, r1, #1
	strh r0, [r3, r2]
	add r2, #8
	cmp r1, r6
	blt _022487F4
_02248804:
	mov r3, #0
	cmp r7, #0
	ble _02248824
	ble _02248824
	ldr r0, [sp, #0x24]
	mov r6, #0x52
	lsl r0, r0, #0x10
	add r2, r3, #0
	asr r1, r0, #0x10
	lsl r6, r6, #2
_02248818:
	ldr r0, [r5, r6]
	add r3, r3, #1
	strh r1, [r0, r2]
	add r2, #8
	cmp r3, r7
	blt _02248818
_02248824:
	mov r1, #0
	cmp r4, #0
	ble _02248844
	ble _02248844
	ldr r2, [sp, #0x28]
	add r0, r1, #0
	lsl r2, r2, #0x10
	asr r6, r2, #0x10
	mov r2, #0x53
	lsl r2, r2, #2
_02248838:
	ldr r3, [r5, r2]
	add r1, r1, #1
	strh r6, [r3, r0]
	add r0, #8
	cmp r1, r4
	blt _02248838
_02248844:
	ldr r0, [sp, #0x1c]
	mov r1, #0
	cmp r0, #0
	ble _02248868
	ble _02248868
	ldr r2, [sp, #0x2c]
	mov r3, #0x15
	lsl r2, r2, #0x10
	add r0, r1, #0
	asr r4, r2, #0x10
	lsl r3, r3, #4
_0224885A:
	ldr r2, [r5, r3]
	add r1, r1, #1
	strh r4, [r2, r0]
	ldr r2, [sp, #0x1c]
	add r0, #8
	cmp r1, r2
	blt _0224885A
_02248868:
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_02248728

	thumb_func_start ov02_0224886C
ov02_0224886C: ; 0x0224886C
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	ldrb r0, [r5]
	mov r6, #0
	cmp r0, #0
	ble _0224889C
	add r4, r6, #0
	mov r7, #4
_0224887C:
	mov r0, #0x51
	lsl r0, r0, #2
	ldr r1, [r5, r0]
	ldrsb r2, [r5, r7]
	add r0, r1, r4
	ldrsh r1, [r1, r4]
	cmp r2, r1
	beq _02248892
	ldr r0, [r0, #4]
	bl SpriteTransfer_DeleteCharTransferTask
_02248892:
	ldrb r0, [r5]
	add r6, r6, #1
	add r4, #8
	cmp r6, r0
	blt _0224887C
_0224889C:
	ldrb r0, [r5, #1]
	mov r6, #0
	cmp r0, #0
	ble _022488C8
	add r4, r6, #0
	mov r7, #5
_022488A8:
	mov r0, #0x52
	lsl r0, r0, #2
	ldr r1, [r5, r0]
	ldrsb r2, [r5, r7]
	add r0, r1, r4
	ldrsh r1, [r1, r4]
	cmp r2, r1
	beq _022488BE
	ldr r0, [r0, #4]
	bl SpriteTransfer_DeletePlttTransferTask
_022488BE:
	ldrb r0, [r5, #1]
	add r6, r6, #1
	add r4, #8
	cmp r6, r0
	blt _022488A8
_022488C8:
	ldrb r0, [r5, #2]
	mov r6, #0
	cmp r0, #0
	ble _022488F4
	add r4, r6, #0
	mov r7, #6
_022488D4:
	mov r0, #0x53
	lsl r0, r0, #2
	ldr r1, [r5, r0]
	ldrsb r2, [r5, r7]
	add r0, r1, r4
	ldrsh r1, [r1, r4]
	cmp r2, r1
	beq _022488EA
	ldr r0, [r0, #4]
	bl sub_0200A740
_022488EA:
	ldrb r0, [r5, #2]
	add r6, r6, #1
	add r4, #8
	cmp r6, r0
	blt _022488D4
_022488F4:
	ldrb r0, [r5, #3]
	mov r6, #0
	cmp r0, #0
	ble _02248920
	add r4, r6, #0
	mov r7, #7
_02248900:
	mov r0, #0x15
	lsl r0, r0, #4
	ldr r1, [r5, r0]
	ldrsb r2, [r5, r7]
	add r0, r1, r4
	ldrsh r1, [r1, r4]
	cmp r2, r1
	beq _02248916
	ldr r0, [r0, #4]
	bl sub_0200A740
_02248916:
	ldrb r0, [r5, #3]
	add r6, r6, #1
	add r4, #8
	cmp r6, r0
	blt _02248900
_02248920:
	mov r0, #0x4d
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #0x4e
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #0x4f
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #5
	lsl r0, r0, #6
	ldr r0, [r5, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #0x51
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl Heap_Free
	mov r0, #0x52
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl Heap_Free
	mov r0, #0x53
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl Heap_Free
	mov r0, #0x15
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	bl Heap_Free
	ldr r0, [r5, #8]
	bl SpriteList_DeleteAllSprites
	ldr r0, [r5, #8]
	bl SpriteList_Delete
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224886C

	thumb_func_start ov02_02248980
ov02_02248980: ; 0x02248980
	push {r4, r5, r6, r7, lr}
	sub sp, #0x14
	add r6, r0, #0
	ldrb r5, [r6]
	str r2, [sp, #0x10]
	str r1, [sp, #0xc]
	add r7, r3, #0
	mov r2, #0
	cmp r5, #0
	ble _022489E6
	mov r0, #0x51
	lsl r0, r0, #2
	ldr r3, [r6, r0]
	mov r0, #4
	ldrsb r4, [r6, r0]
	mov ip, r3
	add r0, r2, #0
_022489A2:
	ldrsh r1, [r3, r0]
	cmp r4, r1
	bne _022489DE
	lsl r4, r2, #3
	mov r0, ip
	strh r7, [r0, r4]
	mov r0, #0x51
	lsl r0, r0, #2
	ldr r1, [r6, r0]
	mov r3, #0
	add r1, r1, r4
	strh r3, [r1, #2]
	str r7, [sp]
	mov r1, #1
	str r1, [sp, #4]
	mov r1, #4
	str r1, [sp, #8]
	sub r0, #0x10
	ldr r0, [r6, r0]
	ldr r1, [sp, #0xc]
	ldr r2, [sp, #0x10]
	bl AddCharResObjFromOpenNarc
	mov r1, #0x51
	lsl r1, r1, #2
	ldr r1, [r6, r1]
	add sp, #0x14
	add r1, r1, r4
	str r0, [r1, #4]
	pop {r4, r5, r6, r7, pc}
_022489DE:
	add r2, r2, #1
	add r3, #8
	cmp r2, r5
	blt _022489A2
_022489E6:
	bl GF_AssertFail
	add sp, #0x14
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_02248980

	thumb_func_start ov02_022489F0
ov02_022489F0: ; 0x022489F0
	push {r4, r5, r6, lr}
	ldrb r3, [r0]
	mov r2, #0
	cmp r3, #0
	ble _02248A1E
	mov r4, #0x51
	lsl r4, r4, #2
	ldr r0, [r0, r4]
	add r4, r2, #0
	add r6, r0, #0
_02248A04:
	ldrsh r5, [r6, r4]
	cmp r1, r5
	bne _02248A16
	lsl r1, r2, #3
	add r0, r0, r1
	ldr r0, [r0, #4]
	bl SpriteTransfer_CreateCharTransferTask_AllocAtEnd
	pop {r4, r5, r6, pc}
_02248A16:
	add r2, r2, #1
	add r6, #8
	cmp r2, r3
	blt _02248A04
_02248A1E:
	bl GF_AssertFail
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_022489F0

	thumb_func_start ov02_02248A24
ov02_02248A24: ; 0x02248A24
	push {r4, r5, r6, lr}
	ldrb r3, [r0]
	mov r2, #0
	cmp r3, #0
	ble _02248A52
	mov r4, #0x51
	lsl r4, r4, #2
	ldr r0, [r0, r4]
	add r4, r2, #0
	add r6, r0, #0
_02248A38:
	ldrsh r5, [r6, r4]
	cmp r1, r5
	bne _02248A4A
	lsl r1, r2, #3
	add r0, r0, r1
	ldr r0, [r0, #4]
	bl sub_0200A740
	pop {r4, r5, r6, pc}
_02248A4A:
	add r2, r2, #1
	add r6, #8
	cmp r2, r3
	blt _02248A38
_02248A52:
	bl GF_AssertFail
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_02248A24

	thumb_func_start ov02_02248A58
ov02_02248A58: ; 0x02248A58
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x18
	add r6, r0, #0
	ldrb r5, [r6]
	str r2, [sp, #0x14]
	str r1, [sp, #0x10]
	add r7, r3, #0
	mov r2, #0
	cmp r5, #0
	ble _02248AC0
	mov r0, #0x52
	lsl r0, r0, #2
	ldr r3, [r6, r0]
	mov r0, #5
	ldrsb r4, [r6, r0]
	mov ip, r3
	add r0, r2, #0
_02248A7A:
	ldrsh r1, [r3, r0]
	cmp r4, r1
	bne _02248AB8
	lsl r4, r2, #3
	mov r0, ip
	strh r7, [r0, r4]
	mov r0, #0x52
	lsl r0, r0, #2
	ldr r1, [r6, r0]
	mov r3, #0
	add r1, r1, r4
	strh r3, [r1, #2]
	str r7, [sp]
	mov r1, #1
	str r1, [sp, #4]
	str r1, [sp, #8]
	mov r1, #4
	str r1, [sp, #0xc]
	sub r0, #0x10
	ldr r0, [r6, r0]
	ldr r1, [sp, #0x10]
	ldr r2, [sp, #0x14]
	bl AddPlttResObjFromOpenNarc
	mov r1, #0x52
	lsl r1, r1, #2
	ldr r1, [r6, r1]
	add sp, #0x18
	add r1, r1, r4
	str r0, [r1, #4]
	pop {r3, r4, r5, r6, r7, pc}
_02248AB8:
	add r2, r2, #1
	add r3, #8
	cmp r2, r5
	blt _02248A7A
_02248AC0:
	bl GF_AssertFail
	add sp, #0x18
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_02248A58

	thumb_func_start ov02_02248AC8
ov02_02248AC8: ; 0x02248AC8
	push {r4, r5, r6, lr}
	ldrb r3, [r0, #1]
	mov r2, #0
	cmp r3, #0
	ble _02248AF6
	mov r4, #0x52
	lsl r4, r4, #2
	ldr r0, [r0, r4]
	add r4, r2, #0
	add r6, r0, #0
_02248ADC:
	ldrsh r5, [r6, r4]
	cmp r1, r5
	bne _02248AEE
	lsl r1, r2, #3
	add r0, r0, r1
	ldr r0, [r0, #4]
	bl SpriteTransfer_CreatePlttTransferTask
	pop {r4, r5, r6, pc}
_02248AEE:
	add r2, r2, #1
	add r6, #8
	cmp r2, r3
	blt _02248ADC
_02248AF6:
	bl GF_AssertFail
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_02248AC8

	thumb_func_start ov02_02248AFC
ov02_02248AFC: ; 0x02248AFC
	push {r4, r5, r6, lr}
	ldrb r3, [r0, #1]
	mov r2, #0
	cmp r3, #0
	ble _02248B2A
	mov r4, #0x52
	lsl r4, r4, #2
	ldr r0, [r0, r4]
	add r4, r2, #0
	add r6, r0, #0
_02248B10:
	ldrsh r5, [r6, r4]
	cmp r1, r5
	bne _02248B22
	lsl r1, r2, #3
	add r0, r0, r1
	ldr r0, [r0, #4]
	bl sub_0200A740
	pop {r4, r5, r6, pc}
_02248B22:
	add r2, r2, #1
	add r6, #8
	cmp r2, r3
	blt _02248B10
_02248B2A:
	bl GF_AssertFail
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_02248AFC

	thumb_func_start ov02_02248B30
ov02_02248B30: ; 0x02248B30
	push {r4, r5, r6, r7, lr}
	sub sp, #0x14
	add r6, r0, #0
	ldrb r5, [r6]
	str r2, [sp, #0x10]
	str r1, [sp, #0xc]
	add r7, r3, #0
	mov r2, #0
	cmp r5, #0
	ble _02248B96
	mov r0, #0x53
	lsl r0, r0, #2
	ldr r3, [r6, r0]
	mov r0, #6
	ldrsb r4, [r6, r0]
	mov ip, r3
	add r0, r2, #0
_02248B52:
	ldrsh r1, [r3, r0]
	cmp r4, r1
	bne _02248B8E
	lsl r4, r2, #3
	mov r0, ip
	strh r7, [r0, r4]
	mov r0, #0x53
	lsl r0, r0, #2
	ldr r1, [r6, r0]
	mov r3, #0
	add r1, r1, r4
	strh r3, [r1, #2]
	str r7, [sp]
	mov r1, #2
	str r1, [sp, #4]
	mov r1, #4
	str r1, [sp, #8]
	sub r0, #0x10
	ldr r0, [r6, r0]
	ldr r1, [sp, #0xc]
	ldr r2, [sp, #0x10]
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x53
	lsl r1, r1, #2
	ldr r1, [r6, r1]
	add sp, #0x14
	add r1, r1, r4
	str r0, [r1, #4]
	pop {r4, r5, r6, r7, pc}
_02248B8E:
	add r2, r2, #1
	add r3, #8
	cmp r2, r5
	blt _02248B52
_02248B96:
	bl GF_AssertFail
	add sp, #0x14
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_02248B30

	thumb_func_start ov02_02248BA0
ov02_02248BA0: ; 0x02248BA0
	push {r4, r5, r6, r7, lr}
	sub sp, #0x14
	add r6, r0, #0
	ldrb r5, [r6]
	str r2, [sp, #0x10]
	str r1, [sp, #0xc]
	add r7, r3, #0
	mov r2, #0
	cmp r5, #0
	ble _02248C06
	mov r0, #0x15
	lsl r0, r0, #4
	ldr r3, [r6, r0]
	mov r0, #7
	ldrsb r4, [r6, r0]
	mov ip, r3
	add r0, r2, #0
_02248BC2:
	ldrsh r1, [r3, r0]
	cmp r4, r1
	bne _02248BFE
	lsl r4, r2, #3
	mov r0, ip
	strh r7, [r0, r4]
	mov r0, #0x15
	lsl r0, r0, #4
	ldr r1, [r6, r0]
	mov r3, #0
	add r1, r1, r4
	strh r3, [r1, #2]
	str r7, [sp]
	mov r1, #3
	str r1, [sp, #4]
	mov r1, #4
	str r1, [sp, #8]
	sub r0, #0x10
	ldr r0, [r6, r0]
	ldr r1, [sp, #0xc]
	ldr r2, [sp, #0x10]
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x15
	lsl r1, r1, #4
	ldr r1, [r6, r1]
	add sp, #0x14
	add r1, r1, r4
	str r0, [r1, #4]
	pop {r4, r5, r6, r7, pc}
_02248BFE:
	add r2, r2, #1
	add r3, #8
	cmp r2, r5
	blt _02248BC2
_02248C06:
	bl GF_AssertFail
	add sp, #0x14
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_02248BA0

	thumb_func_start ov02_02248C10
ov02_02248C10: ; 0x02248C10
	push {r4, r5, r6, lr}
	sub sp, #0x70
	add r5, r0, #0
	add r4, r1, #0
	add r1, r2, #0
	mov r0, #7
	add r2, r3, #0
	ldrsb r3, [r5, r0]
	ldr r6, [sp, #0x84]
	cmp r6, r3
	bne _02248C2A
	sub r0, #8
	str r0, [sp, #0x84]
_02248C2A:
	ldr r0, [sp, #0x84]
	mov r3, #0
	str r0, [sp]
	mov r0, #0
	mvn r0, r0
	str r0, [sp, #4]
	str r0, [sp, #8]
	ldr r0, [sp, #0x88]
	str r3, [sp, #0xc]
	str r0, [sp, #0x10]
	mov r0, #0x4d
	lsl r0, r0, #2
	ldr r6, [r5, r0]
	str r6, [sp, #0x14]
	add r6, r0, #4
	ldr r6, [r5, r6]
	str r6, [sp, #0x18]
	add r6, r0, #0
	add r6, #8
	ldr r6, [r5, r6]
	add r0, #0xc
	str r6, [sp, #0x1c]
	ldr r0, [r5, r0]
	str r0, [sp, #0x20]
	str r3, [sp, #0x24]
	str r3, [sp, #0x28]
	ldr r3, [sp, #0x80]
	add r0, sp, #0x4c
	bl CreateSpriteResourcesHeader
	ldr r0, [r5, #8]
	add r2, sp, #0x34
	str r0, [sp, #0x2c]
	add r0, sp, #0x4c
	str r0, [sp, #0x30]
	ldmia r4!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r4]
	str r0, [r2]
	ldr r0, [sp, #0x8c]
	str r0, [sp, #0x40]
	mov r0, #1
	str r0, [sp, #0x44]
	mov r0, #4
	str r0, [sp, #0x48]
	add r0, sp, #0x2c
	bl Sprite_Create
	add r4, r0, #0
	bne _02248C92
	bl GF_AssertFail
_02248C92:
	add r0, r4, #0
	add sp, #0x70
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_02248C10

	thumb_func_start ov02_02248C98
ov02_02248C98: ; 0x02248C98
	push {r4, lr}
	add r4, r1, #0
	bl Sprite_GetMatrixPtr
	add r2, r0, #0
	ldmia r2!, {r0, r1}
	stmia r4!, {r0, r1}
	ldr r0, [r2]
	str r0, [r4]
	pop {r4, pc}
	thumb_func_end ov02_02248C98

	thumb_func_start ov02_02248CAC
ov02_02248CAC: ; 0x02248CAC
	push {r3, r4, r5, r6, lr}
	sub sp, #0x34
	add r4, r0, #0
	mov r2, #0
	add r0, sp, #0x1c
	str r2, [r0]
	str r2, [r0, #4]
	add r3, sp, #0x28
	str r2, [r3]
	str r2, [r3, #4]
	ldr r6, _02248D14 ; =ov02_02253360
	str r2, [r0, #8]
	ldmia r6!, {r0, r1}
	add r5, sp, #0x10
	stmia r5!, {r0, r1}
	ldr r0, [r6]
	str r2, [r3, #8]
	str r0, [r5]
	add r1, r3, #0
	str r2, [sp]
	mov r0, #2
	str r0, [sp, #4]
	str r2, [sp, #8]
	mov r0, #0x84
	str r0, [sp, #0xc]
	add r0, r4, #0
	add r3, r2, #0
	bl ov02_02248C10
	add r4, r0, #0
	mov r1, #2
	bl Sprite_SetAffineOverwriteMode
	add r0, r4, #0
	add r1, sp, #0x1c
	bl Sprite_SetAffineMatrix
	add r0, r4, #0
	add r1, sp, #0x10
	bl Sprite_SetAffineScale
	mov r0, #0
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	add r0, r4, #0
	add sp, #0x34
	pop {r3, r4, r5, r6, pc}
	nop
_02248D14: .word ov02_02253360
	thumb_func_end ov02_02248CAC

	thumb_func_start ov02_02248D18
ov02_02248D18: ; 0x02248D18
	push {r3, r4, lr}
	sub sp, #0x1c
	mov r3, #0
	add r2, sp, #0x10
	str r3, [r2]
	str r3, [r2, #4]
	str r3, [r2, #8]
	cmp r1, #1
	bne _02248D2C
	mov r3, #1
_02248D2C:
	mov r2, #2
	str r2, [sp]
	mov r1, #1
	str r1, [sp, #4]
	mov r1, #0
	str r1, [sp, #8]
	mov r1, #0x83
	str r1, [sp, #0xc]
	add r1, sp, #0x10
	bl ov02_02248C10
	add r4, r0, #0
	mov r1, #0
	bl Sprite_SetDrawFlag
	add r0, r4, #0
	mov r1, #6
	bl Sprite_SetAnimCtrlSeq
	add r0, r4, #0
	add sp, #0x1c
	pop {r3, r4, pc}
	thumb_func_end ov02_02248D18

	thumb_func_start ov02_02248D58
ov02_02248D58: ; 0x02248D58
	push {r4, r5, lr}
	sub sp, #0x24
	add r5, sp, #0x18
	mov r4, #0
	str r4, [r5]
	str r4, [r5, #4]
	str r0, [sp, #0xc]
	str r2, [sp, #0x14]
	str r3, [sp, #0x10]
	str r4, [r5, #8]
	str r1, [sp, #8]
	add r0, sp, #8
	str r0, [sp]
	mov r0, #0x82
	str r0, [sp, #4]
	add r0, r1, #0
	ldr r1, _02248D88 ; =ov02_02253454
	add r2, r5, #0
	add r3, r4, #0
	bl sub_02068B0C
	add sp, #0x24
	pop {r4, r5, pc}
	nop
_02248D88: .word ov02_02253454
	thumb_func_end ov02_02248D58

	thumb_func_start ov02_02248D8C
ov02_02248D8C: ; 0x02248D8C
	push {r3, lr}
	bl sub_02068D74
	ldrb r0, [r0, #2]
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_02248D8C

	thumb_func_start ov02_02248D98
ov02_02248D98: ; 0x02248D98
	push {r4, lr}
	add r4, r1, #0
	bl sub_02068D98
	add r2, r4, #0
	add r3, r0, #0
	add r2, #0x58
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r4, #0x64]
	bl ov02_02248CAC
	str r0, [r4, #0x68]
	mov r0, #1
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02248D98

	thumb_func_start ov02_02248DBC
ov02_02248DBC: ; 0x02248DBC
	push {r3, r4, r5, lr}
	add r5, r0, #0
	bl sub_02068D74
	add r4, r0, #0
	ldr r0, [r4, #0x6c]
	cmp r0, #0
	beq _02248DD0
	bl sub_02068B48
_02248DD0:
	ldr r0, [r4, #0x70]
	cmp r0, #0
	beq _02248DDA
	bl ov01_021FCD78
_02248DDA:
	add r0, r5, #0
	bl sub_02068B48
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_02248DBC

	thumb_func_start ov02_02248DE4
ov02_02248DE4: ; 0x02248DE4
	ldr r3, _02248DEC ; =Sprite_Delete
	ldr r0, [r1, #0x68]
	bx r3
	nop
_02248DEC: .word Sprite_Delete
	thumb_func_end ov02_02248DE4

	thumb_func_start ov02_02248DF0
ov02_02248DF0: ; 0x02248DF0
	push {r3, r4, r5, lr}
	add r5, r1, #0
	ldrb r0, [r5]
	lsl r1, r0, #2
	ldr r0, _02248E0C ; =ov02_02253320
	ldr r4, [r0, r1]
_02248DFC:
	ldrb r1, [r5, #1]
	add r0, r5, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	blx r1
	cmp r0, #1
	beq _02248DFC
	pop {r3, r4, r5, pc}
	.balign 4, 0
_02248E0C: .word ov02_02253320
	thumb_func_end ov02_02248DF0

	thumb_func_start ov02_02248E10
ov02_02248E10: ; 0x02248E10
	push {r3, lr}
	mov r1, #0
	strb r1, [r0, #2]
	ldr r0, [r0, #0x68]
	bl Sprite_SetDrawFlag
	mov r0, #0
	pop {r3, pc}
	thumb_func_end ov02_02248E10

	thumb_func_start ov02_02248E20
ov02_02248E20: ; 0x02248E20
	push {r4, r5, r6, lr}
	sub sp, #0x30
	ldr r4, _02248F74 ; =ov02_0225339C
	add r2, r0, #0
	ldmia r4!, {r0, r1}
	add r3, sp, #0x24
	stmia r3!, {r0, r1}
	ldr r0, [r4]
	ldr r4, _02248F78 ; =ov02_022533CC
	str r0, [r3]
	ldmia r4!, {r0, r1}
	add r3, sp, #0x18
	stmia r3!, {r0, r1}
	ldr r0, [r4]
	str r0, [r3]
	add r0, r2, #0
	bl sub_02068D74
	add r4, r0, #0
	mov r3, #1
	add r5, r4, #0
	strb r3, [r4]
	mov r2, #0
	strb r2, [r4, #2]
	strb r2, [r4, #1]
	str r2, [r4, #4]
	add r6, sp, #0x24
	ldmia r6!, {r0, r1}
	add r5, #8
	stmia r5!, {r0, r1}
	ldr r0, [r6]
	str r0, [r5]
	str r2, [r4, #0x14]
	str r2, [r4, #0x18]
	str r2, [r4, #0x1c]
	ldr r0, _02248F7C ; =0x0015E000
	add r2, r4, #0
	add r5, sp, #0x18
	str r0, [r4, #0x38]
	ldmia r5!, {r0, r1}
	add r2, #0x2c
	stmia r2!, {r0, r1}
	ldr r0, [r5]
	str r0, [r2]
	lsl r0, r3, #0xa
	str r0, [r4, #0x50]
	mov r0, #0x2d
	lsl r0, r0, #0xc
	str r0, [r4, #0x40]
	mov r0, #3
	lsl r0, r0, #0x12
	str r0, [r4, #0x48]
	lsl r0, r3, #0x11
	str r0, [r4, #0x4c]
	mov r0, #0x2d
	bl GF_CosDeg
	ldr r2, [r4, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r4, #0x14]
	ldr r1, [r4, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_SinDeg
	ldr r2, [r4, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r4, #0x18]
	ldr r1, [r4, #8]
	ldr r0, [r4, #0x14]
	add r0, r1, r0
	str r0, [sp, #0x24]
	ldr r1, [r4, #0xc]
	ldr r0, [r4, #0x18]
	add r0, r1, r0
	str r0, [sp, #0x28]
	ldr r0, [r4, #0x68]
	add r1, sp, #0x24
	bl Sprite_SetMatrix
	ldr r0, [r4, #0x68]
	add r1, sp, #0x18
	bl Sprite_SetAffineScale
	ldr r1, [r4, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	ldr r0, [r4, #0x68]
	bl Sprite_SetAffineZRotation
	ldr r0, [r4, #0x68]
	mov r1, #0x84
	bl Sprite_SetDrawPriority
	ldr r0, [r4, #0x68]
	mov r1, #1
	bl Sprite_SetDrawFlag
	ldr r0, [r4, #0x58]
	ldr r1, [r4, #0x60]
	bl ov02_0224B298
	str r0, [r4, #0x6c]
	ldr r0, [r4, #0x5c]
	mov r1, #4
	bl ov01_021FCD2C
	ldr r2, _02248F80 ; =0xFFF88000
	mov r1, #1
	mov r3, #0xc
	str r0, [r4, #0x70]
	bl ov01_021FCD8C
	add r1, sp, #0xc
	mov r0, #0
	str r0, [r1]
	str r0, [r1, #4]
	ldr r3, _02248F84 ; =ov02_022533A8
	str r0, [r1, #8]
	ldmia r3!, {r0, r1}
	add r2, sp, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	mov r1, #2
	str r0, [r2]
	ldr r4, [r4, #0x60]
	add r0, r4, #0
	bl Sprite_SetAffineOverwriteMode
	add r0, r4, #0
	add r1, sp, #0xc
	bl Sprite_SetAffineMatrix
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetAffineScale
	mov r0, #0
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	add r0, r4, #0
	mov r1, #2
	bl Sprite_SetAnimCtrlSeq
	bl ov02_022493FC
	add sp, #0x30
	pop {r4, r5, r6, pc}
	nop
_02248F74: .word ov02_0225339C
_02248F78: .word ov02_022533CC
_02248F7C: .word 0x0015E000
_02248F80: .word 0xFFF88000
_02248F84: .word ov02_022533A8
	thumb_func_end ov02_02248E20

	thumb_func_start ov02_02248F88
ov02_02248F88: ; 0x02248F88
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	add r5, r0, #0
	ldr r1, [r5, #0x48]
	ldr r0, [r5, #0x4c]
	ldr r6, [r5, #0x68]
	ldr r4, [r5, #0x60]
	sub r0, r1, r0
	str r0, [r5, #0x48]
	bpl _02248FA0
	mov r0, #0
	str r0, [r5, #0x48]
_02248FA0:
	mov r0, #2
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0xa
	cmp r1, r0
	ble _02248FB2
	mov r0, #7
	lsl r0, r0, #0xa
	sub r0, r1, r0
	str r0, [r5, #0x4c]
_02248FB2:
	mov r0, #1
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0xc
	cmp r1, r0
	bge _02248FBE
	str r0, [r5, #0x4c]
_02248FBE:
	mov r0, #0x2d
	bl GF_CosDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x14]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_SinDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x18]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r0, r0, #0xc
	cmp r0, #0x5a
	bge _02249006
	mov r0, #1
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [r5, #0x40]
_02249006:
	ldr r1, [r5, #0x2c]
	ldr r0, [r5, #0x50]
	sub r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xc
	str r1, [r5, #0x2c]
	cmp r1, r0
	bge _02249018
	str r0, [r5, #0x2c]
_02249018:
	ldr r1, [r5, #0x30]
	ldr r0, [r5, #0x50]
	sub r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xc
	str r1, [r5, #0x30]
	cmp r1, r0
	bge _0224902A
	str r0, [r5, #0x30]
_0224902A:
	add r1, r5, #0
	add r0, r6, #0
	add r1, #0x2c
	bl Sprite_SetAffineScale
	add r1, r5, #0
	add r0, r4, #0
	add r1, #0x2c
	bl Sprite_SetAffineScale
	ldr r1, [r5, #8]
	ldr r0, [r5, #0x14]
	add r0, r1, r0
	str r0, [sp]
	ldr r1, [r5, #0xc]
	ldr r0, [r5, #0x18]
	add r0, r1, r0
	str r0, [sp, #4]
	add r0, r6, #0
	add r1, sp, #0
	bl Sprite_SetMatrix
	mov r0, #0x12
	ldr r1, [sp, #4]
	lsl r0, r0, #0xc
	sub r0, r1, r0
	str r0, [sp, #4]
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r0, [r5, #0x48]
	cmp r0, #0
	bne _0224907A
	mov r0, #0
	str r0, [r5, #4]
	ldrb r0, [r5, #1]
	add r0, r0, #1
	strb r0, [r5, #1]
	b _02249080
_0224907A:
	ldr r0, [r5, #4]
	add r0, r0, #1
	str r0, [r5, #4]
_02249080:
	mov r0, #0
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_02248F88

	thumb_func_start ov02_02249088
ov02_02249088: ; 0x02249088
	push {r4, lr}
	add r4, r0, #0
	ldr r0, [r4, #0x6c]
	bl ov02_0224B314
	ldr r0, [r4, #0x70]
	mov r1, #2
	mov r2, #0
	mov r3, #0xc
	bl ov01_021FCD8C
	mov r0, #1
	lsl r0, r0, #0xa
	str r0, [r4, #0x50]
	lsl r0, r0, #9
	str r0, [r4, #0x40]
	mov r0, #0
	str r0, [r4, #0x48]
	mov r0, #6
	lsl r0, r0, #0xa
	str r0, [r4, #0x4c]
	ldrb r0, [r4, #1]
	add r0, r0, #1
	strb r0, [r4, #1]
	mov r0, #1
	pop {r4, pc}
	thumb_func_end ov02_02249088

	thumb_func_start ov02_022490BC
ov02_022490BC: ; 0x022490BC
	push {r4, r5, lr}
	sub sp, #0xc
	add r5, r0, #0
	ldr r1, [r5, #0x48]
	ldr r0, [r5, #0x4c]
	ldr r4, [r5, #0x68]
	add r0, r1, r0
	str r0, [r5, #0x48]
	mov r0, #1
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0xc
	add r2, r1, r0
	lsl r1, r0, #4
	str r2, [r5, #0x4c]
	cmp r2, r1
	ble _022490E0
	lsl r0, r0, #4
	str r0, [r5, #0x4c]
_022490E0:
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_CosDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x14]
	mov r0, #0x80
	bl GF_SinDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x18]
	mov r0, #0xa
	ldr r1, [r5, #0x40]
	lsl r0, r0, #0x10
	cmp r1, r0
	bge _02249124
	mov r0, #1
	lsl r0, r0, #0xc
	add r0, r1, r0
	str r0, [r5, #0x40]
_02249124:
	mov r0, #2
	ldr r1, [r5, #0x38]
	lsl r0, r0, #0xc
	add r1, r1, r0
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	str r1, [r5, #0x38]
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	ldr r1, [r5, #0x2c]
	ldr r0, [r5, #0x50]
	add r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xc
	str r1, [r5, #0x2c]
	cmp r1, r0
	ble _02249156
	str r0, [r5, #0x2c]
_02249156:
	ldr r1, [r5, #0x30]
	ldr r0, [r5, #0x50]
	add r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xc
	str r1, [r5, #0x30]
	cmp r1, r0
	ble _02249168
	str r0, [r5, #0x30]
_02249168:
	add r1, r5, #0
	add r0, r4, #0
	add r1, #0x2c
	bl Sprite_SetAffineScale
	ldr r1, [r5, #8]
	ldr r0, [r5, #0x14]
	add r0, r1, r0
	str r0, [sp]
	ldr r1, [r5, #0xc]
	ldr r0, [r5, #0x18]
	sub r0, r1, r0
	str r0, [sp, #4]
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r1, [sp, #4]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r1, r0, #0xc
	mov r0, #0xf
	mvn r0, r0
	cmp r1, r0
	bgt _022491A2
	ldrb r0, [r5, #1]
	add r0, r0, #1
	strb r0, [r5, #1]
_022491A2:
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	thumb_func_end ov02_022490BC

	thumb_func_start ov02_022491A8
ov02_022491A8: ; 0x022491A8
	push {r4, lr}
	add r4, r0, #0
	ldr r0, [r4, #0x68]
	mov r1, #0
	bl Sprite_SetDrawFlag
	ldr r0, [r4, #0x60]
	mov r1, #1
	bl Sprite_SetAnimCtrlSeq
	mov r0, #0
	str r0, [r4, #4]
	ldrb r0, [r4, #1]
	add r0, r0, #1
	strb r0, [r4, #1]
	mov r0, #1
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_022491A8

	thumb_func_start ov02_022491CC
ov02_022491CC: ; 0x022491CC
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x18
	add r4, r0, #0
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
	cmp r0, #0x14
	bge _022491E2
	add sp, #0x18
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_022491E2:
	ldr r3, _02249284 ; =ov02_022533D8
	add r2, sp, #0xc
	ldmia r3!, {r0, r1}
	add r6, r2, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	ldr r3, _02249288 ; =ov02_022533B4
	str r0, [r2]
	add r2, sp, #0
	ldmia r3!, {r0, r1}
	add r5, r2, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	mov r7, #0
	str r0, [r2]
	add r2, r4, #0
	str r7, [r4, #4]
	add r3, r6, #0
	ldmia r3!, {r0, r1}
	add r2, #8
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	str r7, [r4, #0x14]
	str r7, [r4, #0x18]
	str r7, [r4, #0x1c]
	str r7, [r4, #0x38]
	add r2, r4, #0
	ldmia r5!, {r0, r1}
	add r2, #0x2c
	stmia r2!, {r0, r1}
	ldr r0, [r5]
	mov r1, #2
	str r0, [r2]
	lsl r1, r1, #8
	ldr r0, _0224928C ; =0x0013B000
	str r1, [r4, #0x50]
	str r0, [r4, #0x40]
	lsl r0, r1, #0xa
	str r0, [r4, #0x48]
	lsl r0, r1, #4
	str r0, [r4, #0x4c]
	ldr r0, [r4, #0x68]
	add r1, r6, #0
	bl Sprite_SetMatrix
	ldr r0, [r4, #0x68]
	add r1, sp, #0
	bl Sprite_SetAffineScale
	ldr r1, [r4, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	ldr r0, [r4, #0x68]
	bl Sprite_SetAffineZRotation
	ldr r0, [r4, #0x68]
	mov r1, #1
	bl Sprite_SetDrawFlag
	ldr r0, [r4, #0x60]
	mov r1, #6
	bl Sprite_SetAnimCtrlSeq
	ldr r0, [r4, #0x60]
	mov r1, #1
	bl Sprite_SetAnimActiveFlag
	ldrb r0, [r4, #1]
	add r0, r0, #1
	strb r0, [r4, #1]
	mov r0, #1
	add sp, #0x18
	pop {r3, r4, r5, r6, r7, pc}
	nop
_02249284: .word ov02_022533D8
_02249288: .word ov02_022533B4
_0224928C: .word 0x0013B000
	thumb_func_end ov02_022491CC

	thumb_func_start ov02_02249290
ov02_02249290: ; 0x02249290
	push {r4, r5, lr}
	sub sp, #0xc
	add r5, r0, #0
	ldr r1, [r5, #0x48]
	ldr r0, [r5, #0x4c]
	ldr r4, [r5, #0x68]
	sub r0, r1, r0
	str r0, [r5, #0x48]
	mov r0, #1
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0x10
	cmp r1, r0
	bge _022492B0
	lsr r0, r0, #3
	add r0, r1, r0
	str r0, [r5, #0x4c]
_022492B0:
	ldr r0, [r5, #0x48]
	cmp r0, #0
	bge _022492BA
	mov r0, #0
	str r0, [r5, #0x48]
_022492BA:
	ldr r0, _02249398 ; =0x0000013B
	bl GF_CosDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x14]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_SinDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x18]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r0, r0, #0xc
	cmp r0, #0xb4
	bge _02249302
	mov r0, #1
	lsl r0, r0, #0xe
	sub r0, r1, r0
	str r0, [r5, #0x40]
_02249302:
	ldr r1, [r5, #0x2c]
	ldr r0, [r5, #0x50]
	sub r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xa
	str r1, [r5, #0x2c]
	cmp r1, r0
	bge _02249314
	str r0, [r5, #0x2c]
_02249314:
	ldr r1, [r5, #0x30]
	ldr r0, [r5, #0x50]
	sub r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xa
	str r1, [r5, #0x30]
	cmp r1, r0
	bge _02249326
	str r0, [r5, #0x30]
_02249326:
	add r1, r5, #0
	add r0, r4, #0
	add r1, #0x2c
	bl Sprite_SetAffineScale
	mov r0, #6
	ldr r1, [r5, #0x38]
	lsl r0, r0, #0xc
	add r1, r1, r0
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r0, r0, #0xc
	str r1, [r5, #0x38]
	cmp r0, #0x3c
	ble _0224934C
	mov r0, #0xf
	lsl r0, r0, #0xe
	str r0, [r5, #0x38]
_0224934C:
	ldr r1, [r5, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	ldr r1, [r5, #8]
	ldr r0, [r5, #0x14]
	add r0, r1, r0
	str r0, [sp]
	ldr r1, [r5, #0xc]
	ldr r0, [r5, #0x18]
	add r0, r1, r0
	str r0, [sp, #4]
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r0, [r5, #0x48]
	cmp r0, #0
	bgt _02249390
	add r0, r4, #0
	mov r1, #0
	bl Sprite_SetDrawFlag
	ldrb r0, [r5, #1]
	add r0, r0, #1
	strb r0, [r5, #1]
_02249390:
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	nop
_02249398: .word 0x0000013B
	thumb_func_end ov02_02249290

	thumb_func_start ov02_0224939C
ov02_0224939C: ; 0x0224939C
	push {r4, lr}
	add r4, r0, #0
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
	cmp r0, #8
	bne _022493BA
	ldr r0, [r4, #0x60]
	mov r1, #1
	bl Sprite_SetAnimCtrlSeq
	ldr r0, [r4, #0x5c]
	mov r1, #0
	bl ov02_02249444
_022493BA:
	ldr r0, [r4, #4]
	cmp r0, #0xa
	bne _022493C8
	ldr r0, [r4, #0x60]
	mov r1, #0
	bl Sprite_SetDrawFlag
_022493C8:
	ldr r0, [r4, #4]
	cmp r0, #0xf
	ble _022493E6
	ldr r0, [r4, #0x70]
	bl ov01_021FCD6C
	cmp r0, #1
	bne _022493E6
	mov r0, #0
	str r0, [r4, #4]
	ldrb r0, [r4, #1]
	add r0, r0, #1
	strb r0, [r4, #1]
	mov r0, #2
	strb r0, [r4, #2]
_022493E6:
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224939C

	thumb_func_start ov02_022493EC
ov02_022493EC: ; 0x022493EC
	mov r0, #0
	bx lr
	thumb_func_end ov02_022493EC

	thumb_func_start ov02_022493F0
ov02_022493F0: ; 0x022493F0
	ldr r3, _022493F8 ; =NARC_New
	mov r0, #0x5d
	mov r1, #4
	bx r3
	.balign 4, 0
_022493F8: .word NARC_New
	thumb_func_end ov02_022493F0

	thumb_func_start ov02_022493FC
ov02_022493FC: ; 0x022493FC
	push {lr}
	sub sp, #0xc
	mov r0, #6
	str r0, [sp]
	mov r1, #1
	str r1, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	ldr r3, _0224941C ; =0x00007FFF
	mov r0, #0
	add r2, r1, #0
	bl BeginNormalPaletteFade
	add sp, #0xc
	pop {pc}
	nop
_0224941C: .word 0x00007FFF
	thumb_func_end ov02_022493FC

	thumb_func_start ov02_02249420
ov02_02249420: ; 0x02249420
	push {lr}
	sub sp, #0xc
	mov r0, #6
	str r0, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0
	ldr r3, _02249440 ; =0x00007FFF
	add r1, r0, #0
	add r2, r0, #0
	bl BeginNormalPaletteFade
	add sp, #0xc
	pop {pc}
	.balign 4, 0
_02249440: .word 0x00007FFF
	thumb_func_end ov02_02249420

	thumb_func_start ov02_02249444
ov02_02249444: ; 0x02249444
	push {r4, lr}
	ldr r0, [r0, #0x40]
	add r4, r1, #0
	bl PlayerAvatar_GetMapObject
	add r1, r4, #0
	bl MapObject_SetVisible
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249444

	thumb_func_start ov02_02249458
ov02_02249458: ; 0x02249458
	push {r3, r4, r5, r6, r7, lr}
	str r0, [sp]
	add r5, r1, #0
	add r6, r2, #0
	add r7, r3, #0
	bl ov02_0224955C
	add r4, r0, #0
	str r6, [r4, #0x5c]
	strh r7, [r4, #0xc]
	ldrh r0, [r4, #0xc]
	strh r0, [r4, #0xe]
	str r5, [r4, #0x20]
	ldr r0, [r4, #0x60]
	ldr r0, [r0, #0x40]
	bl PlayerAvatar_GetMapObject
	mov r1, #0x82
	lsl r1, r1, #2
	str r0, [r4, r1]
	cmp r5, #0
	bne _02249490
	ldr r0, _022494B8 ; =ov02_02249584
	add r1, r4, #0
	mov r2, #0x86
	bl SysTask_CreateOnMainQueue
	pop {r3, r4, r5, r6, r7, pc}
_02249490:
	cmp r5, #2
	bne _022494AC
	ldr r0, [sp]
	bl FollowMon_GetMapObject
	mov r1, #0x83
	lsl r1, r1, #2
	str r0, [r4, r1]
	ldr r0, _022494BC ; =ov02_022499B8
	add r1, r4, #0
	mov r2, #0x86
	bl SysTask_CreateOnMainQueue
	pop {r3, r4, r5, r6, r7, pc}
_022494AC:
	ldr r0, _022494C0 ; =ov02_02249984
	add r1, r4, #0
	mov r2, #0x86
	bl SysTask_CreateOnMainQueue
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_022494B8: .word ov02_02249584
_022494BC: .word ov02_022499B8
_022494C0: .word ov02_02249984
	thumb_func_end ov02_02249458

	thumb_func_start ov02_022494C4
ov02_022494C4: ; 0x022494C4
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x18
	add r5, r1, #0
	add r6, r2, #0
	add r7, r3, #0
	bl ov02_0224955C
	add r4, r0, #0
	str r5, [r4, #0x5c]
	mov r0, #0
	strh r0, [r4, #0xc]
	mov r0, #2
	strh r0, [r4, #0xe]
	mov r0, #3
	str r0, [r4, #0x20]
	mov r0, #0x82
	lsl r0, r0, #2
	str r6, [r4, r0]
	add r0, r0, #4
	str r7, [r4, r0]
	ldr r0, [r4, #0x60]
	ldr r0, [r0, #0x40]
	bl PlayerAvatar_GetMapObject
	add r1, sp, #0xc
	bl MapObject_CopyPositionVector
	mov r0, #0x82
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, sp, #0
	bl MapObject_CopyPositionVector
	ldr r1, [sp]
	ldr r0, [sp, #0xc]
	sub r0, r1, r0
	mov r1, #2
	lsl r1, r1, #0xc
	bl FX_Div
	mov r1, #0xbb
	lsl r1, r1, #2
	ldr r2, [r4, r1]
	add r0, r2, r0
	str r0, [r4, r1]
	ldr r2, [sp, #8]
	ldr r0, [sp, #0x14]
	add r1, #8
	sub r0, r2, r0
	str r0, [r4, r1]
	ldr r0, _02249538 ; =ov02_022499B8
	add r1, r4, #0
	mov r2, #0x86
	bl SysTask_CreateOnMainQueue
	add sp, #0x18
	pop {r3, r4, r5, r6, r7, pc}
	nop
_02249538: .word ov02_022499B8
	thumb_func_end ov02_022494C4

	thumb_func_start ov02_0224953C
ov02_0224953C: ; 0x0224953C
	push {r3, lr}
	bl SysTask_GetData
	ldr r0, [r0, #4]
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224953C

	thumb_func_start ov02_02249548
ov02_02249548: ; 0x02249548
	push {r4, lr}
	add r4, r0, #0
	bl SysTask_GetData
	bl ov02_0224957C
	add r0, r4, #0
	bl SysTask_Destroy
	pop {r4, pc}
	thumb_func_end ov02_02249548

	thumb_func_start ov02_0224955C
ov02_0224955C: ; 0x0224955C
	push {r3, r4, r5, lr}
	mov r1, #0xbe
	add r5, r0, #0
	mov r0, #4
	lsl r1, r1, #2
	bl Heap_AllocAtEnd
	mov r2, #0xbe
	mov r1, #0
	lsl r2, r2, #2
	add r4, r0, #0
	bl memset
	str r5, [r4, #0x60]
	add r0, r4, #0
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224955C

	thumb_func_start ov02_0224957C
ov02_0224957C: ; 0x0224957C
	ldr r3, _02249580 ; =Heap_Free
	bx r3
	.balign 4, 0
_02249580: .word Heap_Free
	thumb_func_end ov02_0224957C

	thumb_func_start ov02_02249584
ov02_02249584: ; 0x02249584
	push {r3, r4, r5, lr}
	ldr r4, _022495B4 ; =ov02_02253550
	add r5, r1, #0
_0224958A:
	ldr r1, [r5]
	add r0, r5, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	blx r1
	cmp r0, #1
	beq _0224958A
	ldr r0, [r5, #0x10]
	cmp r0, #1
	bne _022495B2
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	cmp r0, #0
	beq _022495AC
	bl sub_02068BAC
_022495AC:
	add r0, r5, #0
	bl ov02_0224A32C
_022495B2:
	pop {r3, r4, r5, pc}
	.balign 4, 0
_022495B4: .word ov02_02253550
	thumb_func_end ov02_02249584

	thumb_func_start ov02_022495B8
ov02_022495B8: ; 0x022495B8
	push {r4, lr}
	add r4, r0, #0
	bl ov02_02249EC0
	add r0, r4, #0
	bl ov02_02249CF0
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_022495B8

	thumb_func_start ov02_022495D0
ov02_022495D0: ; 0x022495D0
	push {r4, lr}
	add r4, r0, #0
	bl ov02_02249F6C
	add r0, r4, #0
	bl ov02_02249CF0
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_022495D0

	thumb_func_start ov02_022495E8
ov02_022495E8: ; 0x022495E8
	push {r3, r4, r5, lr}
	sub sp, #0x18
	add r4, r0, #0
	mov r0, #0x85
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	cmp r0, #0
	bne _022495FE
	add sp, #0x18
	mov r0, #0
	pop {r3, r4, r5, pc}
_022495FE:
	ldr r5, _02249650 ; =ov02_02253408
	add r3, sp, #0xc
	ldmia r5!, {r0, r1}
	add r2, r3, #0
	stmia r3!, {r0, r1}
	ldr r0, [r5]
	ldr r5, _02249654 ; =ov02_02253384
	str r0, [r3]
	ldmia r5!, {r0, r1}
	add r3, sp, #0
	stmia r3!, {r0, r1}
	ldr r0, [r5]
	add r1, r2, #0
	str r0, [r3]
	add r0, r4, #0
	bl ov02_0224A418
	mov r1, #0x79
	lsl r1, r1, #2
	str r0, [r4, r1]
	add r0, r4, #0
	add r1, sp, #0
	bl ov02_0224A9B8
	mov r1, #0x7a
	lsl r1, r1, #2
	str r0, [r4, r1]
	add r0, r4, #0
	mov r1, #1
	bl ov02_0224A9D8
	add r0, r4, #0
	bl ov02_02249D40
	mov r0, #1
	str r0, [r4, #0x10]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	add sp, #0x18
	pop {r3, r4, r5, pc}
	.balign 4, 0
_02249650: .word ov02_02253408
_02249654: .word ov02_02253384
	thumb_func_end ov02_022495E8

	thumb_func_start ov02_02249658
ov02_02249658: ; 0x02249658
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224B72C
	mov r0, #0
	ldr r1, _0224968C ; =0xFFFC0000
	str r0, [r4, #0x2c]
	str r1, [r4, #0x54]
	mov r1, #0xfe
	lsl r1, r1, #0xc
	str r1, [r4, #0x44]
	mov r1, #0xff
	lsl r1, r1, #0xc
	str r1, [r4, #0x48]
	mov r1, #0x5f
	lsl r1, r1, #0xc
	str r1, [r4, #0x4c]
	mov r1, #0x61
	lsl r1, r1, #0xc
	str r1, [r4, #0x50]
	mov r1, #1
	str r1, [r4, #0x2c]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	pop {r4, pc}
	.balign 4, 0
_0224968C: .word 0xFFFC0000
	thumb_func_end ov02_02249658

	thumb_func_start ov02_02249690
ov02_02249690: ; 0x02249690
	push {r3, r4, lr}
	sub sp, #4
	add r4, r0, #0
	mov r2, #0
	str r2, [r4, #0x2c]
	ldr r1, [r4, #0x44]
	ldr r0, [r4, #0x54]
	add r0, r1, r0
	str r0, [r4, #0x44]
	cmp r0, #0
	bgt _022496B4
	mov r0, #2
	str r2, [r4, #0x44]
	lsl r0, r0, #0xc
	str r0, [r4, #0x54]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_022496B4:
	ldr r0, [r4, #0x50]
	str r0, [sp]
	ldr r1, [r4, #0x44]
	ldr r2, [r4, #0x4c]
	ldr r3, [r4, #0x48]
	add r0, r4, #0
	bl ov02_0224A69C
	mov r0, #1
	str r0, [r4, #0x2c]
	mov r0, #0
	add sp, #4
	pop {r3, r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249690

	thumb_func_start ov02_022496D0
ov02_022496D0: ; 0x022496D0
	push {r3, r4, lr}
	sub sp, #4
	add r4, r0, #0
	mov r0, #0
	str r0, [r4, #0x2c]
	ldr r1, [r4, #0x4c]
	ldr r0, [r4, #0x54]
	sub r0, r1, r0
	str r0, [r4, #0x4c]
	ldr r1, [r4, #0x50]
	ldr r0, [r4, #0x54]
	add r0, r1, r0
	str r0, [r4, #0x50]
	mov r0, #2
	ldr r1, [r4, #0x54]
	lsl r0, r0, #0xc
	add r2, r1, r0
	lsl r1, r0, #4
	str r2, [r4, #0x54]
	cmp r2, r1
	ble _022496FE
	lsl r0, r0, #4
	str r0, [r4, #0x54]
_022496FE:
	mov r0, #0xe
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xe
	cmp r1, r0
	bge _0224970A
	str r0, [r4, #0x4c]
_0224970A:
	mov r0, #0x22
	ldr r1, [r4, #0x50]
	lsl r0, r0, #0xe
	cmp r1, r0
	ble _02249716
	str r0, [r4, #0x50]
_02249716:
	ldr r0, [r4, #0x50]
	str r0, [sp]
	ldr r1, [r4, #0x44]
	ldr r2, [r4, #0x4c]
	ldr r3, [r4, #0x48]
	add r0, r4, #0
	bl ov02_0224A69C
	mov r0, #1
	str r0, [r4, #0x2c]
	mov r0, #0xe
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xe
	cmp r1, r0
	bne _0224974E
	mov r0, #0x22
	ldr r1, [r4, #0x50]
	lsl r0, r0, #0xe
	cmp r1, r0
	bne _0224974E
	mov r0, #0x79
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl ov02_0224A450
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_0224974E:
	mov r0, #0
	add sp, #4
	pop {r3, r4, pc}
	thumb_func_end ov02_022496D0

	thumb_func_start ov02_02249754
ov02_02249754: ; 0x02249754
	ldr r1, [r0, #8]
	add r1, r1, #1
	str r1, [r0, #8]
	cmp r1, #0xf
	blt _0224976C
	mov r1, #0
	str r1, [r0, #8]
	ldr r1, _02249770 ; =0xFFFC0000
	str r1, [r0, #0x58]
	ldr r1, [r0]
	add r1, r1, #1
	str r1, [r0]
_0224976C:
	mov r0, #0
	bx lr
	.balign 4, 0
_02249770: .word 0xFFFC0000
	thumb_func_end ov02_02249754

	thumb_func_start ov02_02249774
ov02_02249774: ; 0x02249774
	push {r3, r4, lr}
	sub sp, #0xc
	add r4, r0, #0
	mov r0, #0x7a
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl Sprite_GetMatrixPtr
	add r3, r0, #0
	ldmia r3!, {r0, r1}
	add r2, sp, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r1, [sp]
	ldr r0, [r4, #0x58]
	add r1, r1, r0
	mov r0, #0xa
	lsl r0, r0, #0x10
	str r1, [sp]
	cmp r1, r0
	bgt _022497AC
	mov r0, #3
	lsl r0, r0, #0x12
	str r0, [sp]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_022497AC:
	mov r0, #0x7a
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, sp, #0
	bl Sprite_SetMatrix
	mov r0, #0
	add sp, #0xc
	pop {r3, r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249774

	thumb_func_start ov02_022497C0
ov02_022497C0: ; 0x022497C0
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r0, #0
	ldr r1, [r4, #0x58]
	lsr r0, r1, #0x1f
	add r0, r1, r0
	asr r1, r0, #1
	ldr r0, _02249834 ; =0xFFFFE000
	str r1, [r4, #0x58]
	cmp r1, r0
	ble _02249802
	str r0, [r4, #0x58]
	ldr r0, [r4]
	mov r1, #5
	add r0, r0, #1
	str r0, [r4]
	ldr r0, [r4, #0x5c]
	mov r2, #0
	bl GetMonData
	add r5, r0, #0
	ldr r0, [r4, #0x5c]
	mov r1, #0x70
	mov r2, #0
	bl GetMonData
	add r1, r0, #0
	lsl r0, r5, #0x10
	lsl r1, r1, #0x18
	lsr r0, r0, #0x10
	lsr r1, r1, #0x18
	bl PlayCry
_02249802:
	mov r0, #0x7a
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl Sprite_GetMatrixPtr
	add r5, r0, #0
	add r3, sp, #0
	ldmia r5!, {r0, r1}
	add r2, r3, #0
	stmia r3!, {r0, r1}
	ldr r0, [r5]
	str r0, [r3]
	ldr r1, [sp]
	ldr r0, [r4, #0x58]
	add r0, r1, r0
	str r0, [sp]
	mov r0, #0x7a
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, r2, #0
	bl Sprite_SetMatrix
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	.balign 4, 0
_02249834: .word 0xFFFFE000
	thumb_func_end ov02_022497C0

	thumb_func_start ov02_02249838
ov02_02249838: ; 0x02249838
	ldr r1, [r0, #8]
	add r1, r1, #1
	str r1, [r0, #8]
	cmp r1, #8
	blt _02249850
	mov r1, #0
	str r1, [r0, #8]
	ldr r1, _02249854 ; =0xFFFFF000
	str r1, [r0, #0x58]
	ldr r1, [r0]
	add r1, r1, #1
	str r1, [r0]
_02249850:
	mov r0, #0
	bx lr
	.balign 4, 0
_02249854: .word 0xFFFFF000
	thumb_func_end ov02_02249838

	thumb_func_start ov02_02249858
ov02_02249858: ; 0x02249858
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r0, #0
	ldr r0, [r4, #0x58]
	lsl r1, r0, #1
	ldr r0, _022498B4 ; =0xFFFC0000
	str r1, [r4, #0x58]
	cmp r1, r0
	bge _0224986C
	str r0, [r4, #0x58]
_0224986C:
	mov r0, #0x7a
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl Sprite_GetMatrixPtr
	add r5, r0, #0
	add r3, sp, #0
	ldmia r5!, {r0, r1}
	add r2, r3, #0
	stmia r3!, {r0, r1}
	ldr r0, [r5]
	str r0, [r3]
	ldr r1, [sp]
	ldr r0, [r4, #0x58]
	add r0, r1, r0
	str r0, [sp]
	mov r0, #0x7a
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, r2, #0
	bl Sprite_SetMatrix
	ldr r1, [sp]
	ldr r0, _022498B8 ; =0xFFFD8000
	cmp r1, r0
	bgt _022498AC
	mov r0, #1
	lsl r0, r0, #0xc
	str r0, [r4, #0x54]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_022498AC:
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	nop
_022498B4: .word 0xFFFC0000
_022498B8: .word 0xFFFD8000
	thumb_func_end ov02_02249858

	thumb_func_start ov02_022498BC
ov02_022498BC: ; 0x022498BC
	push {r3, r4, lr}
	sub sp, #4
	add r4, r0, #0
	mov r0, #0
	str r0, [r4, #0x2c]
	ldr r1, [r4, #0x4c]
	ldr r0, [r4, #0x54]
	add r0, r1, r0
	str r0, [r4, #0x4c]
	ldr r1, [r4, #0x50]
	ldr r0, [r4, #0x54]
	sub r0, r1, r0
	str r0, [r4, #0x50]
	mov r0, #1
	ldr r1, [r4, #0x54]
	lsl r0, r0, #0xe
	add r2, r1, r0
	lsl r1, r0, #2
	str r2, [r4, #0x54]
	cmp r2, r1
	ble _022498EA
	lsl r0, r0, #2
	str r0, [r4, #0x54]
_022498EA:
	mov r0, #0x5f
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xc
	cmp r1, r0
	blt _022498F6
	str r0, [r4, #0x4c]
_022498F6:
	mov r0, #0x61
	ldr r1, [r4, #0x50]
	lsl r0, r0, #0xc
	cmp r1, r0
	bgt _02249902
	str r0, [r4, #0x50]
_02249902:
	ldr r0, [r4, #0x50]
	str r0, [sp]
	ldr r1, [r4, #0x44]
	ldr r2, [r4, #0x4c]
	ldr r3, [r4, #0x48]
	add r0, r4, #0
	bl ov02_0224A69C
	mov r0, #1
	str r0, [r4, #0x2c]
	mov r0, #0x5f
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xc
	cmp r1, r0
	bne _0224993A
	mov r0, #0x61
	ldr r1, [r4, #0x50]
	lsl r0, r0, #0xc
	cmp r1, r0
	bne _0224993A
	add r0, r4, #0
	bl ov02_0224B768
	mov r0, #0x11
	str r0, [r4, #0x34]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_0224993A:
	mov r0, #0
	add sp, #4
	pop {r3, r4, pc}
	thumb_func_end ov02_022498BC

	thumb_func_start ov02_02249940
ov02_02249940: ; 0x02249940
	push {r4, lr}
	add r4, r0, #0
	bl ov02_02249FD4
	mov r0, #0
	str r0, [r4, #0x10]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	pop {r4, pc}
	thumb_func_end ov02_02249940

	thumb_func_start ov02_02249954
ov02_02249954: ; 0x02249954
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224A028
	mov r0, #0
	str r0, [r4, #0x10]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	pop {r4, pc}
	thumb_func_end ov02_02249954

	thumb_func_start ov02_02249968
ov02_02249968: ; 0x02249968
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224A6D0
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249968

	thumb_func_start ov02_0224997C
ov02_0224997C: ; 0x0224997C
	mov r1, #1
	str r1, [r0, #4]
	mov r0, #0
	bx lr
	thumb_func_end ov02_0224997C

	thumb_func_start ov02_02249984
ov02_02249984: ; 0x02249984
	push {r3, r4, r5, lr}
	ldr r4, _022499B4 ; =ov02_02253588
	add r5, r1, #0
_0224998A:
	ldr r1, [r5]
	add r0, r5, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	blx r1
	cmp r0, #1
	beq _0224998A
	ldr r0, [r5, #0x10]
	cmp r0, #1
	bne _022499B2
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	cmp r0, #0
	beq _022499AC
	bl sub_02068BAC
_022499AC:
	add r0, r5, #0
	bl ov02_0224A32C
_022499B2:
	pop {r3, r4, r5, pc}
	.balign 4, 0
_022499B4: .word ov02_02253588
	thumb_func_end ov02_02249984

	thumb_func_start ov02_022499B8
ov02_022499B8: ; 0x022499B8
	push {r3, r4, r5, lr}
	ldr r4, _022499E8 ; =ov02_022534F0
	add r5, r1, #0
_022499BE:
	ldr r1, [r5]
	add r0, r5, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	blx r1
	cmp r0, #1
	beq _022499BE
	ldr r0, [r5, #0x10]
	cmp r0, #1
	bne _022499E6
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	cmp r0, #0
	beq _022499E0
	bl sub_02068BAC
_022499E0:
	add r0, r5, #0
	bl ov02_0224A32C
_022499E6:
	pop {r3, r4, r5, pc}
	.balign 4, 0
_022499E8: .word ov02_022534F0
	thumb_func_end ov02_022499B8

	thumb_func_start ov02_022499EC
ov02_022499EC: ; 0x022499EC
	push {r3, r4, r5, lr}
	sub sp, #0x18
	add r4, r0, #0
	mov r0, #0x85
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	cmp r0, #0
	bne _02249A02
	add sp, #0x18
	mov r0, #0
	pop {r3, r4, r5, pc}
_02249A02:
	ldr r5, _02249A54 ; =ov02_022533FC
	add r3, sp, #0xc
	ldmia r5!, {r0, r1}
	add r2, r3, #0
	stmia r3!, {r0, r1}
	ldr r0, [r5]
	ldr r5, _02249A58 ; =ov02_02253414
	str r0, [r3]
	ldmia r5!, {r0, r1}
	add r3, sp, #0
	stmia r3!, {r0, r1}
	ldr r0, [r5]
	add r1, r2, #0
	str r0, [r3]
	add r0, r4, #0
	bl ov02_0224A418
	mov r1, #0x79
	lsl r1, r1, #2
	str r0, [r4, r1]
	add r0, r4, #0
	add r1, sp, #0
	bl ov02_0224A9B8
	mov r1, #0x7a
	lsl r1, r1, #2
	str r0, [r4, r1]
	add r0, r4, #0
	mov r1, #1
	bl ov02_0224A9D8
	add r0, r4, #0
	bl ov02_02249D40
	mov r0, #1
	str r0, [r4, #0x10]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	add sp, #0x18
	pop {r3, r4, r5, pc}
	.balign 4, 0
_02249A54: .word ov02_022533FC
_02249A58: .word ov02_02253414
	thumb_func_end ov02_022499EC

	thumb_func_start ov02_02249A5C
ov02_02249A5C: ; 0x02249A5C
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	mov r3, #0x85
	add r4, r0, #0
	lsl r3, r3, #2
	ldr r0, [r4, r3]
	cmp r0, #0
	bne _02249A72
	add sp, #0xc
	mov r0, #0
	pop {r3, r4, r5, r6, pc}
_02249A72:
	ldr r6, _02249AC0 ; =ov02_02253348
	add r5, sp, #0
	ldmia r6!, {r0, r1}
	add r2, r5, #0
	stmia r5!, {r0, r1}
	ldr r0, [r6]
	str r0, [r5]
	add r0, r3, #0
	add r0, #0xd8
	ldr r1, [sp]
	ldr r0, [r4, r0]
	add r3, #0xe0
	add r0, r1, r0
	str r0, [sp]
	ldr r1, [sp, #4]
	ldr r0, [r4, r3]
	add r0, r1, r0
	str r0, [sp, #4]
	add r0, r4, #0
	add r1, r2, #0
	bl ov02_0224A418
	mov r1, #0x79
	lsl r1, r1, #2
	str r0, [r4, r1]
	ldr r0, [r4, r1]
	mov r1, #1
	bl Sprite_SetAnimCtrlSeq
	add r0, r4, #0
	bl ov02_02249D40
	mov r0, #1
	str r0, [r4, #0x10]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
_02249AC0: .word ov02_02253348
	thumb_func_end ov02_02249A5C

	thumb_func_start ov02_02249AC4
ov02_02249AC4: ; 0x02249AC4
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224A8D4
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249AC4

	thumb_func_start ov02_02249AD8
ov02_02249AD8: ; 0x02249AD8
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224A4D0
	add r0, r4, #0
	bl ov02_02249D18
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_02249AD8

	thumb_func_start ov02_02249AF0
ov02_02249AF0: ; 0x02249AF0
	push {r4, lr}
	mov r1, #0x85
	add r4, r0, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	cmp r1, #0
	bne _02249B02
	mov r0, #0
	pop {r4, pc}
_02249B02:
	bl ov02_02249D40
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r4, pc}
	thumb_func_end ov02_02249AF0

	thumb_func_start ov02_02249B10
ov02_02249B10: ; 0x02249B10
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224AB58
	add r0, r4, #0
	bl ov02_0224AC38
	add r0, r4, #0
	bl ov02_0224A690
	add r0, r4, #0
	mov r1, #1
	bl ov02_0224B6B0
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249B10

	thumb_func_start ov02_02249B38
ov02_02249B38: ; 0x02249B38
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224AB8C
	cmp r0, #2
	beq _02249B48
	mov r0, #0
	pop {r4, pc}
_02249B48:
	mov r0, #0x79
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	mov r1, #1
	bl Sprite_SetAnimCtrlSeq
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249B38

	thumb_func_start ov02_02249B60
ov02_02249B60: ; 0x02249B60
	push {r3, lr}
	ldr r1, [r0, #8]
	add r1, r1, #1
	str r1, [r0, #8]
	cmp r1, #0x14
	blt _02249B7A
	mov r1, #0
	str r1, [r0, #8]
	ldr r1, [r0]
	add r1, r1, #1
	str r1, [r0]
	bl ov02_0224ADF0
_02249B7A:
	mov r0, #1
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_02249B60

	thumb_func_start ov02_02249B80
ov02_02249B80: ; 0x02249B80
	push {r4, lr}
	add r4, r0, #0
	ldr r1, [r4, #8]
	add r1, r1, #1
	str r1, [r4, #8]
	cmp r1, #0x14
	blt _02249BA2
	mov r1, #0
	str r1, [r4, #8]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	bl ov02_0224AB58
	add r0, r4, #0
	bl ov02_0224ADF0
_02249BA2:
	mov r0, #1
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249B80

	thumb_func_start ov02_02249BA8
ov02_02249BA8: ; 0x02249BA8
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224AB8C
	cmp r0, #3
	beq _02249BB8
	mov r0, #0
	pop {r4, pc}
_02249BB8:
	ldr r0, _02249BD4 ; =SEQ_SE_DP_FW019
	bl PlaySE
	mov r0, #2
	lsl r0, r0, #0xa
	str r0, [r4, #0x54]
	mov r0, #2
	str r0, [r4, #0x14]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r4, pc}
	nop
_02249BD4: .word SEQ_SE_DP_FW019
	thumb_func_end ov02_02249BA8

	thumb_func_start ov02_02249BD8
ov02_02249BD8: ; 0x02249BD8
	push {r3, r4, lr}
	sub sp, #4
	add r4, r0, #0
	mov r0, #0
	str r0, [r4, #0x2c]
	ldr r1, [r4, #0x4c]
	ldr r0, [r4, #0x54]
	add r0, r1, r0
	str r0, [r4, #0x4c]
	ldr r1, [r4, #0x50]
	ldr r0, [r4, #0x54]
	sub r0, r1, r0
	str r0, [r4, #0x50]
	mov r0, #2
	ldr r1, [r4, #0x54]
	lsl r0, r0, #0xa
	add r2, r1, r0
	lsl r1, r0, #5
	str r2, [r4, #0x54]
	cmp r2, r1
	ble _02249C06
	lsl r0, r0, #5
	str r0, [r4, #0x54]
_02249C06:
	mov r0, #0x5f
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xc
	cmp r1, r0
	blt _02249C12
	str r0, [r4, #0x4c]
_02249C12:
	mov r0, #0x61
	ldr r1, [r4, #0x50]
	lsl r0, r0, #0xc
	cmp r1, r0
	bgt _02249C1E
	str r0, [r4, #0x50]
_02249C1E:
	ldr r0, [r4, #0x50]
	str r0, [sp]
	ldr r1, [r4, #0x44]
	ldr r2, [r4, #0x4c]
	ldr r3, [r4, #0x48]
	add r0, r4, #0
	bl ov02_0224A69C
	mov r0, #1
	str r0, [r4, #0x2c]
	ldr r0, [r4, #0x18]
	cmp r0, #0
	bne _02249C4A
	add r0, r4, #0
	bl ov02_0224AB8C
	cmp r0, #4
	bne _02249C4A
	mov r0, #1
	str r0, [r4, #0x18]
	bl ov02_02249420
_02249C4A:
	mov r0, #0x5f
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xc
	cmp r1, r0
	bne _02249C6C
	mov r0, #0x61
	ldr r1, [r4, #0x50]
	lsl r0, r0, #0xc
	cmp r1, r0
	bne _02249C6C
	mov r0, #0x11
	str r0, [r4, #0x34]
	mov r0, #1
	str r0, [r4, #0x14]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_02249C6C:
	mov r0, #0
	add sp, #4
	pop {r3, r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249BD8

	thumb_func_start ov02_02249C74
ov02_02249C74: ; 0x02249C74
	push {r4, lr}
	add r4, r0, #0
	ldr r1, [r4, #0x20]
	cmp r1, #3
	bne _02249C96
	bl ov02_0224AB8C
	cmp r0, #2
	bne _02249C92
	add r0, r4, #0
	bl ov02_0224AB9C
	ldr r0, [r4]
	add r0, r0, #2
	str r0, [r4]
_02249C92:
	mov r0, #0
	pop {r4, pc}
_02249C96:
	ldr r1, [r4, #0x18]
	cmp r1, #0
	bne _02249CAC
	bl ov02_0224AB8C
	cmp r0, #4
	bne _02249CAC
	mov r0, #1
	str r0, [r4, #0x18]
	bl ov02_02249420
_02249CAC:
	add r0, r4, #0
	bl ov02_0224AB8C
	cmp r0, #2
	beq _02249CBA
	mov r0, #0
	pop {r4, pc}
_02249CBA:
	ldr r0, [r4, #0x18]
	cmp r0, #0
	bne _02249CC8
	mov r0, #1
	str r0, [r4, #0x18]
	bl ov02_02249420
_02249CC8:
	add r0, r4, #0
	bl ov02_0224AB9C
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_02249C74

	thumb_func_start ov02_02249CD8
ov02_02249CD8: ; 0x02249CD8
	push {r4, lr}
	add r4, r0, #0
	bl IsPaletteFadeFinished
	cmp r0, #0
	beq _02249CEA
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_02249CEA:
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_02249CD8

	thumb_func_start ov02_02249CF0
ov02_02249CF0: ; 0x02249CF0
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x21
	mov r1, #0
	lsl r0, r0, #4
	str r1, [r4, r0]
	add r0, r0, #4
	str r1, [r4, r0]
	ldr r0, _02249D14 ; =ov02_02249D5C
	add r1, r4, #0
	mov r2, #0x80
	bl SysTask_CreateOnVBlankQueue
	mov r1, #0x22
	lsl r1, r1, #4
	str r0, [r4, r1]
	pop {r4, pc}
	nop
_02249D14: .word ov02_02249D5C
	thumb_func_end ov02_02249CF0

	thumb_func_start ov02_02249D18
ov02_02249D18: ; 0x02249D18
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x21
	mov r1, #0
	lsl r0, r0, #4
	str r1, [r4, r0]
	add r0, r0, #4
	str r1, [r4, r0]
	ldr r0, _02249D3C ; =ov02_02249E58
	add r1, r4, #0
	mov r2, #0x80
	bl SysTask_CreateOnVBlankQueue
	mov r1, #0x22
	lsl r1, r1, #4
	str r0, [r4, r1]
	pop {r4, pc}
	nop
_02249D3C: .word ov02_02249E58
	thumb_func_end ov02_02249D18

	thumb_func_start ov02_02249D40
ov02_02249D40: ; 0x02249D40
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x22
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	cmp r0, #0
	beq _02249D5A
	bl SysTask_Destroy
	mov r0, #0x22
	mov r1, #0
	lsl r0, r0, #4
	str r1, [r4, r0]
_02249D5A:
	pop {r4, pc}
	thumb_func_end ov02_02249D40

	thumb_func_start ov02_02249D5C
ov02_02249D5C: ; 0x02249D5C
	push {r3, r4, r5, r6, r7, lr}
	mov r0, #0x21
	add r6, r1, #0
	lsl r0, r0, #4
	ldr r0, [r6, r0]
	cmp r0, #0
	bne _02249DD2
	mov r7, #0x6b
	mov r4, #0
	add r5, r6, #0
	lsl r7, r7, #2
_02249D72:
	ldr r0, [r5, r7]
	cmp r0, #0
	beq _02249D7C
	bl SpriteTransfer_CreateCharTransferTask_AllocAtEnd
_02249D7C:
	add r4, r4, #1
	add r5, r5, #4
	cmp r4, #4
	blt _02249D72
	mov r7, #0x6f
	mov r5, #0
	add r4, r6, #0
	lsl r7, r7, #2
_02249D8C:
	ldr r0, [r4, r7]
	cmp r0, #0
	beq _02249D96
	bl SpriteTransfer_CreatePlttTransferTask
_02249D96:
	add r5, r5, #1
	add r4, r4, #4
	cmp r5, #3
	blt _02249D8C
	mov r0, #0x86
	lsl r0, r0, #2
	ldr r1, [r6, r0]
	cmp r1, #0
	beq _02249DAE
	add r0, r6, #0
	bl ov02_0224A834
_02249DAE:
	mov r0, #0x87
	lsl r0, r0, #2
	ldr r1, [r6, r0]
	cmp r1, #0
	beq _02249DBE
	add r0, r6, #0
	bl ov02_0224A88C
_02249DBE:
	mov r0, #0x21
	lsl r0, r0, #4
	ldr r1, [r6, r0]
	mov r2, #0x80
	add r1, r1, #1
	str r1, [r6, r0]
	ldr r0, _02249DD4 ; =ov02_02249DD8
	add r1, r6, #0
	bl SysTask_CreateOnVWaitQueue
_02249DD2:
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_02249DD4: .word ov02_02249DD8
	thumb_func_end ov02_02249D5C

	thumb_func_start ov02_02249DD8
ov02_02249DD8: ; 0x02249DD8
	push {r3, r4, r5, r6, r7, lr}
	str r0, [sp]
	mov r0, #0x21
	add r6, r1, #0
	lsl r0, r0, #4
	ldr r0, [r6, r0]
	cmp r0, #1
	bne _02249E56
	mov r7, #0x6b
	mov r4, #0
	add r5, r6, #0
	lsl r7, r7, #2
_02249DF0:
	ldr r0, [r5, r7]
	cmp r0, #0
	beq _02249DFA
	bl sub_0200A740
_02249DFA:
	add r4, r4, #1
	add r5, r5, #4
	cmp r4, #4
	blt _02249DF0
	mov r7, #0x6f
	mov r5, #0
	add r4, r6, #0
	lsl r7, r7, #2
_02249E0A:
	ldr r0, [r4, r7]
	cmp r0, #0
	beq _02249E14
	bl sub_0200A740
_02249E14:
	add r5, r5, #1
	add r4, r4, #4
	cmp r5, #3
	blt _02249E0A
	mov r0, #0x86
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	cmp r0, #0
	beq _02249E32
	bl Heap_Free
	mov r0, #0x86
	mov r1, #0
	lsl r0, r0, #2
	str r1, [r6, r0]
_02249E32:
	mov r0, #0x87
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	cmp r0, #0
	beq _02249E48
	bl Heap_Free
	mov r0, #0x87
	mov r1, #0
	lsl r0, r0, #2
	str r1, [r6, r0]
_02249E48:
	mov r0, #0x85
	mov r1, #1
	lsl r0, r0, #2
	str r1, [r6, r0]
	ldr r0, [sp]
	bl SysTask_Destroy
_02249E56:
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_02249DD8

	thumb_func_start ov02_02249E58
ov02_02249E58: ; 0x02249E58
	push {r4, lr}
	mov r0, #0x67
	add r4, r1, #0
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	mov r1, #0
	bl SpriteResourceCollection_Find
	mov r1, #0x21
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	cmp r1, #0
	bne _02249E8A
	bl SpriteTransfer_CreateCharTransferTask_AllocAtEnd
	ldr r0, _02249E8C ; =ov02_02249E90
	add r1, r4, #0
	mov r2, #0x80
	bl SysTask_CreateOnVWaitQueue
	mov r0, #0x21
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	add r1, r1, #1
	str r1, [r4, r0]
_02249E8A:
	pop {r4, pc}
	.balign 4, 0
_02249E8C: .word ov02_02249E90
	thumb_func_end ov02_02249E58

	thumb_func_start ov02_02249E90
ov02_02249E90: ; 0x02249E90
	push {r3, r4, r5, lr}
	add r5, r0, #0
	mov r0, #0x67
	add r4, r1, #0
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	mov r1, #0
	bl SpriteResourceCollection_Find
	mov r1, #0x21
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	cmp r1, #1
	bne _02249EBE
	bl sub_0200A740
	mov r0, #0x85
	mov r1, #1
	lsl r0, r0, #2
	str r1, [r4, r0]
	add r0, r5, #0
	bl SysTask_Destroy
_02249EBE:
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_02249E90

	thumb_func_start ov02_02249EC0
ov02_02249EC0: ; 0x02249EC0
	push {r3, r4, r5, lr}
	add r5, r0, #0
	bl ov02_0224A074
	mov r2, #3
	mov r3, #1
	add r4, r0, #0
	lsl r2, r2, #0x12
	add r0, r5, #0
	mov r1, #0
	lsl r3, r3, #0xc
	str r2, [sp]
	bl ov02_0224A69C
	add r0, r5, #0
	bl ov02_0224A648
	ldr r0, [r5, #0x60]
	mov r1, #0
	ldr r0, [r0, #8]
	bl GetBgPriority
	strh r0, [r5, #0x24]
	ldr r0, [r5, #0x60]
	mov r1, #3
	ldr r0, [r0, #8]
	bl GetBgPriority
	strh r0, [r5, #0x26]
	ldr r2, _02249F68 ; =0x0400000A
	mov r1, #3
	ldrh r3, [r2]
	mov r0, #1
	bic r3, r1
	orr r0, r3
	strh r0, [r2]
	ldrh r0, [r2, #4]
	bic r0, r1
	strh r0, [r2, #4]
	mov r0, #8
	mov r1, #0
	bl GfGfx_EngineATogglePlanes
	add r2, r5, #0
	add r0, r4, #0
#ifdef HEARTGOLD
	mov r1, #2
#else
	mov r1, #5
#endif
	add r2, #0x6c
	bl ov02_0224A570
	ldr r0, [r5, #0x60]
	add r3, r5, #0
	ldr r0, [r0, #8]
	add r1, r4, #0
#ifdef HEARTGOLD
	mov r2, #0
#else
	mov r2, #3
#endif
	add r3, #0x68
	bl ov02_0224A598
	ldr r0, [r5, #0x60]
	add r3, r5, #0
	ldr r0, [r0, #8]
	add r1, r4, #0
#ifdef HEARTGOLD
	mov r2, #1
#else
	mov r2, #4
#endif
	add r3, #0x64
	bl ov02_0224A5D0
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224A080
	add r0, r4, #0
	bl NARC_Delete
	mov r0, #4
	mov r1, #0x20
	bl sub_020689C8
	mov r1, #0x1e
	lsl r1, r1, #4
	str r0, [r5, r1]
	mov r0, #8
	mov r1, #1
	bl GfGfx_EngineATogglePlanes
	pop {r3, r4, r5, pc}
	.balign 4, 0
_02249F68: .word 0x0400000A
	thumb_func_end ov02_02249EC0

	thumb_func_start ov02_02249F6C
ov02_02249F6C: ; 0x02249F6C
	push {r3, r4, r5, lr}
	add r5, r0, #0
	bl ov02_0224A074
	add r4, r0, #0
	ldr r0, [r5, #0x60]
	mov r1, #0
	ldr r0, [r0, #8]
	bl GetBgPriority
	strh r0, [r5, #0x24]
	ldr r0, [r5, #0x60]
	mov r1, #3
	ldr r0, [r0, #8]
	bl GetBgPriority
	strh r0, [r5, #0x26]
	ldr r2, _02249FD0 ; =0x0400000A
	mov r1, #3
	ldrh r3, [r2]
	mov r0, #1
	bic r3, r1
	orr r0, r3
	strh r0, [r2]
	ldrh r0, [r2, #4]
	bic r0, r1
	strh r0, [r2, #4]
	mov r0, #8
	mov r1, #0
	bl GfGfx_EngineATogglePlanes
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224A080
	add r0, r4, #0
	bl NARC_Delete
	mov r0, #4
	mov r1, #0x20
	bl sub_020689C8
	mov r1, #0x1e
	lsl r1, r1, #4
	str r0, [r5, r1]
	mov r0, #8
	mov r1, #1
	bl GfGfx_EngineATogglePlanes
	pop {r3, r4, r5, pc}
	.balign 4, 0
_02249FD0: .word 0x0400000A
	thumb_func_end ov02_02249F6C

	thumb_func_start ov02_02249FD4
ov02_02249FD4: ; 0x02249FD4
	push {r4, lr}
	add r4, r0, #0
	mov r0, #8
	mov r1, #0
	bl GfGfx_EngineATogglePlanes
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl sub_020689F8
	ldr r0, [r4, #0x60]
	ldr r0, [r0, #8]
	bl ov02_0224A63C
	add r0, r4, #0
	bl ov02_0224A288
	ldr r2, _0224A024 ; =0x04000008
	ldrh r1, [r4, #0x24]
	ldrh r3, [r2]
	mov r0, #3
	bic r3, r0
	orr r1, r3
	strh r1, [r2]
	ldrh r1, [r2, #6]
	bic r1, r0
	ldrh r0, [r4, #0x26]
	orr r0, r1
	strh r0, [r2, #6]
	mov r0, #0
	mov r1, #1
	bl FieldMessage_LoadTextPalettes
	mov r0, #8
	mov r1, #1
	bl GfGfx_EngineATogglePlanes
	pop {r4, pc}
	nop
_0224A024: .word 0x04000008
	thumb_func_end ov02_02249FD4

	thumb_func_start ov02_0224A028
ov02_0224A028: ; 0x0224A028
	push {r4, lr}
	add r4, r0, #0
	mov r0, #8
	mov r1, #0
	bl GfGfx_EngineATogglePlanes
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl sub_020689F8
	add r0, r4, #0
	bl ov02_0224A288
	ldr r2, _0224A070 ; =0x04000008
	ldrh r1, [r4, #0x24]
	ldrh r3, [r2]
	mov r0, #3
	bic r3, r0
	orr r1, r3
	strh r1, [r2]
	ldrh r1, [r2, #6]
	bic r1, r0
	ldrh r0, [r4, #0x26]
	orr r0, r1
	strh r0, [r2, #6]
	mov r0, #0
	mov r1, #1
	bl FieldMessage_LoadTextPalettes
	mov r0, #8
	mov r1, #1
	bl GfGfx_EngineATogglePlanes
	pop {r4, pc}
	nop
_0224A070: .word 0x04000008
	thumb_func_end ov02_0224A028

	thumb_func_start ov02_0224A074
ov02_0224A074: ; 0x0224A074
	ldr r3, _0224A07C ; =NARC_New
	mov r0, #0x5d
	mov r1, #4
	bx r3
	.balign 4, 0
_0224A07C: .word NARC_New
	thumb_func_end ov02_0224A074

	thumb_func_start ov02_0224A080
ov02_0224A080: ; 0x0224A080
	push {r4, r5, r6, lr}
	sub sp, #0x10
	add r6, r1, #0
	mov r1, #0x7e
	add r5, r0, #0
	lsl r1, r1, #2
	add r1, r5, r1
	bl ov02_0224A7A8
	add r1, r5, #0
	mov r0, #0x20
	add r1, #0x74
	mov r2, #4
	bl G2dRenderer_Init
	str r0, [r5, #0x70]
	add r0, r5, #0
	mov r2, #2
	add r0, #0x74
	mov r1, #0
	lsl r2, r2, #0x14
	bl G2dRenderer_SetSubSurfaceCoords
	mov r0, #4
	mov r1, #0
	add r2, r0, #0
	bl Create2DGfxResObjMan
	mov r1, #0x67
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #3
	mov r1, #1
	mov r2, #4
	bl Create2DGfxResObjMan
	mov r1, #0x1a
	lsl r1, r1, #4
	str r0, [r5, r1]
	mov r0, #4
	mov r1, #2
	add r2, r0, #0
	bl Create2DGfxResObjMan
	mov r1, #0x69
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #2
	mov r1, #3
	mov r2, #4
	bl Create2DGfxResObjMan
	mov r1, #0x6a
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #1
	str r0, [sp]
	str r0, [sp, #4]
	mov r0, #4
	sub r1, #0xc
	str r0, [sp, #8]
	ldr r0, [r5, r1]
	add r1, r6, #0
	mov r2, #0xe
	mov r3, #0
	bl AddCharResObjFromOpenNarc
	mov r1, #0x6b
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #2
	str r0, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	ldrh r2, [r5, #0xe]
	sub r1, #0x10
	ldr r0, [r5, r1]
	lsl r3, r2, #1
	ldr r2, _0224A278 ; =ov02_02253304
	add r1, r6, #0
	ldrh r2, [r2, r3]
	mov r3, #0
	bl AddCharResObjFromOpenNarc
	mov r1, #0x1b
	lsl r1, r1, #4
	str r0, [r5, r1]
	add r0, r5, #0
	add r1, r6, #0
	bl ov02_0224A810
	mov r1, #0x6d
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r4, #0
	str r4, [sp]
	mov r0, #1
	str r0, [sp, #4]
	str r0, [sp, #8]
	mov r0, #4
	sub r1, #0x14
	str r0, [sp, #0xc]
	ldr r0, [r5, r1]
	add r1, r6, #0
	mov r2, #6
	add r3, r4, #0
	bl AddPlttResObjFromOpenNarc
	mov r1, #0x6f
	lsl r1, r1, #2
	str r0, [r5, r1]
	ldrh r2, [r5, #0xe]
	add r4, r4, #1
	cmp r2, #0
	beq _0224A196
	mov r0, #1
	sub r2, r2, #1
	str r0, [sp]
	lsl r3, r2, #1
	ldr r2, _0224A27C ; =ov02_022532FC
	str r0, [sp, #4]
	str r0, [sp, #8]
	mov r0, #4
	ldrh r2, [r2, r3]
	sub r1, #0x1c
	str r0, [sp, #0xc]
	ldr r0, [r5, r1]
	add r1, r6, #0
	mov r3, #0
	bl AddPlttResObjFromOpenNarc
	lsl r1, r4, #2
	add r2, r5, r1
	mov r1, #0x6f
	lsl r1, r1, #2
	str r0, [r2, r1]
	add r4, r4, #1
_0224A196:
	add r0, r5, #0
	add r1, r6, #0
	bl ov02_0224A868
	lsl r1, r4, #2
	add r2, r5, r1
	mov r1, #0x6f
	lsl r1, r1, #2
	str r0, [r2, r1]
	mov r0, #1
	str r0, [sp]
	mov r0, #2
	str r0, [sp, #4]
	mov r0, #4
	sub r1, #0x18
	str r0, [sp, #8]
	ldr r0, [r5, r1]
	add r1, r6, #0
	mov r2, #0xf
	mov r3, #0
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x72
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #2
	str r0, [sp]
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	ldrh r2, [r5, #0xe]
	sub r1, #0x24
	ldr r0, [r5, r1]
	lsl r3, r2, #1
	ldr r2, _0224A280 ; =ov02_02253310
	add r1, r6, #0
	ldrh r2, [r2, r3]
	mov r3, #0
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x73
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #3
	str r0, [sp]
	mov r0, #2
	str r0, [sp, #4]
	mov r0, #4
	sub r1, #0x28
	str r0, [sp, #8]
	ldr r0, [r5, r1]
	add r1, r6, #0
	mov r2, #0xa
	mov r3, #0
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x1d
	lsl r1, r1, #4
	str r0, [r5, r1]
	mov r3, #0
	str r3, [sp]
	mov r0, #3
	str r0, [sp, #4]
	mov r0, #4
	sub r1, #0x28
	str r0, [sp, #8]
	ldr r0, [r5, r1]
	add r1, r6, #0
	mov r2, #0x10
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x76
	lsl r1, r1, #2
	str r0, [r5, r1]
	mov r0, #1
	str r0, [sp]
	mov r0, #3
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	ldrh r2, [r5, #0xe]
	sub r1, #0x30
	ldr r0, [r5, r1]
	lsl r3, r2, #1
	ldr r2, _0224A284 ; =ov02_0225330A
	add r1, r6, #0
	ldrh r2, [r2, r3]
	mov r3, #0
	bl AddCellOrAnimResObjFromOpenNarc
	mov r1, #0x77
	lsl r1, r1, #2
	str r0, [r5, r1]
	add r1, #0x1c
	ldr r0, [r5, #0x5c]
	add r1, r5, r1
	mov r2, #4
	bl ov02_0224A7B8
	mov r1, #0x86
	lsl r1, r1, #2
	str r0, [r5, r1]
	sub r1, #0x20
	add r0, r5, r1
	mov r1, #4
	bl ov02_0224A800
	mov r1, #0x87
	lsl r1, r1, #2
	str r0, [r5, r1]
	add sp, #0x10
	pop {r4, r5, r6, pc}
	nop
_0224A278: .word ov02_02253304
_0224A27C: .word ov02_022532FC
_0224A280: .word ov02_02253310
_0224A284: .word ov02_0225330A
	thumb_func_end ov02_0224A080

	thumb_func_start ov02_0224A288
ov02_0224A288: ; 0x0224A288
	push {r3, r4, r5, r6, r7, lr}
	add r6, r0, #0
	mov r7, #0x6b
	mov r4, #0
	add r5, r6, #0
	lsl r7, r7, #2
_0224A294:
	ldr r0, [r5, r7]
	cmp r0, #0
	beq _0224A29E
	bl SpriteTransfer_DeleteCharTransferTask
_0224A29E:
	add r4, r4, #1
	add r5, r5, #4
	cmp r4, #4
	blt _0224A294
	mov r7, #0x6f
	mov r5, #0
	add r4, r6, #0
	lsl r7, r7, #2
_0224A2AE:
	ldr r0, [r4, r7]
	cmp r0, #0
	beq _0224A2B8
	bl SpriteTransfer_DeletePlttTransferTask
_0224A2B8:
	add r5, r5, #1
	add r4, r4, #4
	cmp r5, #3
	blt _0224A2AE
	mov r7, #0x72
	mov r5, #0
	add r4, r6, #0
	lsl r7, r7, #2
_0224A2C8:
	ldr r0, [r4, r7]
	cmp r0, #0
	beq _0224A2D2
	bl sub_0200A740
_0224A2D2:
	add r5, r5, #1
	add r4, r4, #4
	cmp r5, #4
	blt _0224A2C8
	mov r7, #0x76
	mov r5, #0
	add r4, r6, #0
	lsl r7, r7, #2
_0224A2E2:
	ldr r0, [r4, r7]
	cmp r0, #0
	beq _0224A2EC
	bl sub_0200A740
_0224A2EC:
	add r5, r5, #1
	add r4, r4, #4
	cmp r5, #2
	blt _0224A2E2
	mov r0, #0x67
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #0x1a
	lsl r0, r0, #4
	ldr r0, [r6, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #0x69
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	bl Destroy2DGfxResObjMan
	mov r0, #0x6a
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	bl Destroy2DGfxResObjMan
	ldr r0, [r6, #0x70]
	bl SpriteList_DeleteAllSprites
	ldr r0, [r6, #0x70]
	bl SpriteList_Delete
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A288

	thumb_func_start ov02_0224A32C
ov02_0224A32C: ; 0x0224A32C
	push {r3, lr}
	ldr r0, [r0, #0x70]
	cmp r0, #0
	beq _0224A338
	bl SpriteList_RenderAndAnimateSprites
_0224A338:
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A32C

	thumb_func_start ov02_0224A33C
ov02_0224A33C: ; 0x0224A33C
	push {r4, r5, r6, lr}
	sub sp, #0x70
	add r5, r0, #0
	ldr r0, [sp, #0x84]
	add r4, r1, #0
	add r1, r2, #0
	add r2, r3, #0
	cmp r0, #4
	bne _0224A384
	mov r0, #0
	mvn r0, r0
	str r0, [sp]
	str r0, [sp, #4]
	str r0, [sp, #8]
	mov r0, #0
	mov r6, #0x67
	ldr r3, [sp, #0x88]
	str r0, [sp, #0xc]
	lsl r6, r6, #2
	str r3, [sp, #0x10]
	ldr r3, [r5, r6]
	str r3, [sp, #0x14]
	add r3, r6, #4
	ldr r3, [r5, r3]
	add r6, #8
	str r3, [sp, #0x18]
	ldr r3, [r5, r6]
	str r3, [sp, #0x1c]
	str r0, [sp, #0x20]
	str r0, [sp, #0x24]
	str r0, [sp, #0x28]
	ldr r3, [sp, #0x80]
	add r0, sp, #0x4c
	bl CreateSpriteResourcesHeader
	b _0224A3BE
_0224A384:
	str r0, [sp]
	mov r0, #0
	mvn r0, r0
	str r0, [sp, #4]
	str r0, [sp, #8]
	mov r3, #0
	ldr r0, [sp, #0x88]
	str r3, [sp, #0xc]
	str r0, [sp, #0x10]
	mov r0, #0x67
	lsl r0, r0, #2
	ldr r6, [r5, r0]
	str r6, [sp, #0x14]
	add r6, r0, #4
	ldr r6, [r5, r6]
	str r6, [sp, #0x18]
	add r6, r0, #0
	add r6, #8
	ldr r6, [r5, r6]
	add r0, #0xc
	str r6, [sp, #0x1c]
	ldr r0, [r5, r0]
	str r0, [sp, #0x20]
	str r3, [sp, #0x24]
	str r3, [sp, #0x28]
	ldr r3, [sp, #0x80]
	add r0, sp, #0x4c
	bl CreateSpriteResourcesHeader
_0224A3BE:
	ldr r0, [r5, #0x70]
	add r2, sp, #0x34
	str r0, [sp, #0x2c]
	add r0, sp, #0x4c
	str r0, [sp, #0x30]
	ldmia r4!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r4]
	str r0, [r2]
	ldr r0, [sp, #0x8c]
	str r0, [sp, #0x40]
	mov r0, #1
	str r0, [sp, #0x44]
	mov r0, #4
	str r0, [sp, #0x48]
	add r0, sp, #0x2c
	bl Sprite_Create
	add r4, r0, #0
	bne _0224A3EA
	bl GF_AssertFail
_0224A3EA:
	add r0, r4, #0
	add sp, #0x70
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_0224A33C

	thumb_func_start ov02_0224A3F0
ov02_0224A3F0: ; 0x0224A3F0
	push {r3, r4, r5, lr}
	sub sp, #0x10
	mov r5, #1
	add r4, r3, #0
	str r5, [sp]
	mov r3, #0
	str r3, [sp, #4]
	str r3, [sp, #8]
	str r2, [sp, #0xc]
	add r2, r5, #0
	bl ov02_0224A33C
	add r1, r4, #0
	add r5, r0, #0
	bl Sprite_SetAnimCtrlSeq
	add r0, r5, #0
	add sp, #0x10
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A3F0

	thumb_func_start ov02_0224A418
ov02_0224A418: ; 0x0224A418
	push {r4, lr}
	sub sp, #0x10
	ldrh r2, [r0, #0xe]
	mov r3, #0
	cmp r2, #0
	beq _0224A426
	mov r3, #1
_0224A426:
	mov r2, #2
	str r2, [sp]
	mov r4, #1
	str r4, [sp, #4]
	mov r4, #0
	str r4, [sp, #8]
	mov r4, #0x83
	str r4, [sp, #0xc]
	bl ov02_0224A33C
	add r4, r0, #0
	mov r1, #0
	bl Sprite_SetDrawFlag
	add r0, r4, #0
	mov r1, #6
	bl Sprite_SetAnimCtrlSeq
	add r0, r4, #0
	add sp, #0x10
	pop {r4, pc}
	thumb_func_end ov02_0224A418

	thumb_func_start ov02_0224A450
ov02_0224A450: ; 0x0224A450
	push {r4, lr}
	mov r1, #1
	add r4, r0, #0
	bl Sprite_SetAnimActiveFlag
	mov r1, #1
	add r0, r4, #0
	lsl r1, r1, #0xc
	bl Sprite_SetAnimSpeed
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A450

	thumb_func_start ov02_0224A468
ov02_0224A468: ; 0x0224A468
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x28
	add r4, r0, #0
	add r0, sp, #0x1c
	mov r7, #0
	str r7, [r0]
	str r7, [r0, #4]
	add r6, r2, #0
	ldr r5, _0224A4CC ; =ov02_02253390
	add r3, r1, #0
	str r7, [r0, #8]
	ldmia r5!, {r0, r1}
	add r2, sp, #0x10
	stmia r2!, {r0, r1}
	ldr r0, [r5]
	add r1, r3, #0
	str r0, [r2]
	str r7, [sp]
	sub r0, r7, #1
	str r0, [sp, #4]
	str r7, [sp, #8]
	add r0, r4, #0
	add r2, r7, #0
	add r3, r7, #0
	str r6, [sp, #0xc]
	bl ov02_0224A33C
	add r4, r0, #0
	mov r1, #2
	bl Sprite_SetAffineOverwriteMode
	add r0, r4, #0
	add r1, sp, #0x1c
	bl Sprite_SetAffineMatrix
	add r0, r4, #0
	add r1, sp, #0x10
	bl Sprite_SetAffineScale
	add r0, r7, #0
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	add r0, r4, #0
	add sp, #0x28
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224A4CC: .word ov02_02253390
	thumb_func_end ov02_0224A468

	thumb_func_start ov02_0224A4D0
ov02_0224A4D0: ; 0x0224A4D0
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	add r4, r0, #0
	bl ov02_0224A074
	add r6, r0, #0
	mov r0, #0x6b
	mov r5, #0
	add r2, r4, #0
	lsl r0, r0, #2
_0224A4E4:
	ldr r1, [r2, r0]
	cmp r1, #0
	bne _0224A510
	mov r3, #0
	str r3, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0x67
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, r6, #0
	mov r2, #0xb
	bl AddCharResObjFromOpenNarc
	lsl r1, r5, #2
	add r2, r4, r1
	mov r1, #0x6b
	lsl r1, r1, #2
	str r0, [r2, r1]
	b _0224A518
_0224A510:
	add r5, r5, #1
	add r2, r2, #4
	cmp r5, #4
	blt _0224A4E4
_0224A518:
	cmp r5, #4
	blt _0224A520
	bl GF_AssertFail
_0224A520:
	mov r0, #0x72
	mov r5, #0
	add r2, r4, #0
	lsl r0, r0, #2
_0224A528:
	ldr r1, [r2, r0]
	cmp r1, #0
	bne _0224A554
	mov r3, #0
	str r3, [sp]
	mov r0, #2
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0x69
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, r6, #0
	mov r2, #0xc
	bl AddCellOrAnimResObjFromOpenNarc
	lsl r1, r5, #2
	add r2, r4, r1
	mov r1, #0x72
	lsl r1, r1, #2
	str r0, [r2, r1]
	b _0224A55C
_0224A554:
	add r5, r5, #1
	add r2, r2, #4
	cmp r5, #4
	blt _0224A528
_0224A55C:
	cmp r5, #4
	blt _0224A564
	bl GF_AssertFail
_0224A564:
	add r0, r6, #0
	bl NARC_Delete
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A4D0

	thumb_func_start ov02_0224A570
ov02_0224A570: ; 0x0224A570
	push {r3, r4, r5, lr}
	add r5, r2, #0
	mov r2, #4
	bl NARC_AllocAndReadWholeMember
	add r1, r5, #0
	add r4, r0, #0
	bl NNS_G2dGetUnpackedPaletteData
	ldr r1, [r5]
	mov r0, #3
	ldr r1, [r1, #0xc]
	mov r2, #0x20
	lsl r3, r0, #7
	bl BG_LoadPlttData
	add r0, r4, #0
	bl Heap_Free
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224A570

	thumb_func_start ov02_0224A598
ov02_0224A598: ; 0x0224A598
	push {r3, r4, r5, r6, lr}
	sub sp, #4
	add r5, r0, #0
	add r0, r1, #0
	add r1, r2, #0
	add r4, r3, #0
	mov r2, #4
	bl NARC_AllocAndReadWholeMember
	add r1, r4, #0
	add r6, r0, #0
	bl NNS_G2dGetUnpackedCharacterData
	ldr r3, [r4]
	mov r0, #0
	str r0, [sp]
	ldr r2, [r3, #0x14]
	ldr r3, [r3, #0x10]
	add r0, r5, #0
	mov r1, #3
	bl BG_LoadCharTilesData
	add r0, r6, #0
	bl Heap_Free
	add sp, #4
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A598

	thumb_func_start ov02_0224A5D0
ov02_0224A5D0: ; 0x0224A5D0
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r7, r2, #0
	add r6, r1, #0
	mov r2, #0
	add r4, r3, #0
	mov r1, #3
	add r3, r2, #0
	add r5, r0, #0
	bl BgSetPosTextAndCommit
	mov r1, #3
	add r0, r5, #0
	add r2, r1, #0
	mov r3, #0
	bl BgSetPosTextAndCommit
	add r0, r6, #0
	add r1, r7, #0
	mov r2, #4
	bl NARC_AllocAndReadWholeMember
	add r1, r4, #0
	add r6, r0, #0
	bl NNS_G2dGetUnpackedScreenData
	ldr r3, [r4]
	add r0, r5, #0
	add r2, r3, #0
	ldr r3, [r3, #8]
	mov r1, #3
	add r2, #0xc
	bl BG_LoadScreenTilemapData
	mov r0, #0x20
	str r0, [sp]
	str r0, [sp, #4]
	mov r0, #0xc
	mov r2, #0
	str r0, [sp, #8]
	add r0, r5, #0
	mov r1, #3
	add r3, r2, #0
	bl BgTilemapRectChangePalette
	add r0, r5, #0
	mov r1, #3
	bl BgCommitTilemapBufferToVram
	add r0, r6, #0
	bl Heap_Free
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224A5D0

	thumb_func_start ov02_0224A63C
ov02_0224A63C: ; 0x0224A63C
	ldr r3, _0224A644 ; =BgClearTilemapBufferAndCommit
	mov r1, #3
	bx r3
	nop
_0224A644: .word BgClearTilemapBufferAndCommit
	thumb_func_end ov02_0224A63C

	thumb_func_start ov02_0224A648
ov02_0224A648: ; 0x0224A648
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224A6A8
	mov r0, #0
	str r0, [r4, #0x2c]
	add r0, r4, #0
	bl ov02_0224A674
	add r0, r4, #0
	bl ov02_0224A67C
	add r0, r4, #0
	bl ov02_0224A66C
	mov r0, #1
	str r0, [r4, #0x2c]
	pop {r4, pc}
	thumb_func_end ov02_0224A648

	thumb_func_start ov02_0224A66C
ov02_0224A66C: ; 0x0224A66C
	mov r1, #1
	str r1, [r0, #0x30]
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224A66C

	thumb_func_start ov02_0224A674
ov02_0224A674: ; 0x0224A674
	mov r1, #0
	str r1, [r0, #0x30]
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224A674

	thumb_func_start ov02_0224A67C
ov02_0224A67C: ; 0x0224A67C
	mov r1, #0x18
	str r1, [r0, #0x34]
	mov r1, #0
	str r1, [r0, #0x38]
	mov r1, #0x17
	str r1, [r0, #0x3c]
	mov r1, #1
	str r1, [r0, #0x40]
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224A67C

	thumb_func_start ov02_0224A690
ov02_0224A690: ; 0x0224A690
	mov r1, #0x17
	str r1, [r0, #0x3c]
	mov r1, #1
	str r1, [r0, #0x40]
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224A690

	thumb_func_start ov02_0224A69C
ov02_0224A69C: ; 0x0224A69C
	str r1, [r0, #0x44]
	str r3, [r0, #0x48]
	ldr r1, [sp]
	str r2, [r0, #0x4c]
	str r1, [r0, #0x50]
	bx lr
	thumb_func_end ov02_0224A69C

	thumb_func_start ov02_0224A6A8
ov02_0224A6A8: ; 0x0224A6A8
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x89
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	cmp r0, #0
	beq _0224A6BA
	bl GF_AssertFail
_0224A6BA:
	ldr r0, _0224A6CC ; =ov02_0224A700
	add r1, r4, #0
	mov r2, #0x81
	bl SysTask_CreateOnVBlankQueue
	mov r1, #0x89
	lsl r1, r1, #2
	str r0, [r4, r1]
	pop {r4, pc}
	.balign 4, 0
_0224A6CC: .word ov02_0224A700
	thumb_func_end ov02_0224A6A8

	thumb_func_start ov02_0224A6D0
ov02_0224A6D0: ; 0x0224A6D0
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x89
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	cmp r0, #0
	bne _0224A6E2
	bl GF_AssertFail
_0224A6E2:
	mov r0, #0x89
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl SysTask_Destroy
	mov r2, #1
	lsl r2, r2, #0x1a
	ldr r1, [r2]
	ldr r0, _0224A6FC ; =0xFFFF1FFF
	and r0, r1
	str r0, [r2]
	pop {r4, pc}
	nop
_0224A6FC: .word 0xFFFF1FFF
	thumb_func_end ov02_0224A6D0

	thumb_func_start ov02_0224A700
ov02_0224A700: ; 0x0224A700
	push {r3, r4, r5, r6}
	ldr r0, [r1, #0x2c]
	cmp r0, #0
	beq _0224A796
	mov r3, #1
	lsl r3, r3, #0x1a
	ldr r2, [r3]
	ldr r0, _0224A79C ; =0xFFFF1FFF
	and r2, r0
	ldr r0, [r1, #0x30]
	lsl r0, r0, #0xd
	orr r0, r2
	str r0, [r3]
	add r3, #0x48
	ldrh r2, [r3]
	mov r0, #0x3f
	bic r2, r0
	ldr r0, [r1, #0x34]
	orr r2, r0
	ldr r0, [r1, #0x38]
	cmp r0, #0
	beq _0224A730
	mov r0, #0x20
	orr r2, r0
_0224A730:
	ldr r0, _0224A7A0 ; =0x04000048
	strh r2, [r0]
	ldrh r2, [r0, #2]
	mov r0, #0x3f
	bic r2, r0
	ldr r0, [r1, #0x3c]
	orr r2, r0
	ldr r0, [r1, #0x40]
	cmp r0, #0
	beq _0224A748
	mov r0, #0x20
	orr r2, r0
_0224A748:
	ldr r5, _0224A7A4 ; =0x0400004A
	strh r2, [r5]
	ldr r2, [r1, #0x50]
	ldr r6, [r1, #0x48]
	asr r0, r2, #0xb
	lsr r0, r0, #0x14
	add r0, r2, r0
	ldr r2, [r1, #0x4c]
	asr r4, r0, #0xc
	asr r0, r2, #0xb
	lsr r0, r0, #0x14
	add r0, r2, r0
	ldr r2, [r1, #0x44]
	asr r3, r0, #0xc
	asr r0, r2, #0xb
	lsr r0, r0, #0x14
	asr r1, r6, #0xb
	add r0, r2, r0
	lsr r1, r1, #0x14
	asr r0, r0, #0xc
	add r1, r6, r1
	lsl r2, r0, #8
	mov r0, #0xff
	asr r1, r1, #0xc
	lsl r0, r0, #8
	lsl r1, r1, #0x18
	and r2, r0
	lsr r1, r1, #0x18
	orr r2, r1
	add r1, r5, #0
	sub r1, #0xa
	strh r2, [r1]
	lsl r1, r3, #8
	and r1, r0
	lsl r0, r4, #0x18
	lsr r0, r0, #0x18
	orr r1, r0
	sub r0, r5, #6
	strh r1, [r0]
_0224A796:
	pop {r3, r4, r5, r6}
	bx lr
	nop
_0224A79C: .word 0xFFFF1FFF
_0224A7A0: .word 0x04000048
_0224A7A4: .word 0x0400004A
	thumb_func_end ov02_0224A700

	thumb_func_start ov02_0224A7A8
ov02_0224A7A8: ; 0x0224A7A8
	ldr r3, _0224A7B4 ; =GetPokemonSpriteCharAndPlttNarcIds
	add r2, r0, #0
	add r0, r1, #0
	ldr r1, [r2, #0x5c]
	mov r2, #2
	bx r3
	.balign 4, 0
_0224A7B4: .word GetPokemonSpriteCharAndPlttNarcIds
	thumb_func_end ov02_0224A7A8

	thumb_func_start ov02_0224A7B8
ov02_0224A7B8: ; 0x0224A7B8
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x10
	add r5, r1, #0
	mov r1, #0x32
	add r6, r0, #0
	mov r0, #4
	lsl r1, r1, #6
	add r7, r2, #0
	bl Heap_Alloc
	add r4, r0, #0
	bne _0224A7D4
	bl GF_AssertFail
_0224A7D4:
	mov r1, #0
	add r0, r6, #0
	add r2, r1, #0
	bl GetMonData
	str r0, [sp]
	mov r0, #0
	str r0, [sp, #4]
	mov r0, #2
	str r0, [sp, #8]
	ldrh r0, [r5, #6]
	add r2, r7, #0
	add r3, r4, #0
	str r0, [sp, #0xc]
	ldrh r0, [r5]
	ldrh r1, [r5, #2]
	bl sub_02014540
	add r0, r4, #0
	add sp, #0x10
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A7B8

	thumb_func_start ov02_0224A800
ov02_0224A800: ; 0x0224A800
	add r3, r0, #0
	add r2, r1, #0
	ldrh r0, [r3]
	ldrh r1, [r3, #4]
	ldr r3, _0224A80C ; =sub_02014450
	bx r3
	.balign 4, 0
_0224A80C: .word sub_02014450
	thumb_func_end ov02_0224A800

	thumb_func_start ov02_0224A810
ov02_0224A810: ; 0x0224A810
	push {lr}
	sub sp, #0xc
	mov r2, #3
	str r2, [sp]
	mov r2, #1
	str r2, [sp, #4]
	mov r2, #4
	str r2, [sp, #8]
	mov r2, #0x67
	lsl r2, r2, #2
	ldr r0, [r0, r2]
	mov r2, #9
	mov r3, #0
	bl AddCharResObjFromOpenNarc
	add sp, #0xc
	pop {pc}
	.balign 4, 0
	thumb_func_end ov02_0224A810

	thumb_func_start ov02_0224A834
ov02_0224A834: ; 0x0224A834
	push {r3, r4, r5, lr}
	add r4, r1, #0
	mov r1, #0x67
	lsl r1, r1, #2
	ldr r0, [r0, r1]
	mov r1, #3
	bl SpriteResourceCollection_Find
	bl SpriteTransfer_GetCharProxy
	mov r1, #1
	bl NNS_G2dGetImageLocation
	mov r1, #0x32
	add r5, r0, #0
	add r0, r4, #0
	lsl r1, r1, #6
	bl DC_FlushRange
	mov r2, #0x32
	add r0, r4, #0
	add r1, r5, #0
	lsl r2, r2, #6
	bl GX_LoadOBJ
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224A834

	thumb_func_start ov02_0224A868
ov02_0224A868: ; 0x0224A868
	push {r3, lr}
	sub sp, #0x10
	mov r2, #3
	str r2, [sp]
	mov r2, #1
	str r2, [sp, #4]
	str r2, [sp, #8]
	mov r2, #4
	str r2, [sp, #0xc]
	mov r2, #0x1a
	lsl r2, r2, #4
	ldr r0, [r0, r2]
	mov r2, #6
	mov r3, #0
	bl AddPlttResObjFromOpenNarc
	add sp, #0x10
	pop {r3, pc}
	thumb_func_end ov02_0224A868

	thumb_func_start ov02_0224A88C
ov02_0224A88C: ; 0x0224A88C
	push {r4, r5, r6, lr}
	add r5, r0, #0
	mov r0, #0x67
	lsl r0, r0, #2
	add r4, r1, #0
	ldr r0, [r5, r0]
	mov r1, #3
	bl SpriteResourceCollection_Find
	bl SpriteTransfer_GetCharProxy
	add r6, r0, #0
	mov r0, #0x1a
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	mov r1, #3
	bl SpriteResourceCollection_Find
	add r1, r6, #0
	bl SpriteTransfer_GetPaletteProxy
	mov r1, #1
	bl NNS_G2dGetImagePaletteLocation
	add r5, r0, #0
	add r0, r4, #0
	mov r1, #0x20
	bl DC_FlushRange
	add r0, r4, #0
	add r1, r5, #0
	mov r2, #0x20
	bl GX_LoadOBJPltt
	pop {r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A88C

	thumb_func_start ov02_0224A8D4
ov02_0224A8D4: ; 0x0224A8D4
	push {r3, r4, r5, lr}
	add r5, r0, #0
	mov r0, #0x67
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	mov r1, #3
	bl SpriteResourceCollection_Find
	add r4, r0, #0
	bl SpriteTransfer_DeleteCharTransferTask
	mov r0, #0x67
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	add r1, r4, #0
	bl DestroySingle2DGfxResObj
	mov r1, #0x6b
	mov r0, #0
	add r3, r5, #0
	lsl r1, r1, #2
_0224A8FE:
	ldr r2, [r3, r1]
	cmp r2, r4
	bne _0224A912
	lsl r1, r0, #2
	add r2, r5, r1
	mov r1, #0x6b
	mov r3, #0
	lsl r1, r1, #2
	str r3, [r2, r1]
	b _0224A91A
_0224A912:
	add r0, r0, #1
	add r3, r3, #4
	cmp r0, #4
	blt _0224A8FE
_0224A91A:
	cmp r0, #4
	blt _0224A922
	bl GF_AssertFail
_0224A922:
	mov r0, #0x1a
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	mov r1, #3
	bl SpriteResourceCollection_Find
	add r4, r0, #0
	bl SpriteTransfer_DeletePlttTransferTask
	mov r0, #0x1a
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	add r1, r4, #0
	bl DestroySingle2DGfxResObj
	mov r1, #0x6f
	mov r0, #0
	add r3, r5, #0
	lsl r1, r1, #2
_0224A948:
	ldr r2, [r3, r1]
	cmp r2, r4
	bne _0224A95C
	lsl r1, r0, #2
	add r2, r5, r1
	mov r1, #0x6f
	mov r3, #0
	lsl r1, r1, #2
	str r3, [r2, r1]
	b _0224A964
_0224A95C:
	add r0, r0, #1
	add r3, r3, #4
	cmp r0, #3
	blt _0224A948
_0224A964:
	cmp r0, #3
	blt _0224A96C
	bl GF_AssertFail
_0224A96C:
	mov r0, #0x69
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	mov r1, #3
	bl SpriteResourceCollection_Find
	add r4, r0, #0
	bl sub_0200A740
	mov r0, #0x69
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	add r1, r4, #0
	bl DestroySingle2DGfxResObj
	mov r1, #0x72
	mov r0, #0
	add r3, r5, #0
	lsl r1, r1, #2
_0224A992:
	ldr r2, [r3, r1]
	cmp r2, r4
	bne _0224A9A6
	lsl r1, r0, #2
	add r2, r5, r1
	mov r1, #0x72
	mov r3, #0
	lsl r1, r1, #2
	str r3, [r2, r1]
	b _0224A9AE
_0224A9A6:
	add r0, r0, #1
	add r3, r3, #4
	cmp r0, #4
	blt _0224A992
_0224A9AE:
	cmp r0, #4
	blt _0224A9B6
	bl GF_AssertFail
_0224A9B6:
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224A8D4

	thumb_func_start ov02_0224A9B8
ov02_0224A9B8: ; 0x0224A9B8
	push {r3, lr}
	sub sp, #0x10
	mov r2, #3
	str r2, [sp]
	sub r3, r2, #4
	str r3, [sp, #4]
	mov r3, #0
	str r3, [sp, #8]
	mov r3, #0x81
	str r3, [sp, #0xc]
	add r3, r2, #0
	bl ov02_0224A33C
	add sp, #0x10
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224A9B8

	thumb_func_start ov02_0224A9D8
ov02_0224A9D8: ; 0x0224A9D8
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x28
	add r5, r0, #0
	mov r0, #2
	ldr r4, _0224AA40 ; =ov02_022535E4
	add r6, r1, #0
	str r0, [r5, #0x14]
	mov r7, #0
_0224A9E8:
	ldr r0, [r4]
	add r1, sp, #0x1c
	str r0, [sp, #0x1c]
	ldr r0, [r4, #4]
	add r2, sp, #0x10
	str r0, [sp, #0x20]
	mov r0, #0
	str r0, [sp, #0x24]
	ldr r0, [r4, #8]
	str r0, [sp, #0x10]
	mov r0, #0
	str r0, [sp, #0x14]
	str r0, [sp, #0x18]
	ldr r0, [r4, #0xc]
	str r0, [sp, #8]
	ldr r0, [r4, #0x10]
	ldr r3, [sp, #8]
	str r0, [sp]
	str r0, [sp, #0xc]
	str r6, [sp, #4]
	add r0, r5, #0
	bl ov02_0224AA44
	mov r0, #1
	ldr r1, [sp, #0x1c]
	lsl r0, r0, #0x14
	add r0, r1, r0
	str r0, [sp, #0x1c]
	ldr r0, [sp, #0xc]
	ldr r3, [sp, #8]
	str r0, [sp]
	add r0, r5, #0
	add r1, sp, #0x1c
	add r2, sp, #0x10
	str r6, [sp, #4]
	bl ov02_0224AA44
	add r7, r7, #1
	add r4, #0x14
	cmp r7, #0xd
	blt _0224A9E8
	add sp, #0x28
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224AA40: .word ov02_022535E4
	thumb_func_end ov02_0224A9D8

	thumb_func_start ov02_0224AA44
ov02_0224AA44: ; 0x0224AA44
	push {r3, r4, r5, lr}
	sub sp, #0x20
	add r5, r0, #0
	ldr r0, [sp, #0x34]
	str r3, [sp, #8]
	str r5, [sp, #0x10]
	add r4, r1, #0
	str r0, [sp, #0xc]
	ldmia r2!, {r0, r1}
	add r3, sp, #0x14
	stmia r3!, {r0, r1}
	ldr r0, [r2]
	ldr r1, _0224AA7C ; =ov02_02253468
	str r0, [r3]
	add r0, sp, #8
	str r0, [sp]
	mov r0, #0x85
	str r0, [sp, #4]
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	ldr r3, [sp, #0x30]
	add r2, r4, #0
	bl sub_02068B0C
	add sp, #0x20
	pop {r3, r4, r5, pc}
	nop
_0224AA7C: .word ov02_02253468
	thumb_func_end ov02_0224AA44

	thumb_func_start ov02_0224AA80
ov02_0224AA80: ; 0x0224AA80
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r1, #0
	add r5, r0, #0
	bl sub_02068D98
	add r2, r4, #0
	add r3, r0, #0
	add r2, #0xc
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	add r0, r5, #0
	bl sub_02068D90
	str r0, [r4, #4]
	add r0, r5, #0
	add r1, sp, #0
	bl sub_02068DB8
	ldr r0, [r4, #0x14]
	ldr r2, [r4, #0xc]
	ldr r3, [r4, #4]
	add r1, sp, #0
	bl ov02_0224A3F0
	mov r1, #0
	str r0, [r4, #8]
	bl Sprite_SetDrawFlag
	mov r0, #1
	add sp, #0xc
	pop {r4, r5, pc}
	thumb_func_end ov02_0224AA80

	thumb_func_start ov02_0224AAC8
ov02_0224AAC8: ; 0x0224AAC8
	ldr r3, _0224AAD0 ; =Sprite_Delete
	ldr r0, [r1, #8]
	bx r3
	nop
_0224AAD0: .word Sprite_Delete
	thumb_func_end ov02_0224AAC8

	thumb_func_start ov02_0224AAD4
ov02_0224AAD4: ; 0x0224AAD4
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	add r4, r1, #0
	add r1, sp, #0
	add r5, r0, #0
	bl sub_02068DB8
	ldr r1, [sp]
	ldr r0, [r4, #0x18]
	add r0, r1, r0
	lsr r2, r0, #0x1f
	lsl r1, r0, #0xb
	str r0, [sp]
	sub r1, r1, r2
	mov r0, #0xb
	ror r1, r0
	add r0, r2, r1
	str r0, [sp]
	add r0, r5, #0
	add r1, sp, #0
	bl sub_02068DA8
	ldr r0, [r4, #8]
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r0, [r4, #0x10]
	cmp r0, #1
	bne _0224AB4E
	ldr r3, [r4, #0x14]
	ldr r0, [r3, #0x14]
	cmp r0, #2
	bne _0224AB42
	ldr r2, [r3, #0x4c]
	ldr r0, [r3, #0x50]
	mov r3, #2
	ldr r6, [sp, #4]
	lsl r3, r3, #0xc
	sub r5, r6, r3
	mov r1, #0
	cmp r5, r2
	blt _0224AB38
	cmp r5, r0
	bgt _0224AB38
	add r3, r6, r3
	cmp r3, r2
	blt _0224AB38
	cmp r3, r0
	bgt _0224AB38
	mov r1, #1
_0224AB38:
	ldr r0, [r4, #8]
	bl Sprite_SetDrawFlag
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
_0224AB42:
	cmp r0, #1
	bne _0224AB4E
	ldr r0, [r4, #8]
	mov r1, #0
	bl Sprite_SetDrawFlag
_0224AB4E:
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224AAD4

	thumb_func_start ov02_0224AB54
ov02_0224AB54: ; 0x0224AB54
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224AB54

	thumb_func_start ov02_0224AB58
ov02_0224AB58: ; 0x0224AB58
	push {r4, lr}
	sub sp, #0x18
	add r2, sp, #0xc
	mov r3, #0
	add r4, r0, #0
	str r3, [r2]
	str r3, [r2, #4]
	str r3, [r2, #8]
	str r4, [sp, #8]
	add r0, sp, #8
	str r0, [sp]
	mov r0, #0x82
	str r0, [sp, #4]
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	ldr r1, _0224AB88 ; =ov02_0225347C
	bl sub_02068B0C
	mov r1, #0x7b
	lsl r1, r1, #2
	str r0, [r4, r1]
	add sp, #0x18
	pop {r4, pc}
	.balign 4, 0
_0224AB88: .word ov02_0225347C
	thumb_func_end ov02_0224AB58

	thumb_func_start ov02_0224AB8C
ov02_0224AB8C: ; 0x0224AB8C
	push {r3, lr}
	mov r1, #0x7b
	lsl r1, r1, #2
	ldr r0, [r0, r1]
	bl sub_02068D74
	ldrb r0, [r0, #2]
	pop {r3, pc}
	thumb_func_end ov02_0224AB8C

	thumb_func_start ov02_0224AB9C
ov02_0224AB9C: ; 0x0224AB9C
	push {r3, r4, r5, lr}
	add r4, r0, #0
	mov r0, #0x7b
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl sub_02068D74
	add r5, r0, #0
	ldr r0, [r5, #0x60]
	cmp r0, #0
	beq _0224ABB6
	bl sub_02068B48
_0224ABB6:
	ldr r0, [r5, #0x64]
	cmp r0, #0
	beq _0224ABC0
	bl ov01_021FCD78
_0224ABC0:
	mov r0, #0x7b
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl sub_02068B48
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224AB9C

	thumb_func_start ov02_0224ABCC
ov02_0224ABCC: ; 0x0224ABCC
	push {r4, r5, lr}
	sub sp, #0xc
	add r5, r0, #0
	add r4, r1, #0
	bl sub_02068D98
	ldr r0, [r0]
	add r1, sp, #0
	str r0, [r4, #0x5c]
	add r0, r5, #0
	bl sub_02068DB8
	mov r2, #0
	ldr r0, [r4, #0x5c]
	add r1, sp, #0
	add r3, r2, #0
	bl ov02_0224A468
	str r0, [r4, #0x58]
	mov r0, #1
	add sp, #0xc
	pop {r4, r5, pc}
	thumb_func_end ov02_0224ABCC

	thumb_func_start ov02_0224ABF8
ov02_0224ABF8: ; 0x0224ABF8
	ldr r3, _0224AC00 ; =Sprite_Delete
	ldr r0, [r1, #0x58]
	bx r3
	nop
_0224AC00: .word Sprite_Delete
	thumb_func_end ov02_0224ABF8

	thumb_func_start ov02_0224AC04
ov02_0224AC04: ; 0x0224AC04
	push {r3, r4, r5, lr}
	add r5, r1, #0
	ldrb r0, [r5]
	lsl r1, r0, #2
	ldr r0, _0224AC20 ; =ov02_022533C0
	ldr r4, [r0, r1]
_0224AC10:
	ldrb r1, [r5, #1]
	add r0, r5, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	blx r1
	cmp r0, #1
	beq _0224AC10
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224AC20: .word ov02_022533C0
	thumb_func_end ov02_0224AC04

	thumb_func_start ov02_0224AC24
ov02_0224AC24: ; 0x0224AC24
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224AC24

	thumb_func_start ov02_0224AC28
ov02_0224AC28: ; 0x0224AC28
	push {r3, lr}
	mov r1, #0
	strb r1, [r0, #2]
	ldr r0, [r0, #0x58]
	bl Sprite_SetDrawFlag
	mov r0, #0
	pop {r3, pc}
	thumb_func_end ov02_0224AC28

	thumb_func_start ov02_0224AC38
ov02_0224AC38: ; 0x0224AC38
	push {r4, r5, r6, lr}
	sub sp, #0x18
	ldr r4, _0224ACD8 ; =ov02_022533E4
	add r2, r0, #0
	ldmia r4!, {r0, r1}
	add r3, sp, #0xc
	stmia r3!, {r0, r1}
	ldr r0, [r4]
	ldr r4, _0224ACDC ; =ov02_022533F0
	str r0, [r3]
	ldmia r4!, {r0, r1}
	add r3, sp, #0
	stmia r3!, {r0, r1}
	ldr r0, [r4]
	str r0, [r3]
	mov r0, #0x7b
	lsl r0, r0, #2
	ldr r0, [r2, r0]
	bl sub_02068D74
	add r4, r0, #0
	mov r3, #1
	add r5, r4, #0
	strb r3, [r4]
	mov r2, #0
	strb r2, [r4, #1]
	strb r2, [r4, #2]
	add r6, sp, #0xc
	ldmia r6!, {r0, r1}
	add r5, #8
	stmia r5!, {r0, r1}
	ldr r0, [r6]
	add r6, sp, #0
	str r0, [r5]
	str r2, [r4, #0x14]
	str r2, [r4, #0x18]
	mov r0, #0xf
	add r5, r4, #0
	str r2, [r4, #0x1c]
	lsl r0, r0, #0xe
	str r0, [r4, #0x38]
	ldmia r6!, {r0, r1}
	add r5, #0x2c
	stmia r5!, {r0, r1}
	ldr r0, [r6]
	add r1, sp, #0xc
	str r0, [r5]
	lsl r0, r3, #9
	str r0, [r4, #0x50]
	mov r0, #0x2d
	lsl r0, r0, #0xe
	str r0, [r4, #0x40]
	str r2, [r4, #0x48]
	lsl r0, r3, #0xd
	str r0, [r4, #0x4c]
	ldr r0, [r4, #0x58]
	bl Sprite_SetMatrix
	ldr r0, [r4, #0x58]
	add r1, sp, #0
	bl Sprite_SetAffineScale
	ldr r1, [r4, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	ldr r0, [r4, #0x58]
	bl Sprite_SetAffineZRotation
	ldr r0, [r4, #0x58]
	mov r1, #1
	bl Sprite_SetDrawFlag
	add sp, #0x18
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224ACD8: .word ov02_022533E4
_0224ACDC: .word ov02_022533F0
	thumb_func_end ov02_0224AC38

	thumb_func_start ov02_0224ACE0
ov02_0224ACE0: ; 0x0224ACE0
	push {r4, r5, lr}
	sub sp, #0xc
	add r5, r0, #0
	ldr r1, [r5, #0x48]
	ldr r0, [r5, #0x4c]
	ldr r4, [r5, #0x58]
	add r0, r1, r0
	str r0, [r5, #0x48]
	mov r0, #1
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0x10
	cmp r1, r0
	bge _0224AD00
	lsr r0, r0, #2
	add r0, r1, r0
	str r0, [r5, #0x4c]
_0224AD00:
	ldr r0, _0224ADE0 ; =0x0000013B
	bl GF_CosDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x14]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_SinDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x18]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r2, r0, #0xc
	ldr r0, _0224ADE4 ; =0x0000010E
	cmp r2, r0
	bge _0224AD4A
	mov r0, #1
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [r5, #0x40]
_0224AD4A:
	ldr r1, [r5, #0x2c]
	ldr r0, [r5, #0x50]
	add r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xc
	str r1, [r5, #0x2c]
	cmp r1, r0
	ble _0224AD5C
	str r0, [r5, #0x2c]
_0224AD5C:
	ldr r1, [r5, #0x30]
	ldr r0, [r5, #0x50]
	add r1, r1, r0
	mov r0, #1
	lsl r0, r0, #0xc
	str r1, [r5, #0x30]
	cmp r1, r0
	ble _0224AD6E
	str r0, [r5, #0x30]
_0224AD6E:
	add r1, r5, #0
	add r0, r4, #0
	add r1, #0x2c
	bl Sprite_SetAffineScale
	mov r0, #6
	ldr r1, [r5, #0x38]
	lsl r0, r0, #0xc
	sub r1, r1, r0
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	str r1, [r5, #0x38]
	asr r0, r0, #0xc
	bpl _0224AD90
	mov r0, #0
	str r0, [r5, #0x38]
_0224AD90:
	ldr r1, [r5, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	ldr r1, [r5, #8]
	ldr r0, [r5, #0x14]
	add r0, r1, r0
	str r0, [sp]
	ldr r1, [r5, #0xc]
	ldr r0, [r5, #0x18]
	add r0, r1, r0
	str r0, [sp, #4]
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r1, [sp, #4]
	ldr r0, _0224ADE8 ; =0xFFFC0000
	cmp r1, r0
	bge _0224ADDA
	add r0, r4, #0
	mov r1, #0
	bl Sprite_SetDrawFlag
	mov r0, #2
	strb r0, [r5, #2]
	ldrb r0, [r5, #1]
	add r0, r0, #1
	strb r0, [r5, #1]
_0224ADDA:
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	.balign 4, 0
_0224ADE0: .word 0x0000013B
_0224ADE4: .word 0x0000010E
_0224ADE8: .word 0xFFFC0000
	thumb_func_end ov02_0224ACE0

	thumb_func_start ov02_0224ADEC
ov02_0224ADEC: ; 0x0224ADEC
	mov r0, #0
	bx lr
	thumb_func_end ov02_0224ADEC

	thumb_func_start ov02_0224ADF0
ov02_0224ADF0: ; 0x0224ADF0
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x30
	ldr r3, _0224AF5C ; =ov02_02253354
	add r5, r0, #0
	ldmia r3!, {r0, r1}
	add r2, sp, #0x24
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	ldr r3, _0224AF60 ; =ov02_0225336C
	str r0, [r2]
	ldmia r3!, {r0, r1}
	add r2, sp, #0x18
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	mov r0, #0x7b
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl sub_02068D74
	add r4, r0, #0
	mov r0, #2
	strb r0, [r4]
	mov r6, #0
	mov r0, #0xbb
	strb r6, [r4, #1]
	mov r7, #1
	strb r7, [r4, #2]
	str r6, [r4, #4]
	lsl r0, r0, #2
	ldr r1, [r5, r0]
	ldr r2, [sp, #0x24]
	add r0, #8
	add r1, r2, r1
	str r1, [sp, #0x24]
	add r2, r4, #0
	ldr r1, [sp, #0x28]
	ldr r0, [r5, r0]
	add r3, sp, #0x24
	add r0, r1, r0
	str r0, [sp, #0x28]
	ldmia r3!, {r0, r1}
	add r2, #8
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	add r3, sp, #0x18
	str r0, [r2]
	str r6, [r4, #0x14]
	str r6, [r4, #0x18]
	str r6, [r4, #0x1c]
	ldr r6, _0224AF64 ; =0x0013B000
	add r2, r4, #0
	str r6, [r4, #0x38]
	ldmia r3!, {r0, r1}
	add r2, #0x2c
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	add r0, r7, #0
	add r0, #0xff
	str r0, [r4, #0x50]
	mov r0, #0xe1
	lsl r0, r0, #0xc
	str r0, [r4, #0x40]
	mov r0, #3
	lsl r0, r0, #0x12
	str r0, [r4, #0x48]
	lsl r0, r7, #0x11
	str r0, [r4, #0x4c]
	lsr r0, r6, #0xc
	bl GF_CosDeg
	ldr r2, [r4, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r4, #0x14]
	ldr r1, [r4, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_SinDeg
	ldr r2, [r4, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r4, #0x18]
	ldr r1, [r4, #8]
	ldr r0, [r4, #0x14]
	add r0, r1, r0
	str r0, [sp, #0x24]
	ldr r1, [r4, #0xc]
	ldr r0, [r4, #0x18]
	add r0, r1, r0
	str r0, [sp, #0x28]
	ldr r0, [r4, #0x58]
	add r1, sp, #0x24
	bl Sprite_SetMatrix
	ldr r0, [r4, #0x58]
	add r1, sp, #0x18
	bl Sprite_SetAffineScale
	ldr r1, [r4, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	ldr r0, [r4, #0x58]
	bl Sprite_SetAffineZRotation
	ldr r0, [r4, #0x58]
	add r1, r7, #0
	bl Sprite_SetDrawFlag
	mov r1, #0x1e
	lsl r1, r1, #4
	ldr r0, [r5, r1]
	add r1, r1, #4
	ldr r1, [r5, r1]
	bl ov02_0224B298
	str r0, [r4, #0x60]
	add r0, r7, #0
	str r0, [r5, #0x1c]
	ldr r0, [r5, #0x60]
	mov r1, #4
	bl ov01_021FCD2C
	ldr r2, _0224AF68 ; =0xFFF88000
	add r1, r7, #0
	mov r3, #0xc
	str r0, [r4, #0x64]
	bl ov01_021FCD8C
	add r1, sp, #0xc
	mov r0, #0
	str r0, [r1]
	str r0, [r1, #4]
	ldr r3, _0224AF6C ; =ov02_02253378
	str r0, [r1, #8]
	ldmia r3!, {r0, r1}
	add r2, sp, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	mov r0, #0x79
	ldr r1, [r4, #0x5c]
	lsl r0, r0, #2
	ldr r4, [r1, r0]
	mov r1, #2
	add r0, r4, #0
	bl Sprite_SetAffineOverwriteMode
	add r0, r4, #0
	add r1, sp, #0xc
	bl Sprite_SetAffineMatrix
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetAffineScale
	mov r0, #0
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	add sp, #0x30
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224AF5C: .word ov02_02253354
_0224AF60: .word ov02_0225336C
_0224AF64: .word 0x0013B000
_0224AF68: .word 0xFFF88000
_0224AF6C: .word ov02_02253378
	thumb_func_end ov02_0224ADF0

	thumb_func_start ov02_0224AF70
ov02_0224AF70: ; 0x0224AF70
	push {r3, r4, r5, lr}
	sub sp, #0x18
	add r5, r0, #0
	ldr r1, [r5, #0x48]
	ldr r0, [r5, #0x4c]
	ldr r4, [r5, #0x58]
	sub r0, r1, r0
	str r0, [r5, #0x48]
	bpl _0224AF86
	mov r0, #0
	str r0, [r5, #0x48]
_0224AF86:
	mov r0, #2
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0xa
	cmp r1, r0
	ble _0224AF98
	mov r0, #6
	lsl r0, r0, #0xa
	sub r0, r1, r0
	str r0, [r5, #0x4c]
_0224AF98:
	mov r0, #1
	ldr r1, [r5, #0x4c]
	lsl r0, r0, #0xc
	cmp r1, r0
	bge _0224AFA4
	str r0, [r5, #0x4c]
_0224AFA4:
	ldr r0, _0224B0D8 ; =0x0000013B
	bl GF_CosDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x14]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_SinDeg
	ldr r2, [r5, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r5, #0x18]
	ldr r1, [r5, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r2, r0, #0xc
	ldr r0, _0224B0DC ; =0x0000010E
	cmp r2, r0
	bge _0224AFEE
	mov r0, #1
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [r5, #0x40]
_0224AFEE:
	ldr r1, [r5, #0x2c]
	ldr r0, [r5, #0x50]
	add r1, r1, r0
	mov r0, #6
	lsl r0, r0, #0xa
	str r1, [r5, #0x2c]
	cmp r1, r0
	ble _0224B000
	str r0, [r5, #0x2c]
_0224B000:
	ldr r1, [r5, #0x30]
	ldr r0, [r5, #0x50]
	add r1, r1, r0
	mov r0, #6
	lsl r0, r0, #0xa
	str r1, [r5, #0x30]
	cmp r1, r0
	ble _0224B012
	str r0, [r5, #0x30]
_0224B012:
	add r1, r5, #0
	add r0, r4, #0
	add r1, #0x2c
	bl Sprite_SetAffineScale
	mov r0, #2
	ldr r1, [r5, #0x38]
	lsl r0, r0, #0xe
	add r1, r1, r0
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	str r1, [r5, #0x38]
	asr r1, r0, #0xc
	mov r0, #0x5a
	lsl r0, r0, #2
	cmp r1, r0
	ble _0224B03A
	lsl r0, r0, #0xc
	str r0, [r5, #0x38]
_0224B03A:
	ldr r1, [r5, #0x38]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_DegreeToSinCosIdx
	add r1, r0, #0
	add r0, r4, #0
	bl Sprite_SetAffineZRotation
	ldr r1, [r5, #8]
	ldr r0, [r5, #0x14]
	add r0, r1, r0
	str r0, [sp, #0xc]
	ldr r1, [r5, #0xc]
	ldr r0, [r5, #0x18]
	add r0, r1, r0
	str r0, [sp, #0x10]
	add r0, r4, #0
	add r1, sp, #0xc
	bl Sprite_SetMatrix
	ldr r0, [r5, #0x48]
	cmp r0, #0
	bne _0224B07C
	mov r0, #0
	str r0, [r5, #4]
	ldrb r0, [r5, #1]
	add r0, r0, #1
	strb r0, [r5, #1]
	b _0224B082
_0224B07C:
	ldr r0, [r5, #4]
	add r0, r0, #1
	str r0, [r5, #4]
_0224B082:
	ldr r0, [r5, #4]
	cmp r0, #0xc
	bne _0224B08E
	ldr r0, [r5, #0x60]
	bl ov02_0224B2CC
_0224B08E:
	mov r0, #0x79
	ldr r1, [r5, #0x5c]
	lsl r0, r0, #2
	ldr r4, [r1, r0]
	add r0, r4, #0
	bl Sprite_GetScalePtr
	add r3, r0, #0
	ldmia r3!, {r0, r1}
	add r2, sp, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r1, [sp]
	mov r0, #5
	add r1, #0x80
	lsl r0, r0, #0xa
	str r1, [sp]
	cmp r1, r0
	ble _0224B0B8
	str r0, [sp]
_0224B0B8:
	ldr r1, [sp, #4]
	mov r0, #5
	add r1, #0x80
	lsl r0, r0, #0xa
	str r1, [sp, #4]
	cmp r1, r0
	ble _0224B0C8
	str r0, [sp, #4]
_0224B0C8:
	add r0, r4, #0
	add r1, sp, #0
	bl Sprite_SetAffineScale
	mov r0, #0
	add sp, #0x18
	pop {r3, r4, r5, pc}
	nop
_0224B0D8: .word 0x0000013B
_0224B0DC: .word 0x0000010E
	thumb_func_end ov02_0224AF70

	thumb_func_start ov02_0224B0E0
ov02_0224B0E0: ; 0x0224B0E0
	push {r3, r4, r5, lr}
	add r4, r0, #0
	mov r0, #0x79
	ldr r1, [r4, #0x5c]
	lsl r0, r0, #2
	ldr r5, [r1, r0]
	mov r1, #3
	add r0, r5, #0
	bl Sprite_SetAnimCtrlSeq
	add r0, r5, #0
	mov r1, #1
	bl Sprite_SetDrawFlag
	ldr r0, [r4, #0x5c]
	mov r1, #1
	bl ov02_0224B6B0
	mov r0, #0x82
	ldr r1, [r4, #0x5c]
	lsl r0, r0, #2
	ldr r0, [r1, r0]
	bl sub_0205F484
	add r0, r5, #0
	bl Sprite_GetMatrixPtr
	ldr r5, [r0, #4]
	ldr r0, [r4, #0x58]
	bl Sprite_GetMatrixPtr
	ldr r0, [r0, #4]
	sub r0, r5, r0
	str r0, [r4, #0x54]
	ldr r0, [r4, #0x60]
	bl ov02_0224B2C0
	ldr r0, [r4, #0x64]
	mov r1, #2
	mov r2, #0
	mov r3, #0xc
	bl ov01_021FCD8C
	mov r1, #1
	lsl r1, r1, #8
	str r1, [r4, #0x50]
	lsl r0, r1, #0xb
	str r0, [r4, #0x40]
	mov r0, #0
	str r0, [r4, #0x48]
	lsl r0, r1, #3
	str r0, [r4, #0x4c]
	mov r0, #3
	strb r0, [r4, #2]
	ldrb r0, [r4, #1]
	add r0, r0, #1
	strb r0, [r4, #1]
	mov r0, #1
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B0E0

	thumb_func_start ov02_0224B158
ov02_0224B158: ; 0x0224B158
	push {r4, r5, r6, r7, lr}
	sub sp, #0x24
	add r4, r0, #0
	ldr r1, [r4, #0x48]
	ldr r0, [r4, #0x4c]
	ldr r6, [r4, #0x58]
	add r0, r1, r0
	str r0, [r4, #0x48]
	mov r0, #1
	ldr r1, [r4, #0x4c]
	lsl r0, r0, #0xc
	add r2, r1, r0
	lsl r1, r0, #4
	str r2, [r4, #0x4c]
	cmp r2, r1
	ble _0224B17C
	lsl r0, r0, #4
	str r0, [r4, #0x4c]
_0224B17C:
	ldr r1, [r4, #0x40]
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	lsl r0, r0, #4
	lsr r0, r0, #0x10
	bl GF_CosDeg
	ldr r2, [r4, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r4, #0x14]
	mov r0, #0x80
	bl GF_SinDeg
	ldr r2, [r4, #0x48]
	asr r1, r2, #0xb
	lsr r1, r1, #0x14
	add r1, r2, r1
	asr r1, r1, #0xc
	mul r0, r1
	str r0, [r4, #0x18]
	mov r0, #0x87
	ldr r1, [r4, #0x40]
	lsl r0, r0, #0xc
	cmp r1, r0
	bge _0224B1C0
	mov r0, #1
	lsl r0, r0, #0xc
	add r0, r1, r0
	str r0, [r4, #0x40]
_0224B1C0:
	ldr r1, [r4, #0x2c]
	ldr r0, [r4, #0x50]
	add r1, r1, r0
	mov r0, #2
	lsl r0, r0, #0xc
	str r1, [r4, #0x2c]
	cmp r1, r0
	ble _0224B1D2
	str r0, [r4, #0x2c]
_0224B1D2:
	ldr r1, [r4, #0x30]
	ldr r0, [r4, #0x50]
	add r1, r1, r0
	mov r0, #2
	lsl r0, r0, #0xc
	str r1, [r4, #0x30]
	cmp r1, r0
	ble _0224B1E4
	str r0, [r4, #0x30]
_0224B1E4:
	ldr r1, [r4, #8]
	ldr r0, [r4, #0x14]
	add r0, r1, r0
	str r0, [sp, #0x18]
	ldr r1, [r4, #0xc]
	ldr r0, [r4, #0x18]
	add r1, r1, r0
	asr r0, r1, #0xb
	lsr r0, r0, #0x14
	add r0, r1, r0
	asr r0, r0, #0xc
	str r1, [sp, #0x1c]
	cmp r0, #0xe6
	blt _0224B20A
	mov r0, #2
	strb r0, [r4, #2]
	ldrb r0, [r4, #1]
	add r0, r0, #1
	strb r0, [r4, #1]
_0224B20A:
	mov r0, #0x79
	ldr r1, [r4, #0x5c]
	lsl r0, r0, #2
	ldr r7, [r1, r0]
	add r0, r7, #0
	bl Sprite_GetScalePtr
	add r2, sp, #0xc
	add r3, sp, #0x18
	add r5, r0, #0
	ldmia r3!, {r0, r1}
	mov ip, r2
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldmia r5!, {r0, r1}
	add r2, sp, #0
	stmia r2!, {r0, r1}
	ldr r0, [r5]
	str r0, [r2]
	mov r0, #1
	ldr r1, [r4, #0x54]
	lsl r0, r0, #0xc
	sub r1, r1, r0
	str r1, [r4, #0x54]
	ldr r0, [sp, #0x10]
	add r0, r0, r1
	str r0, [sp, #0x10]
	add r0, r7, #0
	mov r1, ip
	bl Sprite_SetMatrix
	mov r0, #1
	ldr r1, [sp]
	lsl r0, r0, #8
	add r2, r1, r0
	lsl r1, r0, #5
	str r2, [sp]
	cmp r2, r1
	ble _0224B25E
	lsl r0, r0, #5
	str r0, [sp]
_0224B25E:
	mov r0, #1
	ldr r1, [sp, #4]
	lsl r0, r0, #8
	add r2, r1, r0
	lsl r1, r0, #5
	str r2, [sp, #4]
	cmp r2, r1
	ble _0224B272
	lsl r0, r0, #5
	str r0, [sp, #4]
_0224B272:
	add r0, r7, #0
	add r1, sp, #0
	bl Sprite_SetAffineScale
	add r4, #0x2c
	add r0, r6, #0
	add r1, r4, #0
	bl Sprite_SetAffineScale
	add r0, r6, #0
	add r1, sp, #0x18
	bl Sprite_SetMatrix
	mov r0, #0
	add sp, #0x24
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B158

	thumb_func_start ov02_0224B294
ov02_0224B294: ; 0x0224B294
	mov r0, #0
	bx lr
	thumb_func_end ov02_0224B294

	thumb_func_start ov02_0224B298
ov02_0224B298: ; 0x0224B298
	push {lr}
	sub sp, #0x1c
	add r2, sp, #0x10
	mov r3, #0
	str r3, [r2]
	str r3, [r2, #4]
	str r1, [sp, #0xc]
	str r3, [r2, #8]
	add r1, sp, #8
	str r1, [sp]
	mov r1, #0x81
	str r1, [sp, #4]
	ldr r1, _0224B2BC ; =ov02_022534A4
	bl sub_02068B0C
	add sp, #0x1c
	pop {pc}
	nop
_0224B2BC: .word ov02_022534A4
	thumb_func_end ov02_0224B298

	thumb_func_start ov02_0224B2C0
ov02_0224B2C0: ; 0x0224B2C0
	push {r3, lr}
	bl sub_02068D74
	mov r1, #0
	str r1, [r0]
	pop {r3, pc}
	thumb_func_end ov02_0224B2C0

	thumb_func_start ov02_0224B2CC
ov02_0224B2CC: ; 0x0224B2CC
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	add r5, r0, #0
	bl sub_02068D74
	add r4, r0, #0
	mov r0, #1
	str r0, [r4]
	mov r0, #0
	str r0, [r4, #4]
	str r0, [r4, #0xc]
	str r0, [r4, #8]
	str r0, [r4, #0x10]
	str r0, [r4, #0x14]
	str r0, [r4, #0x18]
	ldr r0, [r4, #0x20]
	bl Sprite_GetMatrixPtr
	add r6, r0, #0
	add r3, sp, #0
	ldmia r6!, {r0, r1}
	add r2, r3, #0
	stmia r3!, {r0, r1}
	ldr r0, [r6]
	add r1, r2, #0
	str r0, [r3]
	add r0, r5, #0
	bl sub_02068DA8
	ldr r0, [r4, #0x20]
	mov r1, #5
	bl Sprite_SetAnimCtrlSeq
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B2CC

	thumb_func_start ov02_0224B314
ov02_0224B314: ; 0x0224B314
	push {r4, r5, lr}
	sub sp, #0xc
	add r5, r0, #0
	bl sub_02068D74
	add r4, r0, #0
	mov r0, #2
	str r0, [r4]
	mov r0, #0
	str r0, [r4, #4]
	str r0, [r4, #0xc]
	str r0, [r4, #8]
	str r0, [r4, #0x10]
	str r0, [r4, #0x14]
	str r0, [r4, #0x18]
	ldr r0, [r4, #0x20]
	add r1, sp, #0
	bl ov02_02248C98
	add r0, r5, #0
	add r1, sp, #0
	bl sub_02068DA8
	ldr r0, [r4, #0x20]
	mov r1, #4
	bl Sprite_SetAnimCtrlSeq
	add sp, #0xc
	pop {r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B314

	thumb_func_start ov02_0224B350
ov02_0224B350: ; 0x0224B350
	push {r4, lr}
	add r4, r1, #0
	bl sub_02068D98
	ldr r1, [r0]
	str r1, [r4, #0x1c]
	ldr r0, [r0, #4]
	str r0, [r4, #0x20]
	mov r0, #1
	pop {r4, pc}
	thumb_func_end ov02_0224B350

	thumb_func_start ov02_0224B364
ov02_0224B364: ; 0x0224B364
	push {r3, r4, lr}
	sub sp, #0xc
	add r4, r1, #0
	ldr r1, [r4, #4]
	cmp r1, #0
	bne _0224B3A8
	ldr r1, [r4, #0xc]
	lsl r2, r1, #2
	ldr r1, _0224B3AC ; =ov02_02253520
	ldr r1, [r1, r2]
	str r1, [r4, #0x14]
	add r1, sp, #0
	bl sub_02068DB8
	ldr r1, [sp, #4]
	ldr r0, [r4, #0x14]
	add r0, r1, r0
	str r0, [sp, #4]
	ldr r0, [r4, #0x20]
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r0, [r4, #0xc]
	add r0, r0, #1
	str r0, [r4, #0xc]
	cmp r0, #0xc
	blt _0224B3A8
	mov r0, #0
	str r0, [r4, #0xc]
	mov r0, #1
	str r0, [r4, #8]
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
_0224B3A8:
	add sp, #0xc
	pop {r3, r4, pc}
	.balign 4, 0
_0224B3AC: .word ov02_02253520
	thumb_func_end ov02_0224B364

	thumb_func_start ov02_0224B3B0
ov02_0224B3B0: ; 0x0224B3B0
	push {r3, r4, lr}
	sub sp, #0xc
	add r4, r1, #0
	ldr r1, [r4, #4]
	cmp r1, #0
	bne _0224B3F4
	ldr r1, [r4, #0xc]
	lsl r2, r1, #2
	ldr r1, _0224B3F8 ; =ov02_02253430
	ldr r1, [r1, r2]
	str r1, [r4, #0x14]
	add r1, sp, #0
	bl sub_02068DB8
	ldr r1, [sp, #4]
	ldr r0, [r4, #0x14]
	add r0, r1, r0
	str r0, [sp, #4]
	ldr r0, [r4, #0x20]
	add r1, sp, #0
	bl Sprite_SetMatrix
	ldr r0, [r4, #0xc]
	add r0, r0, #1
	str r0, [r4, #0xc]
	cmp r0, #4
	blt _0224B3F4
	mov r0, #0
	str r0, [r4, #0xc]
	mov r0, #1
	str r0, [r4, #8]
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
_0224B3F4:
	add sp, #0xc
	pop {r3, r4, pc}
	.balign 4, 0
_0224B3F8: .word ov02_02253430
	thumb_func_end ov02_0224B3B0

	thumb_func_start ov02_0224B3FC
ov02_0224B3FC: ; 0x0224B3FC
	push {r3, lr}
	ldr r2, [r1]
	cmp r2, #1
	beq _0224B40A
	cmp r2, #2
	beq _0224B410
	pop {r3, pc}
_0224B40A:
	bl ov02_0224B364
	pop {r3, pc}
_0224B410:
	bl ov02_0224B3B0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B3FC

	thumb_func_start ov02_0224B418
ov02_0224B418: ; 0x0224B418
	push {r3, r4, r5, lr}
	add r4, r1, #0
	mov r1, #0x5f
	add r5, r0, #0
	mov r0, #4
	lsl r1, r1, #2
	bl ov02_0224B690
	add r1, r0, #0
	str r4, [r1, #0xc]
	ldr r0, _0224B438 ; =ov02_0224B45C
	mov r2, #0x86
	str r5, [r1, #0x14]
	bl SysTask_CreateOnMainQueue
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224B438: .word ov02_0224B45C
	thumb_func_end ov02_0224B418

	thumb_func_start ov02_0224B43C
ov02_0224B43C: ; 0x0224B43C
	push {r3, lr}
	bl SysTask_GetData
	ldr r0, [r0, #4]
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B43C

	thumb_func_start ov02_0224B448
ov02_0224B448: ; 0x0224B448
	push {r4, lr}
	add r4, r0, #0
	bl SysTask_GetData
	bl Heap_Free
	add r0, r4, #0
	bl SysTask_Destroy
	pop {r4, pc}
	thumb_func_end ov02_0224B448

	thumb_func_start ov02_0224B45C
ov02_0224B45C: ; 0x0224B45C
	push {r3, r4, r5, lr}
	ldr r4, _0224B490 ; =ov02_022534B8
	add r5, r1, #0
_0224B462:
	ldr r1, [r5]
	add r0, r5, #0
	lsl r1, r1, #2
	ldr r1, [r4, r1]
	blx r1
	cmp r0, #1
	beq _0224B462
	ldr r0, [r5, #0x10]
	cmp r0, #0
	beq _0224B48E
	mov r0, #0x17
	lsl r0, r0, #4
	ldr r0, [r5, r0]
	cmp r0, #0
	beq _0224B484
	bl sub_02068BAC
_0224B484:
	ldr r0, [r5, #0x20]
	cmp r0, #0
	beq _0224B48E
	bl SpriteList_RenderAndAnimateSprites
_0224B48E:
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224B490: .word ov02_022534B8
	thumb_func_end ov02_0224B45C

	thumb_func_start ov02_0224B494
ov02_0224B494: ; 0x0224B494
	push {r4, lr}
	add r4, r0, #0
	ldr r0, [r4, #0x14]
	mov r1, #1
	bl ov02_02249444
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B494

	thumb_func_start ov02_0224B4AC
ov02_0224B4AC: ; 0x0224B4AC
	push {r3, r4, r5, lr}
	sub sp, #0x18
	add r5, r0, #0
	mov r0, #4
	mov r1, #0x20
	bl sub_020689C8
	mov r1, #0x17
	lsl r1, r1, #4
	str r0, [r5, r1]
	mov r2, #2
	str r2, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	str r0, [sp, #0xc]
	str r0, [sp, #0x10]
	add r0, r5, #0
	add r0, #0x18
	mov r1, #0x20
	add r3, r2, #0
	str r2, [sp, #0x14]
	bl ov02_02248728
	bl ov02_022493F0
	add r4, r0, #0
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0xb
	mov r3, #0
	bl ov02_02248980
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #6
	mov r3, #0
	bl ov02_02248A58
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0xc
	mov r3, #0
	bl ov02_02248B30
	add r0, r5, #0
	add r0, #0x18
	mov r1, #0
	bl ov02_022489F0
	add r0, r5, #0
	add r0, #0x18
	mov r1, #0
	bl ov02_02248AC8
	add r0, r5, #0
	add r0, #0x18
	mov r1, #0
	bl ov02_02248A24
	add r0, r5, #0
	add r0, #0x18
	mov r1, #0
	bl ov02_02248AFC
	ldr r0, [r5, #0xc]
	cmp r0, #0
	bne _0224B57C
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0x11
	mov r3, #2
	bl ov02_02248980
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0x12
	mov r3, #2
	bl ov02_02248B30
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0x13
	mov r3, #1
	bl ov02_02248BA0
	add r0, r5, #0
	add r0, #0x18
	mov r1, #2
	bl ov02_022489F0
	add r0, r5, #0
	add r0, #0x18
	mov r1, #2
	bl ov02_02248A24
	b _0224B5DC
_0224B57C:
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0x14
	mov r3, #2
	bl ov02_02248980
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #7
	mov r3, #1
	bl ov02_02248A58
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0x15
	mov r3, #2
	bl ov02_02248B30
	add r0, r5, #0
	add r0, #0x18
	add r1, r4, #0
	mov r2, #0x16
	mov r3, #1
	bl ov02_02248BA0
	add r0, r5, #0
	add r0, #0x18
	mov r1, #2
	bl ov02_022489F0
	add r0, r5, #0
	add r0, #0x18
	mov r1, #1
	bl ov02_02248AC8
	add r0, r5, #0
	add r0, #0x18
	mov r1, #2
	bl ov02_02248A24
	add r0, r5, #0
	add r0, #0x18
	mov r1, #1
	bl ov02_02248AFC
_0224B5DC:
	add r0, r4, #0
	bl NARC_Delete
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	mov r0, #0
	add sp, #0x18
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B4AC

	thumb_func_start ov02_0224B5F0
ov02_0224B5F0: ; 0x0224B5F0
	push {r4, lr}
	add r4, r0, #0
	ldr r1, [r4, #0xc]
	add r0, #0x18
	bl ov02_02248D18
	mov r1, #0x5b
	lsl r1, r1, #2
	str r0, [r4, r1]
	ldr r0, [r4, r1]
	mov r1, #1
	bl Sprite_SetDrawFlag
	mov r3, #0x17
	lsl r3, r3, #4
	ldr r1, [r4, r3]
	sub r3, r3, #4
	add r2, r4, #0
	ldr r0, [r4, #0x14]
	ldr r3, [r4, r3]
	add r2, #0x18
	bl ov02_02248D58
	mov r1, #0x5d
	lsl r1, r1, #2
	str r0, [r4, r1]
	ldr r0, [r4, r1]
	bl ov02_02248E20
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	str r0, [r4, #0x10]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_0224B5F0

	thumb_func_start ov02_0224B638
ov02_0224B638: ; 0x0224B638
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x5d
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl ov02_02248D8C
	cmp r0, #2
	beq _0224B64E
	mov r0, #0
	pop {r4, pc}
_0224B64E:
	mov r0, #0x5d
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl ov02_02248DBC
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B638

	thumb_func_start ov02_0224B664
ov02_0224B664: ; 0x0224B664
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x17
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl sub_020689F8
	add r0, r4, #0
	add r0, #0x18
	bl ov02_0224886C
	mov r0, #0
	str r0, [r4, #0x10]
	mov r1, #1
	str r1, [r4, #4]
	ldr r1, [r4]
	add r1, r1, #1
	str r1, [r4]
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B664

	thumb_func_start ov02_0224B68C
ov02_0224B68C: ; 0x0224B68C
	mov r0, #0
	bx lr
	thumb_func_end ov02_0224B68C

	thumb_func_start ov02_0224B690
ov02_0224B690: ; 0x0224B690
	push {r3, r4, r5, lr}
	add r5, r1, #0
	bl Heap_AllocAtEnd
	add r4, r0, #0
	bne _0224B6A0
	bl GF_AssertFail
_0224B6A0:
	add r0, r4, #0
	mov r1, #0
	add r2, r5, #0
	bl memset
	add r0, r4, #0
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B690

	thumb_func_start ov02_0224B6B0
ov02_0224B6B0: ; 0x0224B6B0
	push {r3, r4, r5, lr}
	add r5, r0, #0
	mov r0, #0x82
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	add r4, r1, #0
	bl MapObject_UnpauseMovement
	mov r0, #0x82
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	add r1, r4, #0
	bl MapObject_SetVisible
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B6B0

	thumb_func_start ov02_0224B6D0
ov02_0224B6D0: ; 0x0224B6D0
	push {r4, lr}
	add r4, r1, #0
	bl sub_02068D98
	ldr r1, [r0]
	ldr r0, [r0, #4]
	str r1, [r4]
	str r0, [r4, #4]
	mov r0, #1
	pop {r4, pc}
	thumb_func_end ov02_0224B6D0

	thumb_func_start ov02_0224B6E4
ov02_0224B6E4: ; 0x0224B6E4
	push {r3, r4, r5, lr}
	add r4, r1, #0
	ldr r0, [r4]
	bl Sprite_GetMatrixPtr
	ldr r1, [r4, #4]
	ldr r0, [r0, #4]
	ldr r5, [r1, #0x4c]
	ldr r3, [r1, #0x50]
	ldr r1, [r1, #0x1c]
	cmp r1, #0
	bne _0224B720
	mov r1, #2
	lsl r1, r1, #0xe
	sub r2, r0, r1
	cmp r2, r5
	blt _0224B716
	add r0, r0, r1
	cmp r0, r3
	bgt _0224B716
	ldr r0, [r4]
	mov r1, #1
	bl Sprite_SetDrawFlag
	pop {r3, r4, r5, pc}
_0224B716:
	ldr r0, [r4]
	mov r1, #0
	bl Sprite_SetDrawFlag
	pop {r3, r4, r5, pc}
_0224B720:
	ldr r0, [r4]
	mov r1, #1
	bl Sprite_SetDrawFlag
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B6E4

	thumb_func_start ov02_0224B72C
ov02_0224B72C: ; 0x0224B72C
	push {r3, r4, lr}
	sub sp, #0x1c
	add r2, sp, #0x10
	mov r3, #0
	str r3, [r2]
	add r4, r0, #0
	str r3, [r2, #4]
	mov r0, #0x79
	str r3, [r2, #8]
	lsl r0, r0, #2
	ldr r1, [r4, r0]
	sub r0, r0, #4
	str r1, [sp, #8]
	str r4, [sp, #0xc]
	add r1, sp, #8
	str r1, [sp]
	mov r1, #0x87
	str r1, [sp, #4]
	ldr r0, [r4, r0]
	ldr r1, _0224B764 ; =ov02_02253440
	bl sub_02068B0C
	mov r1, #0x7d
	lsl r1, r1, #2
	str r0, [r4, r1]
	add sp, #0x1c
	pop {r3, r4, pc}
	nop
_0224B764: .word ov02_02253440
	thumb_func_end ov02_0224B72C

	thumb_func_start ov02_0224B768
ov02_0224B768: ; 0x0224B768
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x7d
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	cmp r0, #0
	beq _0224B782
	bl sub_02068B48
	mov r0, #0x7d
	mov r1, #0
	lsl r0, r0, #2
	str r1, [r4, r0]
_0224B782:
	pop {r4, pc}
	thumb_func_end ov02_0224B768

	thumb_func_start ov02_0224B784
ov02_0224B784: ; 0x0224B784
	push {r4, lr}
	sub sp, #0x18
	add r2, sp, #0xc
	mov r1, #0
	str r1, [r2]
	add r4, r0, #0
	str r1, [r2, #4]
	str r1, [r2, #8]
	str r4, [sp, #8]
	bl ov02_0224B88C
	mov r0, #0x83
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	add r1, sp, #0xc
	bl MapObject_CopyPositionVector
	add r0, sp, #8
	str r0, [sp]
	mov r0, #0x83
	str r0, [sp, #4]
	mov r0, #0x1e
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	ldr r1, _0224B7C8 ; =ov02_02253490
	add r2, sp, #0xc
	mov r3, #0
	bl sub_02068B0C
	mov r1, #0x1f
	lsl r1, r1, #4
	str r0, [r4, r1]
	add sp, #0x18
	pop {r4, pc}
	.balign 4, 0
_0224B7C8: .word ov02_02253490
	thumb_func_end ov02_0224B784

	thumb_func_start ov02_0224B7CC
ov02_0224B7CC: ; 0x0224B7CC
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	add r5, r0, #0
	add r4, r1, #0
	bl sub_02068D98
	ldr r1, [r0]
	mov r6, #0x8a
	str r1, [r4]
	ldr r4, [r0]
	lsl r6, r6, #2
	add r0, r5, #0
	add r1, sp, #0
	bl sub_02068DB8
	add r0, r4, r6
	add r0, #0x24
	add r1, sp, #0
	bl Field3dObject_SetPos
	add r0, r4, r6
	add r0, #0x24
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	mov r0, #1
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	thumb_func_end ov02_0224B7CC

	thumb_func_start ov02_0224B804
ov02_0224B804: ; 0x0224B804
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224B804

	thumb_func_start ov02_0224B808
ov02_0224B808: ; 0x0224B808
	push {r4, r5, r6, lr}
	add r5, r1, #0
	ldr r0, [r5, #4]
	mov r6, #0x8a
	lsl r6, r6, #2
	ldr r4, [r5]
	cmp r0, #3
	bhi _0224B878
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224B824: ; jump table
	.short _0224B82C - _0224B824 - 2 ; case 0
	.short _0224B832 - _0224B824 - 2 ; case 1
	.short _0224B854 - _0224B824 - 2 ; case 2
	.short _0224B878 - _0224B824 - 2 ; case 3
_0224B82C:
	mov r0, #1
	str r0, [r5, #4]
	pop {r4, r5, r6, pc}
_0224B832:
	add r0, r4, r6
	add r0, #0x24
	mov r1, #1
	bl Field3dObject_SetActiveFlag
	add r0, r4, r6
	add r0, #0x9c
	mov r1, #0
	bl Field3dModelAnimation_FrameSet
	add r0, r4, r6
	add r0, #0xb0
	mov r1, #0
	bl Field3dModelAnimation_FrameSet
	mov r0, #2
	str r0, [r5, #4]
_0224B854:
	add r0, r4, r6
	mov r1, #1
	add r0, #0x9c
	lsl r1, r1, #0xc
	bl Field3dModelAnimation_FrameAdvanceAndCheck
	add r0, r4, r6
	mov r1, #1
	add r0, #0xb0
	lsl r1, r1, #0xc
	bl Field3dModelAnimation_FrameAdvanceAndCheck
	cmp r0, #0
	beq _0224B878
	mov r0, #1
	str r0, [r5, #8]
	mov r0, #3
	str r0, [r5, #4]
_0224B878:
	pop {r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B808

	thumb_func_start ov02_0224B87C
ov02_0224B87C: ; 0x0224B87C
	mov r0, #0x93
	ldr r1, [r1]
	lsl r0, r0, #2
	ldr r3, _0224B888 ; =Field3dObject_Draw
	add r0, r1, r0
	bx r3
	.balign 4, 0
_0224B888: .word Field3dObject_Draw
	thumb_func_end ov02_0224B87C

	thumb_func_start ov02_0224B88C
ov02_0224B88C: ; 0x0224B88C
	push {r4, lr}
	sub sp, #8
	mov r1, #0x8a
	lsl r1, r1, #2
	add r4, r0, r1
	add r0, r4, #0
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	mov r0, #0x67
	mov r1, #0x83
	mov r2, #4
	bl AllocAtEndAndReadWholeNarcMemberByIdPair
	str r0, [r4, #0x10]
	add r0, r4, #0
	ldr r1, [r4, #0x10]
	add r0, #0x14
	bl ov01_021FBD38
	add r0, r4, #0
	add r1, r4, #0
	add r0, #0x24
	add r1, #0x14
	bl Field3dObject_InitFromModel
	mov r0, #4
	str r0, [sp]
	add r0, r4, #0
	add r1, r4, #0
	add r0, #0x9c
	add r1, #0x14
	mov r2, #0x67
	mov r3, #0xa7
	str r4, [sp, #4]
	bl Field3dModelAnimation_LoadFromFilesystem
	mov r0, #4
	str r0, [sp]
	add r0, r4, #0
	add r1, r4, #0
	add r0, #0xb0
	add r1, #0x14
	mov r2, #0x67
	mov r3, #0xa5
	str r4, [sp, #4]
	bl Field3dModelAnimation_LoadFromFilesystem
	add r0, r4, #0
	add r1, r4, #0
	add r0, #0x24
	add r1, #0x9c
	bl Field3dObject_AddAnimation
	add r0, r4, #0
	add r4, #0xb0
	add r0, #0x24
	add r1, r4, #0
	bl Field3dObject_AddAnimation
	add sp, #8
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B88C

	thumb_func_start ov02_0224B90C
ov02_0224B90C: ; 0x0224B90C
	push {r4, lr}
	mov r1, #0x8a
	lsl r1, r1, #2
	add r4, r0, r1
	add r0, r4, #0
	add r0, #0x14
	bl ov01_021FBDFC
	ldr r0, [r4, #0x10]
	bl ov01_021F1448
	add r0, r4, #0
	add r0, #0x9c
	add r1, r4, #0
	bl Field3dModelAnimation_Unload
	add r0, r4, #0
	add r0, #0xb0
	add r1, r4, #0
	bl Field3dModelAnimation_Unload
	pop {r4, pc}
	thumb_func_end ov02_0224B90C

	thumb_func_start ov02_0224B938
ov02_0224B938: ; 0x0224B938
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x83
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	mov r1, #1
	bl MapObject_SetVisible
	mov r0, #0x83
	lsl r0, r0, #2
	ldr r0, [r4, r0]
	bl sub_0205F484
	add r0, r4, #0
	bl ov02_0224B784
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B938

	thumb_func_start ov02_0224B964
ov02_0224B964: ; 0x0224B964
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0x1f
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl sub_02068D74
	ldr r0, [r0, #8]
	cmp r0, #1
	bne _0224B992
	mov r0, #0x1f
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl sub_02068B48
	add r0, r4, #0
	bl ov02_0224B90C
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
_0224B992:
	mov r0, #0
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224B964

	thumb_func_start ov02_BattleExit_HandleRoamerAction
ov02_BattleExit_HandleRoamerAction: ; 0x0224B998
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r5, r0, #0
	ldr r0, [r1, #8]
	str r1, [sp]
	mov r1, #0
	bl Party_GetMonByIndex
	add r7, r0, #0
	ldr r0, [r5, #0xc]
	bl Save_Roamers_Get
	add r6, r0, #0
	add r0, r7, #0
	mov r1, #5
	mov r2, #0
	bl GetMonData
	add r4, r0, #0
	add r0, r6, #0
	add r1, r4, #0
	bl ov02_0224BAA8
	str r0, [sp, #8]
	cmp r0, #0
	beq _0224BA50
	lsl r0, r4, #0x10
	lsr r0, r0, #0x10
	bl SpeciesToRoamerIdx
	str r0, [sp, #4]
	add r0, r7, #0
	mov r1, #0xa3
	mov r2, #0
	bl GetMonData
	lsl r0, r0, #0x10
	lsr r4, r0, #0x10
	add r0, r7, #0
	mov r1, #0xa0
	mov r2, #0
	bl GetMonData
	lsl r0, r0, #0x18
	lsr r7, r0, #0x18
	ldr r0, [sp]
	ldr r0, [r0, #0x14]
	cmp r0, #1
	bne _0224BA14
	cmp r4, #0
	bne _0224BA14
	add r0, sp, #8
	bl RoamerMon_Init
	ldr r0, [r5, #0xc]
	bl Save_VarsFlags_Get
	ldr r1, [sp, #4]
	mov r2, #2
	bl sub_02066BE8
	b _0224BA42
_0224BA14:
	cmp r0, #4
	bne _0224BA2E
	add r0, sp, #8
	bl RoamerMon_Init
	ldr r0, [r5, #0xc]
	bl Save_VarsFlags_Get
	ldr r1, [sp, #4]
	mov r2, #1
	bl sub_02066BE8
	b _0224BA42
_0224BA2E:
	ldr r0, [sp, #8]
	mov r1, #5
	add r2, r4, #0
	bl SetRoamerData
	ldr r0, [sp, #8]
	mov r1, #7
	add r2, r7, #0
	bl SetRoamerData
_0224BA42:
	ldr r1, [r5, #0x20]
	add r0, r6, #0
	ldr r1, [r1]
	bl ov02_RepelActiveRoamersFromMapNo
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
_0224BA50:
	bl LCRandom
	mov r1, #0x64
	bl _s32_div_f
	lsl r0, r1, #0x10
	lsr r0, r0, #0x10
	cmp r0, #0x1e
	bhs _0224BA6C
	ldr r1, [r5, #0x20]
	add r0, r6, #0
	ldr r1, [r1]
	bl ov02_RepelActiveRoamersFromMapNo
_0224BA6C:
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	thumb_func_end ov02_BattleExit_HandleRoamerAction

	thumb_func_start ov02_RepelActiveRoamersFromMapNo
ov02_RepelActiveRoamersFromMapNo: ; 0x0224BA70
	push {r4, r5, r6, lr}
	add r5, r0, #0
	add r6, r1, #0
	mov r4, #0
_0224BA78:
	add r0, r5, #0
	add r1, r4, #0
	bl GetRoamerIsActiveByIndex
	cmp r0, #0
	beq _0224BA9C
	add r0, r5, #0
	add r1, r4, #0
	bl Roamer_GetLocation
	bl GetRoamMapByLocationIdx
	cmp r6, r0
	bne _0224BA9C
	add r0, r5, #0
	add r1, r4, #0
	bl RoamerLocationUpdateRand
_0224BA9C:
	add r0, r4, #1
	lsl r0, r0, #0x18
	lsr r4, r0, #0x18
	cmp r4, #4
	blo _0224BA78
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_RepelActiveRoamersFromMapNo

	thumb_func_start ov02_0224BAA8
ov02_0224BAA8: ; 0x0224BAA8
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	add r6, r1, #0
	mov r4, #0
_0224BAB0:
	add r0, r5, #0
	add r1, r4, #0
	bl GetRoamerIsActiveByIndex
	cmp r0, #0
	beq _0224BAD4
	add r0, r5, #0
	add r1, r4, #0
	bl Roamers_GetRoamMonStats
	mov r1, #4
	add r7, r0, #0
	bl GetRoamerData
	cmp r6, r0
	bne _0224BAD4
	add r0, r7, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224BAD4:
	add r0, r4, #1
	lsl r0, r0, #0x18
	lsr r4, r0, #0x18
	cmp r4, #4
	blo _0224BAB0
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224BAA8

	thumb_func_start PlayerStepEvent_RepelCounterDecrement
PlayerStepEvent_RepelCounterDecrement: ; 0x0224BAE4
	push {r4, lr}
	add r4, r1, #0
	bl Save_Roamers_Get
	bl RoamerSave_GetRepelAddr
	ldrb r1, [r0]
	cmp r1, #0
	beq _0224BB0E
	sub r1, r1, #1
	strb r1, [r0]
	ldrb r0, [r0]
	cmp r0, #0
	bne _0224BB0E
	ldr r1, _0224BB14 ; =std_repel_wore_off
	add r0, r4, #0
	mov r2, #0
	bl StartMapSceneScript
	mov r0, #1
	pop {r4, pc}
_0224BB0E:
	mov r0, #0
	pop {r4, pc}
	nop
_0224BB14: .word std_repel_wore_off
	thumb_func_end PlayerStepEvent_RepelCounterDecrement

	thumb_func_start PokecenterAnimCreate
PokecenterAnimCreate: ; 0x0224BB18
	push {r4, r5, r6, lr}
	sub sp, #0x20
	add r6, r1, #0
	mov r1, #0x24
	add r2, sp, #4
	add r3, sp, #0
	add r5, r0, #0
	bl sub_02054C20
	cmp r0, #0
	beq _0224BB84
	mov r0, #4
	mov r1, #0x18
	bl Heap_AllocAtEnd
	add r4, r0, #0
	strb r6, [r4, #0xc]
	mov r0, #0
	strb r0, [r4, #0xd]
	strb r0, [r4, #0xe]
	strb r0, [r4, #0xf]
	ldr r0, [r5, #0x30]
	bl MapMatrix_GetWidth
	add r1, r0, #0
	ldr r0, [sp]
	add r2, sp, #0x14
	bl sub_02054DC8
	ldr r1, [sp, #4]
	add r0, sp, #8
	bl MapProp_GetTranslation
	add r3, sp, #8
	ldmia r3!, {r0, r1}
	add r2, r4, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r1, [r4]
	ldr r0, [sp, #0x14]
	add r2, r4, #0
	add r0, r1, r0
	str r0, [r4]
	ldr r1, [r4, #8]
	ldr r0, [sp, #0x1c]
	add r0, r1, r0
	str r0, [r4, #8]
	ldr r0, [r5, #0x10]
	ldr r1, _0224BB8C ; =PokecenterAnimRun
	bl TaskManager_Call
	add sp, #0x20
	pop {r4, r5, r6, pc}
_0224BB84:
	bl GF_AssertFail
	add sp, #0x20
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224BB8C: .word PokecenterAnimRun
	thumb_func_end PokecenterAnimCreate

	thumb_func_start PokecenterAnimRun
PokecenterAnimRun: ; 0x0224BB90
	push {r4, r5, r6, r7, lr}
	sub sp, #0x34
	add r4, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r4, #0
	bl TaskManager_GetEnvironment
	add r4, r0, #0
	ldrb r1, [r4, #0xf]
	cmp r1, #5
	bls _0224BBAC
	b _0224BDCC
_0224BBAC:
	add r1, r1, r1
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0224BBB8: ; jump table
	.short _0224BBC4 - _0224BBB8 - 2 ; case 0
	.short _0224BC98 - _0224BBB8 - 2 ; case 1
	.short _0224BCFA - _0224BBB8 - 2 ; case 2
	.short _0224BD42 - _0224BBB8 - 2 ; case 3
	.short _0224BD64 - _0224BBB8 - 2 ; case 4
	.short _0224BDC2 - _0224BBB8 - 2 ; case 5
_0224BBC4:
	ldr r1, [r6, #0x34]
	mov r0, #0x6b
	bl ov01_021FB90C
	add r5, r0, #0
	ldr r1, [r6, #0x34]
	mov r0, #0x25
	bl ov01_021FB90C
	add r7, r0, #0
	ldr r0, [r5]
	bl NNS_G3dGetMdlSet
	cmp r0, #0
	beq _0224BC02
	add r2, r0, #0
	add r2, #8
	beq _0224BBF6
	ldrb r1, [r0, #9]
	cmp r1, #0
	bls _0224BBF6
	ldrh r1, [r0, #0xe]
	add r1, r2, r1
	add r1, r1, #4
	b _0224BBF8
_0224BBF6:
	mov r1, #0
_0224BBF8:
	cmp r1, #0
	beq _0224BC02
	ldr r1, [r1]
	add r5, r0, r1
	b _0224BC04
_0224BC02:
	mov r5, #0
_0224BC04:
	ldr r0, [r7]
	bl NNS_G3dGetMdlSet
	cmp r0, #0
	beq _0224BC2E
	add r2, r0, #0
	add r2, #8
	beq _0224BC22
	ldrb r1, [r0, #9]
	cmp r1, #0
	bls _0224BC22
	ldrh r1, [r0, #0xe]
	add r1, r2, r1
	add r1, r1, #4
	b _0224BC24
_0224BC22:
	mov r1, #0
_0224BC24:
	cmp r1, #0
	beq _0224BC2E
	ldr r1, [r1]
	add r7, r0, r1
	b _0224BC30
_0224BC2E:
	mov r7, #0
_0224BC30:
	ldr r0, [r6, #0x34]
	bl ov01_021FB9E0
	mov r1, #0
	str r1, [sp]
	str r5, [sp, #4]
	str r0, [sp, #8]
	mov r0, #1
	str r0, [sp, #0xc]
	str r0, [sp, #0x10]
	str r1, [sp, #0x14]
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #0x10
	mov r3, #0x6b
	bl MapPropOneShotAnimationManager_LoadPropAnimations
	add r0, r6, #0
	mov r1, #0x25
	add r2, sp, #0x18
	mov r3, #0
	bl sub_02054C20
	cmp r0, #0
	bne _0224BC66
	bl GF_AssertFail
_0224BC66:
	ldr r0, [sp, #0x18]
	bl MapProp_GetRenderSurface
	add r5, r0, #0
	ldr r0, [r6, #0x34]
	bl ov01_021FB9E0
	str r5, [sp]
	str r7, [sp, #4]
	str r0, [sp, #8]
	mov r0, #1
	str r0, [sp, #0xc]
	str r0, [sp, #0x10]
	mov r0, #0
	str r0, [sp, #0x14]
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #0x20
	mov r3, #0x25
	bl MapPropOneShotAnimationManager_LoadPropAnimations
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224BDCC
_0224BC98:
	add r1, sp, #0x1c
	mov r0, #0
	str r0, [r1]
	str r0, [r1, #4]
	str r0, [r1, #8]
	ldrb r2, [r4, #0xd]
	mov r1, #0xc
	ldr r0, [r4]
	add r3, r2, #0
	ldr r2, _0224BDD4 ; =ov02_02253D90
	mul r3, r1
	ldr r2, [r2, r3]
	add r0, r0, r2
	str r0, [sp, #0x28]
	ldrb r2, [r4, #0xd]
	ldr r0, [r4, #4]
	add r3, r2, #0
	ldr r2, _0224BDD8 ; =ov02_02253D94
	mul r3, r1
	ldr r2, [r2, r3]
	add r0, r0, r2
	str r0, [sp, #0x2c]
	ldrb r2, [r4, #0xd]
	ldr r0, [r4, #8]
	add r3, r2, #0
	mul r3, r1
	ldr r1, _0224BDDC ; =ov02_02253D98
	ldr r1, [r1, r3]
	add r0, r0, r1
	str r0, [sp, #0x30]
	ldr r0, _0224BDE0 ; =SEQ_SE_DP_BOWA
	bl PlaySE
	ldr r0, [r6, #0x54]
	add r6, #0x9c
	str r0, [sp]
	ldr r0, [r6]
	mov r1, #0x6b
	add r2, sp, #0x28
	add r3, sp, #0x1c
	bl MapPropManager_LoadOne
	ldrb r1, [r4, #0xd]
	add r1, r4, r1
	strb r0, [r1, #0x10]
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224BDCC
_0224BCFA:
	ldrb r0, [r4, #0xe]
	cmp r0, #0xc
	bhs _0224BD06
	add r0, r0, #1
	strb r0, [r4, #0xe]
	b _0224BDCC
_0224BD06:
	mov r0, #0
	strb r0, [r4, #0xe]
	ldrb r0, [r4, #0xd]
	add r0, r0, #1
	strb r0, [r4, #0xd]
	ldrb r1, [r4, #0xd]
	ldrb r0, [r4, #0xc]
	cmp r1, r0
	bhs _0224BD1E
	mov r0, #1
	strb r0, [r4, #0xf]
	b _0224BDCC
_0224BD1E:
	add r0, r6, #0
	add r0, #0x9c
	ldrb r1, [r4, #0x10]
	ldr r0, [r0]
	bl MapPropManager_GetMapPropByIndex_Checked_RequireActive
	bl MapProp_GetRenderSurface
	add r3, r0, #0
	ldr r0, [r6, #0x58]
	mov r1, #0x10
	mov r2, #0
	bl MapPropOneShotAnimationManager_SetAnimationRenderObj
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224BDCC
_0224BD42:
	ldr r0, [r6, #0x58]
	mov r1, #0x10
	mov r2, #0
	bl MapPropOneShotAnimationManager_PlayAnimation
	ldr r0, [r6, #0x58]
	mov r1, #0x20
	mov r2, #0
	bl MapPropOneShotAnimationManager_PlayAnimation
	ldr r0, _0224BDE4 ; =SEQ_ME_ASA
	bl PlayFanfare
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224BDCC
_0224BD64:
	ldr r0, [r6, #0x58]
	mov r1, #0x10
	bl MapPropOneShotAnimationManager_IsAnimationLoopFinished
	cmp r0, #0
	beq _0224BDCC
	ldr r0, [r6, #0x58]
	mov r1, #0x20
	bl MapPropOneShotAnimationManager_IsAnimationLoopFinished
	cmp r0, #0
	beq _0224BDCC
	bl IsFanfarePlaying
	cmp r0, #0
	bne _0224BDCC
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #0x20
	bl MapPropOneShotAnimationManager_UnloadAnimation
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #0x10
	bl MapPropOneShotAnimationManager_UnloadAnimation
	ldrb r0, [r4, #0xc]
	mov r5, #0
	cmp r0, #0
	bls _0224BDBA
_0224BDA0:
	add r0, r4, r5
	add r1, r6, #0
	add r1, #0x9c
	ldrb r0, [r0, #0x10]
	ldr r1, [r1]
	bl MapPropManager_RemoveMapPropByIndex
	add r0, r5, #1
	lsl r0, r0, #0x18
	lsr r5, r0, #0x18
	ldrb r0, [r4, #0xc]
	cmp r5, r0
	blo _0224BDA0
_0224BDBA:
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224BDCC
_0224BDC2:
	bl Heap_Free
	add sp, #0x34
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224BDCC:
	mov r0, #0
	add sp, #0x34
	pop {r4, r5, r6, r7, pc}
	nop
_0224BDD4: .word ov02_02253D90
_0224BDD8: .word ov02_02253D94
_0224BDDC: .word ov02_02253D98
_0224BDE0: .word SEQ_SE_DP_BOWA
_0224BDE4: .word SEQ_ME_ASA
	thumb_func_end PokecenterAnimRun

	thumb_func_start ov02_0224BDE8
ov02_0224BDE8: ; 0x0224BDE8
	push {r4, r5, r6, lr}
	add r6, r2, #0
	mov r2, #0
	add r4, r1, #0
	mov r1, #0xd0
	add r3, r2, #0
	add r5, r0, #0
	bl sub_02054C20
	cmp r0, #0
	beq _0224BE1A
	mov r0, #4
	add r1, r0, #0
	bl Heap_AllocAtEnd
	add r2, r0, #0
	strb r6, [r2]
	strb r4, [r2, #1]
	mov r0, #0
	strb r0, [r2, #2]
	ldr r0, [r5, #0x10]
	ldr r1, _0224BE20 ; =ov02_0224BE24
	bl TaskManager_Call
	pop {r4, r5, r6, pc}
_0224BE1A:
	bl GF_AssertFail
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224BE20: .word ov02_0224BE24
	thumb_func_end ov02_0224BDE8

	thumb_func_start ov02_0224BE24
ov02_0224BE24: ; 0x0224BE24
	push {r4, r5, r6, r7, lr}
	sub sp, #0x1c
	add r4, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r4, #0
	bl TaskManager_GetEnvironment
	add r4, r0, #0
	ldrb r1, [r4, #2]
	cmp r1, #4
	bls _0224BE40
	b _0224BF48
_0224BE40:
	add r1, r1, r1
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0224BE4C: ; jump table
	.short _0224BE56 - _0224BE4C - 2 ; case 0
	.short _0224BED2 - _0224BE4C - 2 ; case 1
	.short _0224BF00 - _0224BE4C - 2 ; case 2
	.short _0224BF2C - _0224BE4C - 2 ; case 3
	.short _0224BF3E - _0224BE4C - 2 ; case 4
_0224BE56:
	ldr r1, [r6, #0x34]
	mov r0, #0xd0
	bl ov01_021FB90C
	ldr r0, [r0]
	bl NNS_G3dGetMdlSet
	cmp r0, #0
	beq _0224BE88
	add r2, r0, #0
	add r2, #8
	beq _0224BE7C
	ldrb r1, [r0, #9]
	cmp r1, #0
	bls _0224BE7C
	ldrh r1, [r0, #0xe]
	add r1, r2, r1
	add r1, r1, #4
	b _0224BE7E
_0224BE7C:
	mov r1, #0
_0224BE7E:
	cmp r1, #0
	beq _0224BE88
	ldr r1, [r1]
	add r7, r0, r1
	b _0224BE8A
_0224BE88:
	mov r7, #0
_0224BE8A:
	add r0, r6, #0
	mov r1, #0xd0
	add r2, sp, #0x18
	mov r3, #0
	bl sub_02054C20
	cmp r0, #0
	bne _0224BE9E
	bl GF_AssertFail
_0224BE9E:
	ldr r0, [sp, #0x18]
	bl MapProp_GetRenderSurface
	add r5, r0, #0
	ldr r0, [r6, #0x34]
	bl ov01_021FB9E0
	str r5, [sp]
	str r7, [sp, #4]
	str r0, [sp, #8]
	mov r0, #2
	str r0, [sp, #0xc]
	ldrb r0, [r4]
	mov r2, #1
	mov r3, #0xd0
	str r0, [sp, #0x10]
	mov r0, #0
	str r0, [sp, #0x14]
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	bl MapPropOneShotAnimationManager_LoadPropAnimations
	ldrb r0, [r4, #2]
	add r0, r0, #1
	strb r0, [r4, #2]
	b _0224BF48
_0224BED2:
	ldrb r0, [r4, #1]
	mov r1, #1
	cmp r0, #0
	beq _0224BEE0
	cmp r0, #1
	beq _0224BEE0
	mov r1, #0
_0224BEE0:
	cmp r1, #0
	bne _0224BEE8
	bl GF_AssertFail
_0224BEE8:
	ldrb r2, [r4, #1]
	ldr r0, [r6, #0x58]
	mov r1, #1
	bl MapPropOneShotAnimationManager_PlayAnimation
	ldr r0, _0224BF50 ; =SEQ_SE_DP_ELEBETA2
	bl PlaySE
	ldrb r0, [r4, #2]
	add r0, r0, #1
	strb r0, [r4, #2]
	b _0224BF48
_0224BF00:
	ldr r0, [r6, #0x58]
	mov r1, #1
	bl MapPropOneShotAnimationManager_IsAnimationLoopFinished
	cmp r0, #0
	beq _0224BF48
	ldr r0, _0224BF50 ; =SEQ_SE_DP_ELEBETA2
	mov r1, #0
	bl StopSE
	ldr r0, _0224BF54 ; =SEQ_SE_DP_PINPON
	bl PlaySE
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #1
	bl MapPropOneShotAnimationManager_UnloadAnimation
	ldrb r0, [r4, #2]
	add r0, r0, #1
	strb r0, [r4, #2]
	b _0224BF48
_0224BF2C:
	ldr r0, _0224BF54 ; =SEQ_SE_DP_PINPON
	bl IsSEPlaying
	cmp r0, #0
	bne _0224BF48
	ldrb r0, [r4, #2]
	add r0, r0, #1
	strb r0, [r4, #2]
	b _0224BF48
_0224BF3E:
	bl Heap_Free
	add sp, #0x1c
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224BF48:
	mov r0, #0
	add sp, #0x1c
	pop {r4, r5, r6, r7, pc}
	nop
_0224BF50: .word SEQ_SE_DP_ELEBETA2
_0224BF54: .word SEQ_SE_DP_PINPON
	thumb_func_end ov02_0224BE24

	thumb_func_start ov02_0224BF58
ov02_0224BF58: ; 0x0224BF58
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x28
	ldr r2, _0224BFBC ; =ov02_022536E8
	add r7, r1, #0
	ldr r3, [r2]
	ldr r2, [r2, #4]
	str r3, [sp, #0x18]
	str r2, [sp, #0x1c]
	add r2, sp, #0x20
	str r2, [sp]
	add r1, sp, #0x18
	mov r2, #2
	add r3, sp, #0x24
	add r5, r0, #0
	bl sub_02054C90
	cmp r0, #0
	beq _0224BFB4
	ldr r0, [r5, #0x34]
	bl ov01_021FB9E0
	add r6, r0, #0
	ldr r0, [sp, #0x24]
	bl MapProp_GetRenderSurface
	add r4, r0, #0
	ldr r0, [sp, #0x24]
	bl MapProp_GetResModel
	str r4, [sp]
	str r0, [sp, #4]
	str r6, [sp, #8]
	mov r0, #2
	str r0, [sp, #0xc]
	mov r0, #1
	str r0, [sp, #0x10]
	mov r0, #0
	str r0, [sp, #0x14]
	ldr r0, [r5, #0x54]
	ldr r1, [r5, #0x58]
	ldr r3, [sp, #0x20]
	add r2, r7, #0
	bl MapPropOneShotAnimationManager_LoadPropAnimations
	add sp, #0x28
	pop {r3, r4, r5, r6, r7, pc}
_0224BFB4:
	bl GF_AssertFail
	add sp, #0x28
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224BFBC: .word ov02_022536E8
	thumb_func_end ov02_0224BF58

	thumb_func_start ov02_0224BFC0
ov02_0224BFC0: ; 0x0224BFC0
	ldr r3, _0224BFC8 ; =MapPropOneShotAnimationManager_PlayAnimation
	ldr r0, [r0, #0x58]
	mov r2, #0
	bx r3
	.balign 4, 0
_0224BFC8: .word MapPropOneShotAnimationManager_PlayAnimation
	thumb_func_end ov02_0224BFC0

	thumb_func_start ov02_0224BFCC
ov02_0224BFCC: ; 0x0224BFCC
	ldr r3, _0224BFD4 ; =MapPropOneShotAnimationManager_PlayAnimation
	ldr r0, [r0, #0x58]
	mov r2, #1
	bx r3
	.balign 4, 0
_0224BFD4: .word MapPropOneShotAnimationManager_PlayAnimation
	thumb_func_end ov02_0224BFCC

	thumb_func_start CreateFieldEscapeRopeTaskEnv
CreateFieldEscapeRopeTaskEnv: ; 0x0224BFD8
	push {r3, r4, r5, lr}
	add r5, r0, #0
	add r0, r1, #0
	mov r1, #0x30
	bl ov02_0224C660
	add r4, r0, #0
	mov r0, #0
	str r0, [r4, #0xc]
	str r5, [r4, #0x24]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetMapObject
	str r0, [r4, #0x20]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetState
	sub r0, r0, #1
	cmp r0, #1
	bhi _0224C006
	mov r0, #0
	str r0, [r4, #8]
	b _0224C01A
_0224C006:
	add r0, r5, #0
	bl FollowMon_IsActive
	cmp r0, #0
	beq _0224C016
	mov r0, #1
	str r0, [r4, #8]
	b _0224C01A
_0224C016:
	mov r0, #0
	str r0, [r4, #8]
_0224C01A:
	add r0, r4, #0
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end CreateFieldEscapeRopeTaskEnv

	thumb_func_start Task_FieldEscapeRope
Task_FieldEscapeRope: ; 0x0224C020
	push {r3, r4, r5, r6, r7, lr}
	add r6, r0, #0
	bl TaskManager_GetFieldSystem
	add r7, r0, #0
	add r0, r6, #0
	bl TaskManager_GetEnvironment
	add r5, r0, #0
_0224C032:
	ldr r3, [r5]
	add r0, r6, #0
	lsl r4, r3, #2
	ldr r3, _0224C058 ; =ov02_02253700
	add r1, r7, #0
	ldr r3, [r3, r4]
	add r2, r5, #0
	blx r3
	add r4, r0, #0
	cmp r4, #2
	bne _0224C04E
	add r0, r5, #0
	bl Heap_Free
_0224C04E:
	cmp r4, #1
	beq _0224C032
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224C058: .word ov02_02253700
	thumb_func_end Task_FieldEscapeRope

	thumb_func_start ov02_0224C05C
ov02_0224C05C: ; 0x0224C05C
	push {r3, r4, r5, lr}
	add r5, r1, #0
	add r0, r5, #0
	mov r1, #4
	add r4, r2, #0
	bl ov01_021FCD2C
	ldr r2, _0224C0A4 ; =0xFFF6A000
	str r0, [r4, #0x1c]
	mov r1, #1
	mov r3, #0xf
	bl ov01_021FCD8C
	ldr r0, [r4, #0x20]
	ldr r1, _0224C0A8 ; =ov02_02253820
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C092
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C0A8 ; =ov02_02253820
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C092:
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	ldr r0, _0224C0AC ; =SEQ_SE_DP_KAIDAN2
	bl PlaySE
	mov r0, #0
	pop {r3, r4, r5, pc}
	nop
_0224C0A4: .word 0xFFF6A000
_0224C0A8: .word ov02_02253820
_0224C0AC: .word SEQ_SE_DP_KAIDAN2
	thumb_func_end ov02_0224C05C

	thumb_func_start ov02_0224C0B0
ov02_0224C0B0: ; 0x0224C0B0
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C0C8
	add sp, #0xc
	mov r0, #0
	pop {r4, r5, pc}
_0224C0C8:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C144 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C0F0
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C144 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C0F0:
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
	cmp r0, #8
	bge _0224C100
	add sp, #0xc
	mov r0, #0
	pop {r4, r5, pc}
_0224C100:
	ldr r0, [r4, #0xc]
	cmp r0, #2
	bne _0224C120
	mov r0, #6
	str r0, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0
	add r1, r0, #0
	add r2, r0, #0
	add r3, r0, #0
	bl BeginNormalPaletteFade
	b _0224C138
_0224C120:
	mov r0, #6
	str r0, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0
	ldr r3, _0224C148 ; =0x00007FFF
	add r1, r0, #0
	add r2, r0, #0
	bl BeginNormalPaletteFade
_0224C138:
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	.balign 4, 0
_0224C144: .word ov02_02253794
_0224C148: .word 0x00007FFF
	thumb_func_end ov02_0224C0B0

	thumb_func_start ov02_0224C14C
ov02_0224C14C: ; 0x0224C14C
	push {r3, r4, r5, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #1
	bne _0224C184
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C1B4 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C184
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C1B4 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C184:
	bl IsPaletteFadeFinished
	cmp r0, #0
	bne _0224C190
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224C190:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C1A2
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
_0224C1A2:
	ldr r0, [r4, #0x1c]
	bl ov01_021FCD78
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r3, r4, r5, pc}
	nop
_0224C1B4: .word ov02_02253794
	thumb_func_end ov02_0224C14C

	thumb_func_start ov02_0224C1B8
ov02_0224C1B8: ; 0x0224C1B8
	push {r3, r4, r5, lr}
	add r5, r0, #0
	ldr r0, [r1, #0xc]
	add r4, r2, #0
	bl Save_LocalFieldData_Get
	bl LocalFieldData_GetSpecialSpawnWarpPtr
	add r1, r0, #0
	ldr r2, [r4, #0xc]
	add r0, r5, #0
	bl sub_02053B04
	mov r0, #2
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224C1B8

	thumb_func_start ov02_0224C1D8
ov02_0224C1D8: ; 0x0224C1D8
	push {r4, r5, r6, lr}
	add r5, r0, #0
	add r0, r1, #0
	mov r1, #0x30
	add r6, r2, #0
	bl ov02_0224C660
	add r4, r0, #0
	str r6, [r4, #0xc]
	str r5, [r4, #0x24]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetMapObject
	str r0, [r4, #0x20]
	add r0, r4, #0
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_0224C1D8

	thumb_func_start ov02_0224C1F8
ov02_0224C1F8: ; 0x0224C1F8
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r5, #0
	bl TaskManager_GetEnvironment
	ldr r7, _0224C230 ; =ov02_022536F0
	add r4, r0, #0
_0224C20C:
	ldr r3, [r4]
	add r0, r5, #0
	lsl r3, r3, #2
	ldr r3, [r7, r3]
	add r1, r6, #0
	add r2, r4, #0
	blx r3
	cmp r0, #2
	bne _0224C228
	add r0, r4, #0
	bl Heap_Free
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0224C228:
	cmp r0, #1
	beq _0224C20C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224C230: .word ov02_022536F0
	thumb_func_end ov02_0224C1F8

	thumb_func_start ov02_0224C234
ov02_0224C234: ; 0x0224C234
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r2, #0
	ldr r0, [r4, #0xc]
	add r5, r1, #0
	cmp r0, #2
	bne _0224C25A
	mov r0, #6
	str r0, [sp]
	mov r1, #1
	str r1, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0
	add r2, r1, #0
	add r3, r0, #0
	bl BeginNormalPaletteFade
	b _0224C270
_0224C25A:
	mov r0, #6
	str r0, [sp]
	mov r1, #1
	str r1, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	ldr r3, _0224C29C ; =0x00007FFF
	mov r0, #0
	add r2, r1, #0
	bl BeginNormalPaletteFade
_0224C270:
	add r0, r5, #0
	mov r1, #4
	bl ov01_021FCD2C
	mov r1, #1
	ldr r2, _0224C2A0 ; =0xFFF6A000
	str r0, [r4, #0x1c]
	add r3, r1, #0
	bl ov01_021FCD8C
	ldr r0, [r4, #0x20]
	ldr r1, _0224C2A4 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	nop
_0224C29C: .word 0x00007FFF
_0224C2A0: .word 0xFFF6A000
_0224C2A4: .word ov02_02253794
	thumb_func_end ov02_0224C234

	thumb_func_start ov02_0224C2A8
ov02_0224C2A8: ; 0x0224C2A8
	push {r4, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_IsFinish
	cmp r0, #1
	bne _0224C2C6
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C2E8 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
_0224C2C6:
	bl IsPaletteFadeFinished
	cmp r0, #0
	bne _0224C2D2
	mov r0, #0
	pop {r4, pc}
_0224C2D2:
	ldr r0, [r4, #0x1c]
	mov r1, #2
	mov r2, #0
	mov r3, #0x3c
	bl ov01_021FCD8C
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r4, pc}
	.balign 4, 0
_0224C2E8: .word ov02_02253794
	thumb_func_end ov02_0224C2A8

	thumb_func_start ov02_0224C2EC
ov02_0224C2EC: ; 0x0224C2EC
	push {r4, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C2FE
	mov r0, #0
	pop {r4, pc}
_0224C2FE:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
	cmp r0, #4
	ldr r0, [r4, #0x20]
	bge _0224C31C
	ldr r1, _0224C330 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	mov r0, #0
	pop {r4, pc}
_0224C31C:
	ldr r1, _0224C334 ; =ov02_02253884
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	nop
_0224C330: .word ov02_02253794
_0224C334: .word ov02_02253884
	thumb_func_end ov02_0224C2EC

	thumb_func_start ov02_0224C338
ov02_0224C338: ; 0x0224C338
	push {r4, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C34A
	mov r0, #0
	pop {r4, pc}
_0224C34A:
	ldr r0, [r4, #0x1c]
	bl ov01_021FCD6C
	cmp r0, #0
	bne _0224C358
	mov r0, #0
	pop {r4, pc}
_0224C358:
	ldr r0, [r4, #0x1c]
	bl ov01_021FCD78
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	mov r0, #2
	pop {r4, pc}
	thumb_func_end ov02_0224C338

	thumb_func_start FieldMoveTask_CreateDigEnvironment
FieldMoveTask_CreateDigEnvironment: ; 0x0224C368
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	add r6, r1, #0
	add r0, r3, #0
	mov r1, #0x30
	add r7, r2, #0
	bl ov02_0224C660
	add r4, r0, #0
	mov r0, #1
	str r0, [r4, #0xc]
	str r5, [r4, #0x24]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetMapObject
	str r0, [r4, #0x20]
	add r0, r5, #0
	str r6, [r4, #0x28]
	bl ov01_02206268
	cmp r0, #0
	beq _0224C3A4
	add r0, r5, #0
	bl ov01_022062CC
	cmp r7, r0
	bne _0224C3A4
	mov r0, #1
	str r0, [r4, #8]
	b _0224C3A8
_0224C3A4:
	mov r0, #0
	str r0, [r4, #8]
_0224C3A8:
	add r0, r4, #0
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end FieldMoveTask_CreateDigEnvironment

	thumb_func_start Task_FieldDig
Task_FieldDig: ; 0x0224C3AC
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r7, #0
	bl TaskManager_GetEnvironment
	add r4, r0, #0
	add r0, r7, #0
	bl TaskManager_GetStatePtr
	add r5, r0, #0
	ldr r0, [r5]
	cmp r0, #3
	bhi _0224C4A2
	add r1, r0, r0
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0224C3D8: ; jump table
	.short _0224C3E0 - _0224C3D8 - 2 ; case 0
	.short _0224C3F8 - _0224C3D8 - 2 ; case 1
	.short _0224C42A - _0224C3D8 - 2 ; case 2
	.short _0224C45C - _0224C3D8 - 2 ; case 3
_0224C3E0:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C3F0
	ldr r1, _0224C4A8 ; =ov01_02205A60
	add r0, r7, #0
	mov r2, #0
	bl TaskManager_Call
_0224C3F0:
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	b _0224C4A2
_0224C3F8:
	add r0, r0, #1
	str r0, [r5]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C42A
	add r0, r6, #0
	mov r1, #4
	bl ov02_02250780
	cmp r0, #0
	beq _0224C41E
	mov r0, #0x42
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	mov r1, #1
	mov r4, #2
	bl FieldSystem_UnkSub108_AddMonMood
	b _0224C420
_0224C41E:
	mov r4, #1
_0224C420:
	add r0, r6, #0
	add r1, r4, #0
	bl ov02_022507B4
	b _0224C4A2
_0224C42A:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C456
	ldr r0, [r4, #0x28]
	mov r1, #5
	mov r2, #0
	bl GetMonData
	str r0, [sp]
	ldr r0, [r4, #0x28]
	mov r1, #0x70
	mov r2, #0
	bl GetMonData
	add r1, r0, #0
	ldr r0, [sp]
	lsl r1, r1, #0x18
	lsl r0, r0, #0x10
	lsr r0, r0, #0x10
	lsr r1, r1, #0x18
	bl PlayCry
_0224C456:
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
_0224C45C:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C482
	bl IsCryFinished
	cmp r0, #0
	beq _0224C46E
	mov r5, #0
	b _0224C494
_0224C46E:
	ldr r3, [r4]
	add r0, r7, #0
	lsl r5, r3, #2
	ldr r3, _0224C4AC ; =ov02_02253710
	add r1, r6, #0
	ldr r3, [r3, r5]
	add r2, r4, #0
	blx r3
	add r5, r0, #0
	b _0224C494
_0224C482:
	ldr r3, [r4]
	add r0, r7, #0
	lsl r5, r3, #2
	ldr r3, _0224C4B0 ; =ov02_02253754
	add r1, r6, #0
	ldr r3, [r3, r5]
	add r2, r4, #0
	blx r3
	add r5, r0, #0
_0224C494:
	cmp r5, #2
	bne _0224C49E
	add r0, r4, #0
	bl Heap_Free
_0224C49E:
	cmp r5, #1
	beq _0224C45C
_0224C4A2:
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224C4A8: .word ov01_02205A60
_0224C4AC: .word ov02_02253710
_0224C4B0: .word ov02_02253754
	thumb_func_end Task_FieldDig

	thumb_func_start ov02_0224C4B4
ov02_0224C4B4: ; 0x0224C4B4
	push {r3, r4, r5, lr}
	add r5, r1, #0
	ldr r0, [r5, #0x40]
	add r4, r2, #0
	bl PlayerAvatar_GetGender
	add r3, r0, #0
	ldr r2, [r4, #0x28]
	add r0, r5, #0
	mov r1, #0
	bl ov02_02249458
	str r0, [r4, #0x18]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224C4B4

	thumb_func_start ov02_0224C4D8
ov02_0224C4D8: ; 0x0224C4D8
	push {r4, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x18]
	bl ov02_0224953C
	cmp r0, #0
	bne _0224C4EA
	mov r0, #0
	pop {r4, pc}
_0224C4EA:
	ldr r0, [r4, #0x18]
	bl ov02_02249548
	ldr r0, [r4, #0x24]
	bl ov01_02205D68
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_0224C4D8

	thumb_func_start FieldMoveTask_CreateTeleportEnvironment
FieldMoveTask_CreateTeleportEnvironment: ; 0x0224C500
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	add r6, r1, #0
	add r0, r3, #0
	mov r1, #0x30
	add r7, r2, #0
	bl ov02_0224C660
	add r4, r0, #0
	mov r0, #2
	str r0, [r4, #0xc]
	str r5, [r4, #0x24]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetMapObject
	str r0, [r4, #0x20]
	str r6, [r4, #0x28]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetState
	sub r0, r0, #1
	cmp r0, #1
	bhi _0224C534
	mov r0, #0
	str r0, [r4, #8]
	b _0224C552
_0224C534:
	add r0, r5, #0
	bl ov01_02206268
	cmp r0, #0
	beq _0224C54E
	add r0, r5, #0
	bl ov01_022062CC
	cmp r7, r0
	bne _0224C54E
	mov r0, #1
	str r0, [r4, #8]
	b _0224C552
_0224C54E:
	mov r0, #0
	str r0, [r4, #8]
_0224C552:
	add r0, r4, #0
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end FieldMoveTask_CreateTeleportEnvironment

	thumb_func_start Task_FieldTeleport
Task_FieldTeleport: ; 0x0224C558
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r7, #0
	bl TaskManager_GetEnvironment
	add r4, r0, #0
	add r0, r7, #0
	bl TaskManager_GetStatePtr
	add r5, r0, #0
	ldr r0, [r5]
	cmp r0, #3
	bhi _0224C64E
	add r1, r0, r0
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0224C584: ; jump table
	.short _0224C58C - _0224C584 - 2 ; case 0
	.short _0224C5A4 - _0224C584 - 2 ; case 1
	.short _0224C5D6 - _0224C584 - 2 ; case 2
	.short _0224C608 - _0224C584 - 2 ; case 3
_0224C58C:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C59C
	ldr r1, _0224C654 ; =ov01_02205A60
	add r0, r7, #0
	mov r2, #0
	bl TaskManager_Call
_0224C59C:
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	b _0224C64E
_0224C5A4:
	add r0, r0, #1
	str r0, [r5]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C5D6
	add r0, r6, #0
	mov r1, #0xe
	bl ov02_02250780
	cmp r0, #0
	beq _0224C5CA
	mov r0, #0x42
	lsl r0, r0, #2
	ldr r0, [r6, r0]
	mov r1, #1
	mov r4, #2
	bl FieldSystem_UnkSub108_AddMonMood
	b _0224C5CC
_0224C5CA:
	mov r4, #1
_0224C5CC:
	add r0, r6, #0
	add r1, r4, #0
	bl ov02_022507B4
	b _0224C64E
_0224C5D6:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C602
	ldr r0, [r4, #0x28]
	mov r1, #5
	mov r2, #0
	bl GetMonData
	str r0, [sp]
	ldr r0, [r4, #0x28]
	mov r1, #0x70
	mov r2, #0
	bl GetMonData
	add r1, r0, #0
	ldr r0, [sp]
	lsl r1, r1, #0x18
	lsl r0, r0, #0x10
	lsr r0, r0, #0x10
	lsr r1, r1, #0x18
	bl PlayCry
_0224C602:
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
_0224C608:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C62E
	bl IsCryFinished
	cmp r0, #0
	beq _0224C61A
	mov r5, #0
	b _0224C640
_0224C61A:
	ldr r3, [r4]
	add r0, r7, #0
	lsl r5, r3, #2
	ldr r3, _0224C658 ; =ov02_0225373C
	add r1, r6, #0
	ldr r3, [r3, r5]
	add r2, r4, #0
	blx r3
	add r5, r0, #0
	b _0224C640
_0224C62E:
	ldr r3, [r4]
	add r0, r7, #0
	lsl r5, r3, #2
	ldr r3, _0224C65C ; =ov02_02253724
	add r1, r6, #0
	ldr r3, [r3, r5]
	add r2, r4, #0
	blx r3
	add r5, r0, #0
_0224C640:
	cmp r5, #2
	bne _0224C64A
	add r0, r4, #0
	bl Heap_Free
_0224C64A:
	cmp r5, #1
	beq _0224C608
_0224C64E:
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224C654: .word ov01_02205A60
_0224C658: .word ov02_0225373C
_0224C65C: .word ov02_02253724
	thumb_func_end Task_FieldTeleport

	thumb_func_start ov02_0224C660
ov02_0224C660: ; 0x0224C660
	push {r3, r4, r5, lr}
	add r5, r1, #0
	bl Heap_AllocAtEnd
	add r4, r0, #0
	bne _0224C670
	bl GF_AssertFail
_0224C670:
	add r0, r4, #0
	mov r1, #0
	add r2, r5, #0
	bl memset
	add r0, r4, #0
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224C660

	thumb_func_start ov02_0224C680
ov02_0224C680: ; 0x0224C680
	push {r4, lr}
	add r4, r2, #0
	add r0, r1, #0
	mov r1, #2
	mov r2, #1
	bl ov01_022060B8
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r4, pc}
	thumb_func_end ov02_0224C680

	thumb_func_start ov02_0224C698
ov02_0224C698: ; 0x0224C698
	push {r3, r4, r5, lr}
	add r5, r1, #0
	add r0, r5, #0
	mov r1, #4
	add r4, r2, #0
	bl ov01_021FCD2C
	ldr r2, _0224C6D0 ; =0xFFF6A000
	mov r1, #1
	mov r3, #0xf
	str r0, [r4, #0x1c]
	bl ov01_021FCD8C
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C6D4 ; =ov02_02253770
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	ldr r0, _0224C6D8 ; =SEQ_SE_DP_TELE
	bl PlaySE
	mov r0, #0
	pop {r3, r4, r5, pc}
	nop
_0224C6D0: .word 0xFFF6A000
_0224C6D4: .word ov02_02253770
_0224C6D8: .word SEQ_SE_DP_TELE
	thumb_func_end ov02_0224C698

	thumb_func_start ov02_0224C6DC
ov02_0224C6DC: ; 0x0224C6DC
	push {r3, r4, r5, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x14]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C6F0
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224C6F0:
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C718 ; =ov02_02253820
	bl EventObjectMovementMan_Create
	add r5, #0xe4
	str r0, [r4, #0x10]
	ldr r0, [r5]
	ldr r1, _0224C718 ; =ov02_02253820
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r3, r4, r5, pc}
	nop
_0224C718: .word ov02_02253820
	thumb_func_end ov02_0224C6DC

	thumb_func_start ov02_0224C71C
ov02_0224C71C: ; 0x0224C71C
	push {r4, lr}
	add r0, r1, #0
	mov r1, #4
	add r4, r2, #0
	bl ov01_021FCD2C
	ldr r2, _0224C750 ; =0xFFF6A000
	str r0, [r4, #0x1c]
	mov r1, #1
	mov r3, #0xf
	bl ov01_021FCD8C
	ldr r0, [r4, #0x20]
	ldr r1, _0224C754 ; =ov02_02253820
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	ldr r0, _0224C758 ; =SEQ_SE_DP_TELE
	bl PlaySE
	mov r0, #0
	pop {r4, pc}
	nop
_0224C750: .word 0xFFF6A000
_0224C754: .word ov02_02253820
_0224C758: .word SEQ_SE_DP_TELE
	thumb_func_end ov02_0224C71C

	thumb_func_start ov02_0224C75C
ov02_0224C75C: ; 0x0224C75C
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C774
	add sp, #0xc
	mov r0, #0
	pop {r4, r5, pc}
_0224C774:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C7D0 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C79C
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C7D0 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C79C:
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
	cmp r0, #8
	bge _0224C7AC
	add sp, #0xc
	mov r0, #0
	pop {r4, r5, pc}
_0224C7AC:
	mov r0, #6
	str r0, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0
	add r1, r0, #0
	add r2, r0, #0
	add r3, r0, #0
	bl BeginNormalPaletteFade
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	.balign 4, 0
_0224C7D0: .word ov02_02253794
	thumb_func_end ov02_0224C75C

	thumb_func_start ov02_0224C7D4
ov02_0224C7D4: ; 0x0224C7D4
	push {r3, r4, r5, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #1
	bne _0224C80C
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C83C ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C80C
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C83C ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C80C:
	bl IsPaletteFadeFinished
	cmp r0, #0
	bne _0224C818
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224C818:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C82A
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
_0224C82A:
	ldr r0, [r4, #0x1c]
	bl ov01_021FCD78
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r3, r4, r5, pc}
	nop
_0224C83C: .word ov02_02253794
	thumb_func_end ov02_0224C7D4

	thumb_func_start ov02_0224C840
ov02_0224C840: ; 0x0224C840
	push {r4, r5, r6, r7, lr}
	sub sp, #0x14
	add r5, r0, #0
	ldr r0, [r1, #0xc]
	add r4, r2, #0
	bl Save_LocalFieldData_Get
	add r6, r0, #0
	bl LocalFieldData_GetBlackoutSpawn
	add r1, sp, #0
	add r7, r0, #0
	bl GetFlyWarpData
	add r0, r6, #0
	bl LocalFieldData_GetSpecialSpawnWarpPtr
	add r1, r0, #0
	add r0, r7, #0
	bl GetSpecialSpawnWarpData
	ldr r2, [r4, #0xc]
	add r0, r5, #0
	add r1, sp, #0
	bl sub_02053B04
	mov r0, #2
	add sp, #0x14
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224C840

	thumb_func_start ov02_0224C87C
ov02_0224C87C: ; 0x0224C87C
	push {r3, r4, r5, lr}
	add r5, r1, #0
	add r0, r5, #0
	mov r1, #4
	add r4, r2, #0
	bl ov01_021FCD2C
	ldr r2, _0224C8C4 ; =0xFFF6A000
	str r0, [r4, #0x1c]
	mov r1, #1
	mov r3, #0xf
	bl ov01_021FCD8C
	ldr r0, [r4, #0x20]
	ldr r1, _0224C8C8 ; =ov02_022537DC
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C8B2
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C8C8 ; =ov02_022537DC
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C8B2:
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	ldr r0, _0224C8CC ; =SEQ_SE_DP_KAIDAN2
	bl PlaySE
	mov r0, #0
	pop {r3, r4, r5, pc}
	nop
_0224C8C4: .word 0xFFF6A000
_0224C8C8: .word ov02_022537DC
_0224C8CC: .word SEQ_SE_DP_KAIDAN2
	thumb_func_end ov02_0224C87C

	thumb_func_start ov02_0224C8D0
ov02_0224C8D0: ; 0x0224C8D0
	push {r3, r4, r5, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C8E4
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224C8E4:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C938 ; =ov02_022537B8
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C90E
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	ldr r1, _0224C938 ; =ov02_022537B8
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C90E:
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetState
	cmp r0, #2
	beq _0224C92E
	ldr r0, [r4, #8]
	cmp r0, #0
	ldr r0, [r4, #0x24]
	beq _0224C928
	bl ov02_0224DDF4
	str r0, [r4, #0x2c]
	b _0224C92E
_0224C928:
	bl ov02_0224DDE0
	str r0, [r4, #0x2c]
_0224C92E:
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224C938: .word ov02_022537B8
	thumb_func_end ov02_0224C8D0

	thumb_func_start ov02_0224C93C
ov02_0224C93C: ; 0x0224C93C
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #0
	bne _0224C954
	add sp, #0xc
	mov r0, #0
	pop {r4, r5, pc}
_0224C954:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224C9B0 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C97C
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r5, #0xe4
	ldr r0, [r5]
	ldr r1, _0224C9B0 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C97C:
	ldr r0, [r4, #4]
	add r0, r0, #1
	str r0, [r4, #4]
	cmp r0, #8
	bge _0224C98C
	add sp, #0xc
	mov r0, #0
	pop {r4, r5, pc}
_0224C98C:
	mov r0, #6
	str r0, [sp]
	mov r0, #1
	str r0, [sp, #4]
	mov r0, #4
	str r0, [sp, #8]
	mov r0, #0
	ldr r3, _0224C9B4 ; =0x00007FFF
	add r1, r0, #0
	add r2, r0, #0
	bl BeginNormalPaletteFade
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #0
	add sp, #0xc
	pop {r4, r5, pc}
	.balign 4, 0
_0224C9B0: .word ov02_02253794
_0224C9B4: .word 0x00007FFF
	thumb_func_end ov02_0224C93C

	thumb_func_start ov02_0224C9B8
ov02_0224C9B8: ; 0x0224C9B8
	push {r3, r4, r5, lr}
	add r4, r2, #0
	ldr r0, [r4, #0x10]
	add r5, r1, #0
	bl EventObjectMovementMan_IsFinish
	cmp r0, #1
	bne _0224C9F2
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r4, #0x20]
	ldr r1, _0224CA34 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x10]
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224C9F2
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	ldr r1, _0224CA34 ; =ov02_02253794
	bl EventObjectMovementMan_Create
	str r0, [r4, #0x14]
_0224C9F2:
	bl IsPaletteFadeFinished
	cmp r0, #0
	bne _0224C9FE
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224C9FE:
	ldr r0, [r4, #0x10]
	bl EventObjectMovementMan_Delete
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetState
	cmp r0, #2
	beq _0224CA18
	ldr r0, [r4, #0x2c]
	bl ov02_0224DE08
	mov r0, #0
	str r0, [r4, #0x2c]
_0224CA18:
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224CA24
	ldr r0, [r4, #0x14]
	bl EventObjectMovementMan_Delete
_0224CA24:
	ldr r0, [r4, #0x1c]
	bl ov01_021FCD78
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	mov r0, #1
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224CA34: .word ov02_02253794
	thumb_func_end ov02_0224C9B8

	thumb_func_start ov02_0224CA38
ov02_0224CA38: ; 0x0224CA38
	push {r3, r4, r5, lr}
	add r5, r0, #0
	ldr r0, [r1, #0xc]
	add r4, r2, #0
	bl Save_LocalFieldData_Get
	bl LocalFieldData_GetSpecialSpawnWarpPtr
	add r1, r0, #0
	ldr r2, [r4, #0xc]
	add r0, r5, #0
	bl sub_02053B04
	mov r0, #2
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224CA38

	thumb_func_start ov02_0224CA58
ov02_0224CA58: ; 0x0224CA58
	push {r4, r5, r6, r7}
	add r3, r0, #0
	add r0, r2, #0
	sub r0, r0, #1
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	cmp r2, #0
	beq _0224CAB4
	add r6, r3, r1
	sub r7, r1, #1
_0224CA6C:
	sub r1, r6, #1
	ldrb r2, [r1]
	mov r1, #1
	add r5, r7, #0
	and r1, r2
	lsl r1, r1, #0x18
	lsr r4, r1, #0x18
	cmp r7, #0
	ble _0224CA9A
_0224CA7E:
	ldrb r1, [r3, r5]
	add r2, r3, r5
	sub r2, r2, #1
	asr r1, r1, #1
	strb r1, [r3, r5]
	ldrb r2, [r2]
	ldrb r1, [r3, r5]
	lsl r2, r2, #0x1f
	lsr r2, r2, #0x18
	orr r1, r2
	strb r1, [r3, r5]
	sub r5, r5, #1
	cmp r5, #0
	bgt _0224CA7E
_0224CA9A:
	ldrb r1, [r3, r5]
	asr r1, r1, #1
	strb r1, [r3, r5]
	ldrb r2, [r3, r5]
	lsl r1, r4, #7
	orr r1, r2
	strb r1, [r3, r5]
	add r1, r0, #0
	sub r0, r0, #1
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	cmp r1, #0
	bne _0224CA6C
_0224CAB4:
	pop {r4, r5, r6, r7}
	bx lr
	thumb_func_end ov02_0224CA58

	thumb_func_start ov02_0224CAB8
ov02_0224CAB8: ; 0x0224CAB8
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x10
	add r5, r0, #0
	add r6, r2, #0
	str r1, [sp]
	add r7, r3, #0
	bl WallpaperPasswordBank_GetCount
	add r4, r0, #0
	add r0, r5, #0
	add r1, r6, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	strh r0, [r1, #4]
	add r0, r5, #0
	add r1, r7, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	strh r0, [r1, #6]
	add r1, sp, #0x18
	ldrh r1, [r1, #0x10]
	add r0, r5, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	strh r0, [r1, #8]
	add r1, sp, #0x18
	ldrh r1, [r1, #0x14]
	add r0, r5, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	mov r2, #0
	strh r0, [r1, #0xa]
	add r3, sp, #8
	add r5, sp, #4
	add r7, r2, #0
_0224CB06:
	ldrsh r0, [r3, r7]
	cmp r0, #0
	bge _0224CB14
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CB14:
	cmp r2, #0
	ble _0224CB48
	mov r6, #1
	mvn r6, r6
	ldrsh r6, [r3, r6]
	cmp r0, r6
	blt _0224CB34
	sub r0, r0, r6
	cmp r0, #0xff
	ble _0224CB30
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CB30:
	strb r0, [r5]
	b _0224CB5A
_0224CB34:
	sub r0, r6, r0
	sub r0, r4, r0
	cmp r0, #0xff
	ble _0224CB44
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CB44:
	strb r0, [r5]
	b _0224CB5A
_0224CB48:
	mov r0, #4
	ldrsh r0, [r1, r0]
	cmp r0, #0xff
	ble _0224CB58
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CB58:
	strb r0, [r1]
_0224CB5A:
	add r2, r2, #1
	add r3, r3, #2
	add r5, r5, #1
	cmp r2, #4
	blt _0224CB06
	add r0, sp, #4
	mov r1, #4
	mov r2, #5
	bl ov02_0224CA58
	mov r2, #0
	add r1, sp, #4
	add r4, sp, #4
	mov r3, #0xf0
_0224CB76:
	ldrb r5, [r4, #3]
	ldrb r0, [r1]
	add r2, r2, #1
	asr r6, r5, #4
	and r5, r3
	orr r5, r6
	eor r0, r5
	strb r0, [r1]
	add r1, r1, #1
	cmp r2, #3
	blt _0224CB76
	add r2, sp, #4
	ldrb r3, [r2, #3]
	mov r2, #0xf
	add r0, sp, #4
	and r2, r3
	lsl r2, r2, #0x18
	mov r1, #3
	lsr r2, r2, #0x18
	bl ov02_0224CA58
	add r1, sp, #4
	ldrb r5, [r1]
	mov r0, #0xf
	add r4, r5, #0
	and r4, r0
	cmp r4, #8
	blt _0224CBB4
	add sp, #0x10
	sub r0, #0x10
	pop {r3, r4, r5, r6, r7, pc}
_0224CBB4:
	ldrb r0, [r1, #1]
	eor r0, r5
	strb r0, [r1, #1]
	ldrb r0, [r1, #2]
	eor r0, r5
	strb r0, [r1, #2]
	ldrb r2, [r1, #1]
	ldrb r3, [r1, #2]
	lsl r0, r2, #8
	add r6, r0, #0
	ldr r0, [sp]
	orr r6, r3
	cmp r0, r6
	bne _0224CBEE
	mov r0, #0xf0
	and r0, r5
	asr r0, r0, #4
	cmp r0, #6
	bne _0224CBEE
	ldrb r0, [r1, #3]
	add r1, r5, r2
	mul r1, r3
	lsl r1, r1, #0x18
	lsr r1, r1, #0x18
	cmp r0, r1
	bne _0224CBEE
	add sp, #0x10
	add r0, r4, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224CBEE:
	mov r0, #0
	mvn r0, r0
	add sp, #0x10
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224CAB8

	thumb_func_start ov02_0224CBF8
ov02_0224CBF8: ; 0x0224CBF8
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x10
	add r5, r0, #0
	add r6, r2, #0
	str r1, [sp]
	add r7, r3, #0
	bl WallpaperPasswordBank_GetCount
	add r4, r0, #0
	add r0, r5, #0
	add r1, r6, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	strh r0, [r1, #4]
	add r0, r5, #0
	add r1, r7, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	strh r0, [r1, #6]
	add r1, sp, #0x18
	ldrh r1, [r1, #0x10]
	add r0, r5, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	strh r0, [r1, #8]
	add r1, sp, #0x18
	ldrh r1, [r1, #0x14]
	add r0, r5, #0
	bl WallpaperPasswordBank_GetIndexOfWord
	add r1, sp, #4
	mov r2, #0
	strh r0, [r1, #0xa]
	add r3, sp, #8
	add r5, sp, #4
	add r7, r2, #0
_0224CC46:
	ldrsh r0, [r3, r7]
	cmp r0, #0
	bge _0224CC54
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CC54:
	cmp r2, #0
	ble _0224CC88
	mov r6, #1
	mvn r6, r6
	ldrsh r6, [r3, r6]
	cmp r0, r6
	blt _0224CC74
	sub r0, r0, r6
	cmp r0, #0xff
	ble _0224CC70
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CC70:
	strb r0, [r5]
	b _0224CC9A
_0224CC74:
	sub r0, r6, r0
	sub r0, r4, r0
	cmp r0, #0xff
	ble _0224CC84
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CC84:
	strb r0, [r5]
	b _0224CC9A
_0224CC88:
	mov r0, #4
	ldrsh r0, [r1, r0]
	cmp r0, #0xff
	ble _0224CC98
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CC98:
	strb r0, [r1]
_0224CC9A:
	add r2, r2, #1
	add r3, r3, #2
	add r5, r5, #1
	cmp r2, #4
	blt _0224CC46
	add r0, sp, #4
	mov r1, #4
	mov r2, #5
	bl ov02_0224CA58
	mov r2, #0
	add r1, sp, #4
	add r4, sp, #4
	mov r3, #0xf0
_0224CCB6:
	ldrb r5, [r4, #3]
	ldrb r0, [r1]
	add r2, r2, #1
	asr r6, r5, #4
	and r5, r3
	orr r5, r6
	eor r0, r5
	strb r0, [r1]
	add r1, r1, #1
	cmp r2, #3
	blt _0224CCB6
	add r2, sp, #4
	ldrb r3, [r2, #3]
	mov r2, #0xf
	add r0, sp, #4
	and r2, r3
	lsl r2, r2, #0x18
	mov r1, #3
	lsr r2, r2, #0x18
	bl ov02_0224CA58
	add r1, sp, #4
	ldrb r4, [r1]
	mov r0, #0xf
	and r0, r4
	lsl r2, r0, #0x18
	lsr r2, r2, #0x18
	cmp r2, #8
	blo _0224CCF4
	cmp r2, #0xb
	blo _0224CCFC
_0224CCF4:
	mov r0, #0
	add sp, #0x10
	mvn r0, r0
	pop {r3, r4, r5, r6, r7, pc}
_0224CCFC:
	ldrb r2, [r1, #1]
	eor r2, r4
	strb r2, [r1, #1]
	ldrb r2, [r1, #2]
	eor r2, r4
	strb r2, [r1, #2]
	ldrb r2, [r1, #1]
	ldrb r3, [r1, #2]
	lsl r5, r2, #8
	add r6, r5, #0
	ldr r5, [sp]
	orr r6, r3
	cmp r5, r6
	bne _0224CD30
	mov r5, #0xf0
	and r5, r4
	asr r5, r5, #4
	cmp r5, #6
	bne _0224CD30
	add r2, r4, r2
	mul r2, r3
	lsl r2, r2, #0x18
	ldrb r1, [r1, #3]
	lsr r2, r2, #0x18
	cmp r1, r2
	beq _0224CD34
_0224CD30:
	mov r0, #0
	mvn r0, r0
_0224CD34:
	add sp, #0x10
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224CBF8

	thumb_func_start ov02_0224CD38
ov02_0224CD38: ; 0x0224CD38
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r6, r0, #0
	ldr r0, [sp, #0x24]
	add r7, r1, #0
	str r2, [sp, #8]
	add r5, r3, #0
	bl WallpaperPasswordBank_Create
	add r4, r0, #0
	add r0, r6, #0
	bl PlayerProfile_GetTrainerID_VisibleHalf
	add r1, r0, #0
	str r5, [sp]
	add r0, sp, #0x10
	ldrh r0, [r0, #0x10]
	add r2, r7, #0
	str r0, [sp, #4]
	ldr r3, [sp, #8]
	add r0, r4, #0
	bl ov02_0224CAB8
	add r5, r0, #0
	add r0, r4, #0
	bl WallpaperPasswordBank_Delete
	add r0, r5, #0
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224CD38

	thumb_func_start ov02_0224CD74
ov02_0224CD74: ; 0x0224CD74
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r6, r0, #0
	ldr r0, [sp, #0x24]
	add r7, r1, #0
	str r2, [sp, #8]
	add r5, r3, #0
	bl WallpaperPasswordBank_Create
	add r4, r0, #0
	add r0, r6, #0
	bl PlayerProfile_GetTrainerID_VisibleHalf
	add r1, r0, #0
	str r5, [sp]
	add r0, sp, #0x10
	ldrh r0, [r0, #0x10]
	add r2, r7, #0
	str r0, [sp, #4]
	ldr r3, [sp, #8]
	add r0, r4, #0
	bl ov02_0224CBF8
	add r5, r0, #0
	add r0, r4, #0
	bl WallpaperPasswordBank_Delete
	add r0, r5, #0
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224CD74

	thumb_func_start ov02_0224CDB0
ov02_0224CDB0: ; 0x0224CDB0
	push {r4, r5, r6, lr}
	sub sp, #0x20
	add r6, r1, #0
	mov r1, #0x26
	add r2, sp, #4
	add r3, sp, #0
	add r5, r0, #0
	bl sub_02054C20
	cmp r0, #0
	beq _0224CE1C
	mov r0, #4
	mov r1, #0x18
	bl Heap_AllocAtEnd
	add r4, r0, #0
	strb r6, [r4, #0xc]
	mov r0, #0
	strb r0, [r4, #0xd]
	strb r0, [r4, #0xe]
	strb r0, [r4, #0xf]
	ldr r0, [r5, #0x30]
	bl MapMatrix_GetWidth
	add r1, r0, #0
	ldr r0, [sp]
	add r2, sp, #0x14
	bl sub_02054DC8
	ldr r1, [sp, #4]
	add r0, sp, #8
	bl MapProp_GetTranslation
	add r3, sp, #8
	ldmia r3!, {r0, r1}
	add r2, r4, #0
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r1, [r4]
	ldr r0, [sp, #0x14]
	add r2, r4, #0
	add r0, r1, r0
	str r0, [r4]
	ldr r1, [r4, #8]
	ldr r0, [sp, #0x1c]
	add r0, r1, r0
	str r0, [r4, #8]
	ldr r0, [r5, #0x10]
	ldr r1, _0224CE24 ; =ov02_0224CE28
	bl TaskManager_Call
	add sp, #0x20
	pop {r4, r5, r6, pc}
_0224CE1C:
	bl GF_AssertFail
	add sp, #0x20
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224CE24: .word ov02_0224CE28
	thumb_func_end ov02_0224CDB0

	thumb_func_start ov02_0224CE28
ov02_0224CE28: ; 0x0224CE28
	push {r4, r5, r6, lr}
	sub sp, #0x30
	add r4, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r4, #0
	bl TaskManager_GetEnvironment
	add r4, r0, #0
	ldrb r1, [r4, #0xf]
	cmp r1, #5
	bls _0224CE44
	b _0224CFC0
_0224CE44:
	add r1, r1, r1
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0224CE50: ; jump table
	.short _0224CE5C - _0224CE50 - 2 ; case 0
	.short _0224CEBA - _0224CE50 - 2 ; case 1
	.short _0224CF1C - _0224CE50 - 2 ; case 2
	.short _0224CF64 - _0224CE50 - 2 ; case 3
	.short _0224CF76 - _0224CE50 - 2 ; case 4
	.short _0224CFB6 - _0224CE50 - 2 ; case 5
_0224CE5C:
	ldr r1, [r6, #0x34]
	mov r0, #0x6b
	bl ov01_021FB90C
	ldr r0, [r0]
	bl NNS_G3dGetMdlSet
	cmp r0, #0
	beq _0224CE8E
	add r2, r0, #0
	add r2, #8
	beq _0224CE82
	ldrb r1, [r0, #9]
	cmp r1, #0
	bls _0224CE82
	ldrh r1, [r0, #0xe]
	add r1, r2, r1
	add r1, r1, #4
	b _0224CE84
_0224CE82:
	mov r1, #0
_0224CE84:
	cmp r1, #0
	beq _0224CE8E
	ldr r1, [r1]
	add r5, r0, r1
	b _0224CE90
_0224CE8E:
	mov r5, #0
_0224CE90:
	ldr r0, [r6, #0x34]
	bl ov01_021FB9E0
	mov r1, #0
	str r1, [sp]
	str r5, [sp, #4]
	str r0, [sp, #8]
	mov r0, #1
	str r0, [sp, #0xc]
	str r0, [sp, #0x10]
	str r1, [sp, #0x14]
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #0x10
	mov r3, #0x6b
	bl MapPropOneShotAnimationManager_LoadPropAnimations
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224CFC0
_0224CEBA:
	add r1, sp, #0x18
	mov r0, #0
	str r0, [r1]
	str r0, [r1, #4]
	str r0, [r1, #8]
	ldrb r2, [r4, #0xd]
	mov r1, #0xc
	ldr r0, [r4]
	add r3, r2, #0
	ldr r2, _0224CFC8 ; =ov02_02253DD8
	mul r3, r1
	ldr r2, [r2, r3]
	add r0, r0, r2
	str r0, [sp, #0x24]
	ldrb r2, [r4, #0xd]
	ldr r0, [r4, #4]
	add r3, r2, #0
	ldr r2, _0224CFCC ; =ov02_02253DDC
	mul r3, r1
	ldr r2, [r2, r3]
	add r0, r0, r2
	str r0, [sp, #0x28]
	ldrb r2, [r4, #0xd]
	ldr r0, [r4, #8]
	add r3, r2, #0
	mul r3, r1
	ldr r1, _0224CFD0 ; =ov02_02253DE0
	ldr r1, [r1, r3]
	add r0, r0, r1
	str r0, [sp, #0x2c]
	ldr r0, _0224CFD4 ; =SEQ_SE_DP_BOWA
	bl PlaySE
	ldr r0, [r6, #0x54]
	add r6, #0x9c
	str r0, [sp]
	ldr r0, [r6]
	mov r1, #0x6b
	add r2, sp, #0x24
	add r3, sp, #0x18
	bl MapPropManager_LoadOne
	ldrb r1, [r4, #0xd]
	add r1, r4, r1
	strb r0, [r1, #0x10]
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224CFC0
_0224CF1C:
	ldrb r0, [r4, #0xe]
	cmp r0, #0xf
	bhs _0224CF28
	add r0, r0, #1
	strb r0, [r4, #0xe]
	b _0224CFC0
_0224CF28:
	mov r0, #0
	strb r0, [r4, #0xe]
	ldrb r0, [r4, #0xd]
	add r0, r0, #1
	strb r0, [r4, #0xd]
	ldrb r1, [r4, #0xd]
	ldrb r0, [r4, #0xc]
	cmp r1, r0
	bhs _0224CF40
	mov r0, #1
	strb r0, [r4, #0xf]
	b _0224CFC0
_0224CF40:
	add r0, r6, #0
	add r0, #0x9c
	ldrb r1, [r4, #0x10]
	ldr r0, [r0]
	bl MapPropManager_GetMapPropByIndex_Checked_RequireActive
	bl MapProp_GetRenderSurface
	add r3, r0, #0
	ldr r0, [r6, #0x58]
	mov r1, #0x10
	mov r2, #0
	bl MapPropOneShotAnimationManager_SetAnimationRenderObj
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224CFC0
_0224CF64:
	ldr r0, [r6, #0x58]
	mov r1, #0x10
	mov r2, #0
	bl MapPropOneShotAnimationManager_PlayAnimation
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224CFC0
_0224CF76:
	ldr r0, [r6, #0x58]
	mov r1, #0x10
	bl MapPropOneShotAnimationManager_IsAnimationLoopFinished
	cmp r0, #0
	beq _0224CFC0
	ldr r0, [r6, #0x54]
	ldr r1, [r6, #0x58]
	mov r2, #0x10
	bl MapPropOneShotAnimationManager_UnloadAnimation
	ldrb r0, [r4, #0xc]
	mov r5, #0
	cmp r0, #0
	bls _0224CFAE
_0224CF94:
	add r0, r4, r5
	add r1, r6, #0
	add r1, #0x9c
	ldrb r0, [r0, #0x10]
	ldr r1, [r1]
	bl MapPropManager_RemoveMapPropByIndex
	add r0, r5, #1
	lsl r0, r0, #0x18
	lsr r5, r0, #0x18
	ldrb r0, [r4, #0xc]
	cmp r5, r0
	blo _0224CF94
_0224CFAE:
	ldrb r0, [r4, #0xf]
	add r0, r0, #1
	strb r0, [r4, #0xf]
	b _0224CFC0
_0224CFB6:
	bl Heap_Free
	add sp, #0x30
	mov r0, #1
	pop {r4, r5, r6, pc}
_0224CFC0:
	mov r0, #0
	add sp, #0x30
	pop {r4, r5, r6, pc}
	nop
_0224CFC8: .word ov02_02253DD8
_0224CFCC: .word ov02_02253DDC
_0224CFD0: .word ov02_02253DE0
_0224CFD4: .word SEQ_SE_DP_BOWA
	thumb_func_end ov02_0224CE28

	thumb_func_start ov02_0224CFD8
ov02_0224CFD8: ; 0x0224CFD8
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r7, r2, #0
	bl MapObjectManager_GetFirstActiveObjectByID
	add r6, r0, #0
	add r1, sp, #0
	bl MapObject_CopyPositionVector
	add r0, r6, #0
	bl MapObject_GetXCoord
	add r5, r0, #0
	add r0, r6, #0
	bl MapObject_GetZCoord
	add r4, r0, #0
	add r0, r6, #0
	bl MapObject_GetFacingDirection
	cmp r0, #3
	bhi _0224D028
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224D010: ; jump table
	.short _0224D018 - _0224D010 - 2 ; case 0
	.short _0224D01C - _0224D010 - 2 ; case 1
	.short _0224D020 - _0224D010 - 2 ; case 2
	.short _0224D024 - _0224D010 - 2 ; case 3
_0224D018:
	sub r4, r4, #1
	b _0224D02C
_0224D01C:
	add r4, r4, #1
	b _0224D02C
_0224D020:
	sub r5, r5, #1
	b _0224D02C
_0224D024:
	add r5, r5, #1
	b _0224D02C
_0224D028:
	bl GF_AssertFail
_0224D02C:
	mov r3, #2
	lsl r1, r5, #0x10
	lsl r3, r3, #0xe
	ldr r2, [sp, #4]
	lsl r4, r4, #0x10
	add r1, r1, r3
	add r0, r7, #0
	add r3, r4, r3
	bl Field3dObject_SetPosEx
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224CFD8

	thumb_func_start ov02_0224D044
ov02_0224D044: ; 0x0224D044
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r7, r1, #0
	add r6, r0, #0
	add r1, sp, #0
	bl PlayerAvatar_CopyPositionVector
	add r0, r6, #0
	bl PlayerAvatar_GetXCoord
	add r5, r0, #0
	add r0, r6, #0
	bl PlayerAvatar_GetZCoord
	add r4, r0, #0
	add r0, r6, #0
	bl PlayerAvatar_GetFacingDirection
	cmp r0, #3
	bhi _0224D090
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224D078: ; jump table
	.short _0224D080 - _0224D078 - 2 ; case 0
	.short _0224D084 - _0224D078 - 2 ; case 1
	.short _0224D088 - _0224D078 - 2 ; case 2
	.short _0224D08C - _0224D078 - 2 ; case 3
_0224D080:
	sub r4, r4, #1
	b _0224D094
_0224D084:
	add r4, r4, #1
	b _0224D094
_0224D088:
	sub r5, r5, #1
	b _0224D094
_0224D08C:
	add r5, r5, #1
	b _0224D094
_0224D090:
	bl GF_AssertFail
_0224D094:
	mov r3, #2
	lsl r1, r5, #0x10
	lsl r3, r3, #0xe
	ldr r2, [sp, #4]
	lsl r4, r4, #0x10
	add r1, r1, r3
	add r0, r7, #0
	add r3, r4, r3
	bl Field3dObject_SetPosEx
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224D044

	thumb_func_start ov02_0224D0AC
ov02_0224D0AC: ; 0x0224D0AC
	push {r3, r4, lr}
	sub sp, #0xc
	add r4, r1, #0
	add r1, sp, #0
	bl PlayerAvatar_CopyPositionVector
	ldr r1, [sp]
	ldr r2, [sp, #4]
	ldr r3, [sp, #8]
	add r0, r4, #0
	bl Field3dObject_SetPosEx
	add sp, #0xc
	pop {r3, r4, pc}
	thumb_func_end ov02_0224D0AC

	thumb_func_start ov02_0224D0C8
ov02_0224D0C8: ; 0x0224D0C8
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x10
	add r5, r1, #0
	str r2, [sp, #8]
	add r6, r0, #0
	mov r1, #0
	mov r2, #0xdc
	add r4, r3, #0
	ldr r7, [sp, #0x28]
	bl memset
	add r0, r6, #0
	add r0, #0x78
	mov r1, #0x86
	add r2, r5, #0
	mov r3, #4
	bl Field3dModel_LoadFromFilesystem
	add r1, r6, #0
	add r0, r6, #0
	add r1, #0x78
	bl Field3dObject_InitFromModel
	add r0, r6, #0
	add r0, #0xd8
	str r4, [r0]
	add r0, r6, #0
	add r0, #0xd8
	ldr r0, [r0]
	mov r4, #0
	cmp r0, #0
	bls _0224D13E
	add r0, r6, #0
	add r5, r6, #0
	str r0, [sp, #0xc]
	add r0, #0x78
	add r5, #0x88
	str r0, [sp, #0xc]
_0224D114:
	ldr r3, [sp, #8]
	mov r0, #4
	str r0, [sp]
	ldr r1, [sp, #0xc]
	add r0, r5, #0
	mov r2, #0x86
	add r3, r3, r4
	str r7, [sp, #4]
	bl Field3dModelAnimation_LoadFromFilesystem
	add r0, r6, #0
	add r1, r5, #0
	bl Field3dObject_AddAnimation
	add r0, r6, #0
	add r0, #0xd8
	ldr r0, [r0]
	add r4, r4, #1
	add r5, #0x14
	cmp r4, r0
	blo _0224D114
_0224D13E:
	add sp, #0x10
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D0C8

	thumb_func_start ov02_0224D144
ov02_0224D144: ; 0x0224D144
	push {r3, r4, r5, r6, r7, lr}
	add r6, r0, #0
	add r0, #0x78
	add r7, r1, #0
	bl Field3dModel_Unload
	add r0, r6, #0
	add r0, #0xd8
	ldr r0, [r0]
	mov r4, #0
	cmp r0, #0
	bls _0224D176
	add r5, r6, #0
	add r5, #0x88
_0224D160:
	add r0, r5, #0
	add r1, r7, #0
	bl Field3dModelAnimation_Unload
	add r0, r6, #0
	add r0, #0xd8
	ldr r0, [r0]
	add r4, r4, #1
	add r5, #0x14
	cmp r4, r0
	blo _0224D160
_0224D176:
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224D144

	thumb_func_start ov02_0224D178
ov02_0224D178: ; 0x0224D178
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	add r0, #0xd8
	ldr r0, [r0]
	mov r6, #1
	mov r4, #0
	cmp r0, #0
	bls _0224D1A6
	add r5, r7, #0
	add r5, #0x88
_0224D18C:
	mov r1, #1
	add r0, r5, #0
	lsl r1, r1, #0xc
	bl Field3dModelAnimation_FrameAdvanceAndCheck
	and r6, r0
	add r0, r7, #0
	add r0, #0xd8
	ldr r0, [r0]
	add r4, r4, #1
	add r5, #0x14
	cmp r4, r0
	blo _0224D18C
_0224D1A6:
	add r0, r6, #0
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D178

	thumb_func_start ov02_0224D1AC
ov02_0224D1AC: ; 0x0224D1AC
	push {r3, r4, r5, r6, r7, lr}
	add r6, r0, #0
	add r0, #0xd8
	ldr r0, [r0]
	mov r4, #0
	cmp r0, #0
	bls _0224D1D8
	add r5, r6, #0
	mov r7, #1
	add r5, #0x88
	lsl r7, r7, #0xc
_0224D1C2:
	add r0, r5, #0
	add r1, r7, #0
	bl Field3dModelAnimation_FrameAdvanceAndLoop
	add r0, r6, #0
	add r0, #0xd8
	ldr r0, [r0]
	add r4, r4, #1
	add r5, #0x14
	cmp r4, r0
	blo _0224D1C2
_0224D1D8:
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D1AC

	thumb_func_start ov02_0224D1DC
ov02_0224D1DC: ; 0x0224D1DC
	ldr r3, _0224D1E0 ; =Field3dObject_Draw
	bx r3
	.balign 4, 0
_0224D1E0: .word Field3dObject_Draw
	thumb_func_end ov02_0224D1DC

	thumb_func_start ov02_0224D1E4
ov02_0224D1E4: ; 0x0224D1E4
	push {r3, r4, r5, lr}
	add r4, r2, #0
	add r5, r1, #0
	add r0, r4, #0
	mov r1, #0
	mov r2, #0xf0
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #3
	str r0, [sp]
	add r0, r4, #0
	mov r2, #0
	add r3, r1, #0
	bl ov02_0224D0C8
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D044
	ldr r0, _0224D228 ; =SEQ_SE_DP_FW015
	bl PlaySE
	mov r0, #0
	add r4, #0xec
	str r0, [r4]
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224D228: .word SEQ_SE_DP_FW015
	thumb_func_end ov02_0224D1E4

	thumb_func_start ov02_0224D22C
ov02_0224D22C: ; 0x0224D22C
	push {r3, r4, r5, lr}
	add r4, r2, #0
	add r5, r1, #0
	add r0, r4, #0
	mov r1, #0
	mov r2, #0xf0
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #3
	str r0, [sp]
	add r0, r4, #0
	mov r2, #0
	add r3, r1, #0
	bl ov02_0224D0C8
	ldr r0, [r5, #0x3c]
	mov r1, #0xfd
	add r2, r4, #0
	bl ov02_0224CFD8
	ldr r0, _0224D274 ; =SEQ_SE_DP_FW015
	bl PlaySE
	mov r0, #0
	add r4, #0xec
	str r0, [r4]
	pop {r3, r4, r5, pc}
	nop
_0224D274: .word SEQ_SE_DP_FW015
	thumb_func_end ov02_0224D22C

	thumb_func_start ov02_0224D278
ov02_0224D278: ; 0x0224D278
	ldr r3, _0224D284 ; =ov02_0224D144
	add r0, r2, #0
	add r2, #0xdc
	add r1, r2, #0
	bx r3
	nop
_0224D284: .word ov02_0224D144
	thumb_func_end ov02_0224D278

	thumb_func_start ov02_0224D288
ov02_0224D288: ; 0x0224D288
	push {r4, lr}
	add r4, r2, #0
	add r0, r4, #0
	add r0, #0xec
	ldr r0, [r0]
	cmp r0, #0
	beq _0224D29A
	cmp r0, #1
	pop {r4, pc}
_0224D29A:
	add r0, r4, #0
	bl ov02_0224D178
	cmp r0, #1
	bne _0224D2B8
	add r0, r4, #0
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	add r0, r4, #0
	add r0, #0xec
	ldr r0, [r0]
	add r4, #0xec
	add r0, r0, #1
	str r0, [r4]
_0224D2B8:
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D288

	thumb_func_start ov02_0224D2BC
ov02_0224D2BC: ; 0x0224D2BC
	ldr r3, _0224D2C4 ; =ov02_0224D1DC
	add r0, r2, #0
	bx r3
	nop
_0224D2C4: .word ov02_0224D1DC
	thumb_func_end ov02_0224D2BC

	thumb_func_start ov02_0224D2C8
ov02_0224D2C8: ; 0x0224D2C8
	ldr r0, [r0, #4]
	ldr r3, _0224D2D4 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D2D8 ; =ov02_02253974
	bx r3
	nop
_0224D2D4: .word Field3dObjectTaskManager_CreateTask
_0224D2D8: .word ov02_02253974
	thumb_func_end ov02_0224D2C8

	thumb_func_start ov02_0224D2DC
ov02_0224D2DC: ; 0x0224D2DC
	ldr r0, [r0, #4]
	ldr r3, _0224D2E8 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D2EC ; =ov02_022539BC
	bx r3
	nop
_0224D2E8: .word Field3dObjectTaskManager_CreateTask
_0224D2EC: .word ov02_022539BC
	thumb_func_end ov02_0224D2DC

	thumb_func_start ov02_0224D2F0
ov02_0224D2F0: ; 0x0224D2F0
	ldr r3, _0224D2F4 ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224D2F4: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224D2F0

	thumb_func_start ov02_0224D2F8
ov02_0224D2F8: ; 0x0224D2F8
	push {r3, lr}
	bl Field3dObjectTask_GetData
	add r0, #0xec
	ldr r0, [r0]
	cmp r0, #1
	bne _0224D30A
	mov r0, #1
	pop {r3, pc}
_0224D30A:
	mov r0, #0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D2F8

	thumb_func_start ov02_0224D310
ov02_0224D310: ; 0x0224D310
	push {r3, r4, r5, lr}
	add r4, r2, #0
	add r5, r1, #0
	add r0, r4, #0
	mov r1, #0
	mov r2, #0xf0
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r4, #0
	add r0, #0xdc
	mov r2, #4
	str r0, [sp]
	add r0, r4, #0
	mov r1, #8
	add r3, r2, #0
	bl ov02_0224D0C8
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D044
	ldr r0, _0224D354 ; =SEQ_SE_DP_FW088
	bl PlaySE
	mov r0, #0
	add r4, #0xec
	str r0, [r4]
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224D354: .word SEQ_SE_DP_FW088
	thumb_func_end ov02_0224D310

	thumb_func_start ov02_0224D358
ov02_0224D358: ; 0x0224D358
	push {r3, r4, r5, lr}
	add r4, r2, #0
	add r5, r1, #0
	add r0, r4, #0
	mov r1, #0
	mov r2, #0xf0
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r4, #0
	add r0, #0xdc
	mov r2, #4
	str r0, [sp]
	add r0, r4, #0
	mov r1, #8
	add r3, r2, #0
	bl ov02_0224D0C8
	ldr r0, [r5, #0x3c]
	mov r1, #0xfd
	add r2, r4, #0
	bl ov02_0224CFD8
	ldr r0, _0224D3A0 ; =SEQ_SE_DP_FW088
	bl PlaySE
	mov r0, #0
	add r4, #0xec
	str r0, [r4]
	pop {r3, r4, r5, pc}
	nop
_0224D3A0: .word SEQ_SE_DP_FW088
	thumb_func_end ov02_0224D358

	thumb_func_start ov02_0224D3A4
ov02_0224D3A4: ; 0x0224D3A4
	ldr r3, _0224D3B0 ; =ov02_0224D144
	add r0, r2, #0
	add r2, #0xdc
	add r1, r2, #0
	bx r3
	nop
_0224D3B0: .word ov02_0224D144
	thumb_func_end ov02_0224D3A4

	thumb_func_start ov02_0224D3B4
ov02_0224D3B4: ; 0x0224D3B4
	push {r4, lr}
	add r4, r2, #0
	add r0, r4, #0
	add r0, #0xec
	ldr r0, [r0]
	cmp r0, #0
	beq _0224D3C6
	cmp r0, #1
	pop {r4, pc}
_0224D3C6:
	add r0, r4, #0
	bl ov02_0224D178
	cmp r0, #1
	bne _0224D3E4
	add r0, r4, #0
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	add r0, r4, #0
	add r0, #0xec
	ldr r0, [r0]
	add r4, #0xec
	add r0, r0, #1
	str r0, [r4]
_0224D3E4:
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D3B4

	thumb_func_start ov02_0224D3E8
ov02_0224D3E8: ; 0x0224D3E8
	ldr r3, _0224D3F0 ; =ov02_0224D1DC
	add r0, r2, #0
	bx r3
	nop
_0224D3F0: .word ov02_0224D1DC
	thumb_func_end ov02_0224D3E8

	thumb_func_start ov02_0224D3F4
ov02_0224D3F4: ; 0x0224D3F4
	ldr r0, [r0, #4]
	ldr r3, _0224D400 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D404 ; =ov02_022538FC
	bx r3
	nop
_0224D400: .word Field3dObjectTaskManager_CreateTask
_0224D404: .word ov02_022538FC
	thumb_func_end ov02_0224D3F4

	thumb_func_start ov02_0224D408
ov02_0224D408: ; 0x0224D408
	ldr r0, [r0, #4]
	ldr r3, _0224D414 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D418 ; =ov02_0225398C
	bx r3
	nop
_0224D414: .word Field3dObjectTaskManager_CreateTask
_0224D418: .word ov02_0225398C
	thumb_func_end ov02_0224D408

	thumb_func_start ov02_0224D41C
ov02_0224D41C: ; 0x0224D41C
	ldr r3, _0224D420 ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224D420: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224D41C

	thumb_func_start ov02_0224D424
ov02_0224D424: ; 0x0224D424
	push {r3, lr}
	bl Field3dObjectTask_GetData
	add r0, #0xec
	ldr r0, [r0]
	cmp r0, #1
	bne _0224D436
	mov r0, #1
	pop {r3, pc}
_0224D436:
	mov r0, #0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D424

	thumb_func_start ov02_0224D43C
ov02_0224D43C: ; 0x0224D43C
	push {r4, lr}
	add r4, r2, #0
	mov r2, #0x73
	add r0, r4, #0
	mov r1, #0
	lsl r2, r2, #2
	bl memset
	mov r0, #0x6e
	lsl r0, r0, #2
	add r0, r4, r0
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	ldr r0, _0224D464 ; =0x000001CA
	mov r1, #0
	strh r1, [r4, r0]
	pop {r4, pc}
	nop
_0224D464: .word 0x000001CA
	thumb_func_end ov02_0224D43C

	thumb_func_start ov02_0224D468
ov02_0224D468: ; 0x0224D468
	push {r4, r5, r6, lr}
	mov r0, #0x6e
	add r5, r2, #0
	lsl r0, r0, #2
	mov r4, #0
	add r6, r5, r0
_0224D474:
	add r0, r5, #0
	add r1, r6, #0
	bl ov02_0224D144
	add r4, r4, #1
	add r5, #0xdc
	cmp r4, #2
	blt _0224D474
	pop {r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D468

	thumb_func_start ov02_0224D488
ov02_0224D488: ; 0x0224D488
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	ldr r7, _0224D574 ; =0x000001CA
	add r4, r2, #0
	ldrh r0, [r4, r7]
	add r5, r1, #0
	cmp r0, #3
	bhi _0224D570
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224D4A4: ; jump table
	.short _0224D4AC - _0224D4A4 - 2 ; case 0
	.short _0224D50A - _0224D4A4 - 2 ; case 1
	.short _0224D522 - _0224D4A4 - 2 ; case 2
	.short _0224D55E - _0224D4A4 - 2 ; case 3
_0224D4AC:
	ldr r2, _0224D578 ; =ov02_022538EC
	add r1, sp, #4
	ldrb r3, [r2, #2]
	add r0, sp, #4
	add r1, #2
	strb r3, [r0, #2]
	ldrb r3, [r2, #3]
	strb r3, [r0, #3]
	ldrb r6, [r2, #4]
	add r3, sp, #4
	strb r6, [r0]
	ldrb r2, [r2, #5]
	strb r2, [r0, #1]
	sub r0, r7, #2
	ldrh r0, [r4, r0]
	lsl r0, r0, #0x18
	lsr r2, r0, #0x18
	mov r0, #0xdc
	add r6, r2, #0
	mul r6, r0
	add r0, #0xdc
	add r0, r4, r0
	str r0, [sp]
	ldrb r1, [r1, r2]
	ldrb r2, [r3, r2]
	add r0, r4, r6
	mov r3, #2
	bl ov02_0224D0C8
	ldr r0, [r5, #0x40]
	add r1, r4, r6
	bl ov02_0224D0AC
	sub r1, r7, #2
	ldrh r0, [r4, r1]
	add r0, r0, #1
	strh r0, [r4, r1]
	ldrh r0, [r4, r1]
	cmp r0, #2
	blo _0224D570
	add r0, r1, #2
	ldrh r0, [r4, r0]
	add sp, #8
	add r2, r0, #1
	add r0, r1, #2
	strh r2, [r4, r0]
	pop {r3, r4, r5, r6, r7, pc}
_0224D50A:
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	ldr r0, _0224D57C ; =SEQ_SE_DP_FW463
	bl PlaySE
	add r0, r7, #0
	ldrh r1, [r4, r0]
	add r1, r1, #1
	strh r1, [r4, r0]
_0224D522:
	add r0, r4, #0
	bl ov02_0224D178
	add r6, r0, #0
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D0AC
	cmp r6, #1
	bne _0224D570
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #1
	bl Field3dObject_SetActiveFlag
	add r0, r4, #0
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	add r1, r4, #0
	ldr r0, [r5, #0x40]
	add r1, #0xdc
	bl ov02_0224D0AC
	ldr r0, _0224D574 ; =0x000001CA
	add sp, #8
	ldrh r1, [r4, r0]
	add r1, r1, #1
	strh r1, [r4, r0]
	pop {r3, r4, r5, r6, r7, pc}
_0224D55E:
	add r0, r4, #0
	add r0, #0xdc
	bl ov02_0224D1AC
	add r4, #0xdc
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D0AC
_0224D570:
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224D574: .word 0x000001CA
_0224D578: .word ov02_022538EC
_0224D57C: .word SEQ_SE_DP_FW463
	thumb_func_end ov02_0224D488

	thumb_func_start ov02_0224D580
ov02_0224D580: ; 0x0224D580
	push {r3, r4, r5, lr}
	add r5, r2, #0
	mov r4, #0
_0224D586:
	add r0, r5, #0
	bl ov02_0224D1DC
	add r4, r4, #1
	add r5, #0xdc
	cmp r4, #2
	blt _0224D586
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D580

	thumb_func_start ov02_0224D598
ov02_0224D598: ; 0x0224D598
	ldr r0, [r0, #4]
	ldr r3, _0224D5A4 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D5A8 ; =ov02_02253944
	bx r3
	nop
_0224D5A4: .word Field3dObjectTaskManager_CreateTask
_0224D5A8: .word ov02_02253944
	thumb_func_end ov02_0224D598

	thumb_func_start ov02_0224D5AC
ov02_0224D5AC: ; 0x0224D5AC
	ldr r3, _0224D5B0 ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224D5B0: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224D5AC

	thumb_func_start ov02_0224D5B4
ov02_0224D5B4: ; 0x0224D5B4
	push {r4, r5, r6, lr}
	sub sp, #0x10
	add r5, r1, #0
	ldr r1, _0224D640 ; =ov02_022538EC
	add r4, r2, #0
	ldrb r2, [r1]
	add r0, sp, #4
	strb r2, [r0, #1]
	ldrb r2, [r1, #1]
	strb r2, [r0]
	ldrh r2, [r1, #6]
	strh r2, [r0, #2]
	ldrh r2, [r1, #8]
	strh r2, [r0, #4]
	ldrh r2, [r1, #0xa]
	strh r2, [r0, #6]
	ldrh r1, [r1, #0xc]
	mov r2, #0xf0
	strh r1, [r0, #8]
	add r0, r4, #0
	mov r1, #0
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetFacingDirection
	add r6, r0, #0
	add r0, r4, #0
	add r0, #0xdc
	str r0, [sp]
	add r2, sp, #4
	ldrb r1, [r2, #1]
	ldrb r2, [r2]
	add r0, r4, #0
	mov r3, #1
	bl ov02_0224D0C8
	add r0, r4, #0
	bl ov02_0224D1AC
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D0AC
	add r0, sp, #4
	lsl r1, r6, #1
	add r0, #2
	ldrh r0, [r0, r1]
	bl GF_DegreeToSinCosIdxNoWrap
	add r1, r0, #0
	add r0, r4, #0
	mov r2, #1
	bl Field3dObject_SetXRotation
	ldr r0, _0224D644 ; =SEQ_SE_DP_FW463
	bl PlaySE
	mov r0, #0
	add r4, #0xec
	strh r0, [r4]
	add sp, #0x10
	pop {r4, r5, r6, pc}
	nop
_0224D640: .word ov02_022538EC
_0224D644: .word SEQ_SE_DP_FW463
	thumb_func_end ov02_0224D5B4

	thumb_func_start ov02_0224D648
ov02_0224D648: ; 0x0224D648
	ldr r3, _0224D654 ; =ov02_0224D144
	add r0, r2, #0
	add r2, #0xdc
	add r1, r2, #0
	bx r3
	nop
_0224D654: .word ov02_0224D144
	thumb_func_end ov02_0224D648

	thumb_func_start ov02_0224D658
ov02_0224D658: ; 0x0224D658
	push {r3, r4, r5, lr}
	add r4, r2, #0
	add r5, r1, #0
	add r0, r4, #0
	bl ov02_0224D1AC
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D0AC
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D658

	thumb_func_start ov02_0224D670
ov02_0224D670: ; 0x0224D670
	ldr r3, _0224D678 ; =ov02_0224D1DC
	add r0, r2, #0
	bx r3
	nop
_0224D678: .word ov02_0224D1DC
	thumb_func_end ov02_0224D670

	thumb_func_start ov02_0224D67C
ov02_0224D67C: ; 0x0224D67C
	ldr r0, [r0, #4]
	ldr r3, _0224D688 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D68C ; =ov02_02253914
	bx r3
	nop
_0224D688: .word Field3dObjectTaskManager_CreateTask
_0224D68C: .word ov02_02253914
	thumb_func_end ov02_0224D67C

	thumb_func_start ov02_0224D690
ov02_0224D690: ; 0x0224D690
	ldr r3, _0224D694 ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224D694: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224D690

	thumb_func_start ov02_0224D698
ov02_0224D698: ; 0x0224D698
	push {r4, r5, r6, r7, lr}
	sub sp, #0xc
	add r7, r0, #0
	add r0, #0xc8
	ldr r0, [r0]
	add r6, r1, #0
	add r4, r2, #0
	add r5, r3, #0
	cmp r0, #0
	beq _0224D6B0
	bl GF_AssertFail
_0224D6B0:
	add r0, r6, #0
	add r1, sp, #0
	bl PlayerAvatar_CopyPositionVector
	ldr r2, [sp, #4]
	ldr r3, [sp, #8]
	ldr r1, [sp]
	add r0, r7, #0
	add r2, r2, r4
	add r3, r3, r5
	bl Field3dObject_SetPosEx
	add r0, r7, #0
	mov r4, #0
	add r5, r7, #0
	mov r1, #1
	add r0, #0xc8
	str r1, [r0]
	add r5, #0x78
	add r6, r4, #0
_0224D6D8:
	add r0, r5, #0
	add r1, r6, #0
	bl Field3dModelAnimation_FrameSet
	add r4, r4, #1
	add r5, #0x14
	cmp r4, #4
	blt _0224D6D8
	add r0, r7, #0
	mov r1, #1
	bl Field3dObject_SetActiveFlag
	ldr r0, _0224D6FC ; =SEQ_SE_DP_UG_023
	bl PlaySE
	add sp, #0xc
	pop {r4, r5, r6, r7, pc}
	nop
_0224D6FC: .word SEQ_SE_DP_UG_023
	thumb_func_end ov02_0224D698

	thumb_func_start ov02_0224D700
ov02_0224D700: ; 0x0224D700
	push {r3, r4, r5, r6, r7, lr}
	str r0, [sp]
	add r0, #0xc8
	ldr r0, [r0]
	cmp r0, #0
	beq _0224D73A
	ldr r5, [sp]
	mov r4, #1
	mov r6, #0
	add r5, #0x78
	lsl r7, r4, #0xc
_0224D716:
	add r0, r5, #0
	add r1, r7, #0
	bl Field3dModelAnimation_FrameAdvanceAndCheck
	add r6, r6, #1
	and r4, r0
	add r5, #0x14
	cmp r6, #4
	blt _0224D716
	cmp r4, #1
	bne _0224D73A
	ldr r0, [sp]
	mov r1, #0
	add r0, #0xc8
	str r1, [r0]
	ldr r0, [sp]
	bl Field3dObject_SetActiveFlag
_0224D73A:
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224D700

	thumb_func_start ov02_0224D73C
ov02_0224D73C: ; 0x0224D73C
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	str r1, [sp]
	str r2, [sp, #4]
	mov r1, #0
	mov r2, #0xcc
	add r7, r0, #0
	add r5, r3, #0
	bl memset
	ldr r1, [sp]
	add r0, r7, #0
	bl Field3dObject_InitFromModel
	add r4, r7, #0
	mov r6, #0
	add r4, #0x78
_0224D75E:
	ldr r1, [sp]
	ldr r2, [r5]
	ldr r3, [sp, #4]
	add r0, r4, #0
	bl ov01_021FBE70
	add r0, r7, #0
	add r1, r4, #0
	bl Field3dObject_AddAnimation
	add r6, r6, #1
	add r5, r5, #4
	add r4, #0x14
	cmp r6, #4
	blt _0224D75E
	add r0, r7, #0
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224D73C

	thumb_func_start ov02_0224D788
ov02_0224D788: ; 0x0224D788
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	add r5, r7, #0
	add r6, r1, #0
	mov r4, #0
	add r5, #0x78
_0224D794:
	add r0, r5, #0
	add r1, r6, #0
	bl Field3dModelAnimation_Unload
	add r4, r4, #1
	add r5, #0x14
	cmp r4, #4
	blt _0224D794
	add r0, r7, #0
	mov r1, #0
	mov r2, #0xcc
	bl memset
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224D788

	thumb_func_start ov02_0224D7B0
ov02_0224D7B0: ; 0x0224D7B0
	push {r3, r4, lr}
	sub sp, #0xc
	add r4, r0, #0
	mov r0, #0xce
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	add r1, sp, #0
	ldr r0, [r0, #0x40]
	bl PlayerAvatar_CopyPositionVector
	mov r1, #0xcf
	lsl r1, r1, #4
	ldr r2, [sp]
	ldr r0, [r4, r1]
	sub r0, r2, r0
	bne _0224D7F8
	add r0, r1, #4
	ldr r2, [sp, #4]
	ldr r0, [r4, r0]
	cmp r2, r0
	bge _0224D7F8
	add r0, r1, #0
	add r0, #8
	ldr r2, [sp, #8]
	ldr r0, [r4, r0]
	cmp r2, r0
	ble _0224D7F8
	add r0, r1, #0
	mov r2, #0
	sub r0, #8
	str r2, [r4, r0]
	mov r2, #2
	lsl r2, r2, #0x10
	sub r0, r1, #4
	str r2, [r4, r0]
	b _0224D806
_0224D7F8:
	mov r1, #2
	ldr r0, _0224D81C ; =0x00000CE8
	lsl r1, r1, #0x10
	str r1, [r4, r0]
	lsr r1, r1, #1
	add r0, r0, #4
	str r1, [r4, r0]
_0224D806:
	mov r0, #0xcf
	lsl r0, r0, #4
	add r3, sp, #0
	add r2, r4, r0
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	add sp, #0xc
	pop {r3, r4, pc}
	nop
_0224D81C: .word 0x00000CE8
	thumb_func_end ov02_0224D7B0

	thumb_func_start ov02_0224D820
ov02_0224D820: ; 0x0224D820
	push {r4, lr}
	add r4, r0, #0
	bl ov02_0224D7B0
	mov r2, #0
	add r1, r4, #0
_0224D82C:
	add r0, r1, #0
	add r0, #0xd8
	ldr r0, [r0]
	cmp r0, #0
	bne _0224D858
	add r1, r4, #0
	mov r0, #0xcc
	mov r3, #0xce
	add r1, #0x10
	mul r0, r2
	lsl r3, r3, #4
	add r0, r1, r0
	ldr r1, [r4, r3]
	add r2, r3, #0
	add r2, #8
	add r3, #0xc
	ldr r1, [r1, #0x40]
	ldr r2, [r4, r2]
	ldr r3, [r4, r3]
	bl ov02_0224D698
	pop {r4, pc}
_0224D858:
	add r2, r2, #1
	add r1, #0xcc
	cmp r2, #0x10
	blt _0224D82C
	bl GF_AssertFail
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224D820

	thumb_func_start ov02_0224D868
ov02_0224D868: ; 0x0224D868
	push {r3, r4, r5, lr}
	add r5, r0, #0
	mov r4, #0
	add r5, #0x10
_0224D870:
	add r0, r5, #0
	bl ov02_0224D700
	add r4, r4, #1
	add r5, #0xcc
	cmp r4, #0x10
	blt _0224D870
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224D868

	thumb_func_start ov02_0224D880
ov02_0224D880: ; 0x0224D880
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	add r5, r2, #0
	mov r2, #0xd1
	str r1, [sp, #4]
	add r0, r5, #0
	mov r1, #0
	lsl r2, r2, #4
	bl memset
	ldr r0, _0224D90C ; =0x00000CFC
	mov r1, #4
	add r0, r5, r0
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r5, #0
	mov r1, #0x86
	mov r2, #8
	mov r3, #4
	bl Field3dModel_LoadFromFilesystem
	mov r7, #0xcd
	mov r4, #0
	add r6, r5, #0
	lsl r7, r7, #4
_0224D8B4:
	mov r0, #0
	str r0, [sp]
	mov r0, #0x86
	add r1, r4, #4
	mov r2, #0
	mov r3, #4
	bl GfGfxLoader_LoadFromNarc
	str r0, [r6, r7]
	add r4, r4, #1
	add r6, r6, #4
	cmp r4, #4
	blt _0224D8B4
	add r4, r5, #0
	mov r7, #0xcd
	mov r6, #0
	add r4, #0x10
	lsl r7, r7, #4
_0224D8D8:
	ldr r2, _0224D90C ; =0x00000CFC
	add r0, r4, #0
	add r1, r5, #0
	add r2, r5, r2
	add r3, r5, r7
	bl ov02_0224D73C
	add r6, r6, #1
	add r4, #0xcc
	cmp r6, #0x10
	blt _0224D8D8
	mov r1, #0xce
	ldr r0, [sp, #4]
	lsl r1, r1, #4
	str r0, [r5, r1]
	ldr r0, [r5, r1]
	add r1, #0x10
	ldr r0, [r0, #0x40]
	add r1, r5, r1
	bl PlayerAvatar_CopyPositionVector
	ldr r0, _0224D910 ; =0x00000D0C
	mov r1, #0
	str r1, [r5, r0]
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224D90C: .word 0x00000CFC
_0224D910: .word 0x00000D0C
	thumb_func_end ov02_0224D880

	thumb_func_start ov02_0224D914
ov02_0224D914: ; 0x0224D914
	push {r3, r4, r5, r6, r7, lr}
	add r5, r2, #0
	add r4, r5, #0
	ldr r7, _0224D94C ; =0x00000CFC
	mov r6, #0
	add r4, #0x10
_0224D920:
	add r0, r4, #0
	add r1, r5, r7
	bl ov02_0224D788
	add r6, r6, #1
	add r4, #0xcc
	cmp r6, #0x10
	blt _0224D920
	add r0, r5, #0
	bl Field3dModel_Unload
	mov r6, #0xcd
	mov r4, #0
	lsl r6, r6, #4
_0224D93C:
	ldr r0, [r5, r6]
	bl Heap_Free
	add r4, r4, #1
	add r5, r5, #4
	cmp r4, #4
	blt _0224D93C
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224D94C: .word 0x00000CFC
	thumb_func_end ov02_0224D914

	thumb_func_start ov02_0224D950
ov02_0224D950: ; 0x0224D950
	push {r4, lr}
	ldr r1, _0224D988 ; =0x00000D0C
	add r4, r2, #0
	ldr r0, [r4, r1]
	cmp r0, #0
	bne _0224D986
	add r0, r1, #0
	sub r0, #0x28
	ldr r0, [r4, r0]
	sub r2, r0, #1
	add r0, r1, #0
	sub r0, #0x28
	str r2, [r4, r0]
	add r0, r1, #0
	sub r0, #0x28
	ldr r0, [r4, r0]
	cmp r0, #0
	bge _0224D980
	mov r0, #4
	sub r1, #0x28
	str r0, [r4, r1]
	add r0, r4, #0
	bl ov02_0224D820
_0224D980:
	add r0, r4, #0
	bl ov02_0224D868
_0224D986:
	pop {r4, pc}
	.balign 4, 0
_0224D988: .word 0x00000D0C
	thumb_func_end ov02_0224D950

	thumb_func_start ov02_0224D98C
ov02_0224D98C: ; 0x0224D98C
	push {r3, r4, r5, lr}
	add r5, r2, #0
	mov r4, #0
	add r5, #0x10
_0224D994:
	add r0, r5, #0
	bl Field3dObject_Draw
	add r4, r4, #1
	add r5, #0xcc
	cmp r4, #0x10
	blt _0224D994
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224D98C

	thumb_func_start ov02_0224D9A4
ov02_0224D9A4: ; 0x0224D9A4
	ldr r0, [r0, #4]
	ldr r3, _0224D9B0 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224D9B4 ; =ov02_0225395C
	bx r3
	nop
_0224D9B0: .word Field3dObjectTaskManager_CreateTask
_0224D9B4: .word ov02_0225395C
	thumb_func_end ov02_0224D9A4

	thumb_func_start ov02_0224D9B8
ov02_0224D9B8: ; 0x0224D9B8
	ldr r3, _0224D9BC ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224D9BC: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224D9B8

	thumb_func_start ov02_0224D9C0
ov02_0224D9C0: ; 0x0224D9C0
	push {r3, r4, r5, lr}
	sub sp, #0x28
	add r4, r2, #0
	mov r2, #0x45
	add r5, r1, #0
	add r0, r4, #0
	mov r1, #0
	lsl r2, r2, #2
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r4, #0
	add r0, #0xdc
	str r0, [sp]
	add r0, r4, #0
	mov r1, #0x13
	mov r2, #0x11
	mov r3, #2
	bl ov02_0224D0C8
	ldr r0, [r5, #0x40]
	add r1, r4, #0
	bl ov02_0224D044
	ldr r1, [r5, #0x24]
	add r0, sp, #0x10
	bl Camera_GetLookAtCamTarget
	add r3, sp, #0x10
	add r2, r4, #0
	ldmia r3!, {r0, r1}
	add r2, #0xf8
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r1, [r5, #0x24]
	add r0, sp, #4
	bl Camera_GetLookAtCamPos
	add r3, sp, #4
	add r2, r4, #0
	ldmia r3!, {r0, r1}
	add r2, #0xec
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	add r1, sp, #0x1c
	str r0, [r2]
	mov r0, #0
	str r0, [r1]
	str r0, [r1, #4]
	str r0, [r1, #8]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetFacingDirection
	cmp r0, #3
	bhi _0224DA7C
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224DA46: ; jump table
	.short _0224DA4E - _0224DA46 - 2 ; case 0
	.short _0224DA5A - _0224DA46 - 2 ; case 1
	.short _0224DA66 - _0224DA46 - 2 ; case 2
	.short _0224DA72 - _0224DA46 - 2 ; case 3
_0224DA4E:
	mov r0, #2
	ldr r1, [sp, #0x24]
	lsl r0, r0, #0xe
	sub r0, r1, r0
	str r0, [sp, #0x24]
	b _0224DA7C
_0224DA5A:
	mov r0, #2
	ldr r1, [sp, #0x24]
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [sp, #0x24]
	b _0224DA7C
_0224DA66:
	mov r0, #2
	ldr r1, [sp, #0x1c]
	lsl r0, r0, #0xe
	sub r0, r1, r0
	str r0, [sp, #0x1c]
	b _0224DA7C
_0224DA72:
	mov r0, #2
	ldr r1, [sp, #0x1c]
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [sp, #0x1c]
_0224DA7C:
	mov r0, #0x41
	lsl r0, r0, #2
	add r3, sp, #0x1c
	add r2, r4, r0
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r0, _0224DA9C ; =SEQ_SE_GS_ZUTUKI
	bl PlaySE
	ldr r0, _0224DAA0 ; =0x00000113
	mov r1, #0
	strb r1, [r4, r0]
	add sp, #0x28
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224DA9C: .word SEQ_SE_GS_ZUTUKI
_0224DAA0: .word 0x00000113
	thumb_func_end ov02_0224D9C0

	thumb_func_start ov02_0224DAA4
ov02_0224DAA4: ; 0x0224DAA4
	push {r3, r4, r5, lr}
	sub sp, #0x28
	add r4, r2, #0
	mov r2, #0x45
	add r5, r1, #0
	add r0, r4, #0
	mov r1, #0
	lsl r2, r2, #2
	bl memset
	add r0, r4, #0
	add r0, #0xdc
	mov r1, #4
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r4, #0
	add r0, #0xdc
	str r0, [sp]
	add r0, r4, #0
	mov r1, #0x13
	mov r2, #0x11
	mov r3, #2
	bl ov02_0224D0C8
	ldr r0, [r5, #0x3c]
	mov r1, #0xfd
	add r2, r4, #0
	bl ov02_0224CFD8
	ldr r1, [r5, #0x24]
	add r0, sp, #0x10
	bl Camera_GetLookAtCamTarget
	add r3, sp, #0x10
	add r2, r4, #0
	ldmia r3!, {r0, r1}
	add r2, #0xf8
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r1, [r5, #0x24]
	add r0, sp, #4
	bl Camera_GetLookAtCamPos
	add r3, sp, #4
	add r2, r4, #0
	ldmia r3!, {r0, r1}
	add r2, #0xec
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	add r1, sp, #0x1c
	str r0, [r2]
	mov r0, #0
	str r0, [r1]
	str r0, [r1, #4]
	str r0, [r1, #8]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetFacingDirection
	cmp r0, #3
	bhi _0224DB62
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224DB2C: ; jump table
	.short _0224DB34 - _0224DB2C - 2 ; case 0
	.short _0224DB40 - _0224DB2C - 2 ; case 1
	.short _0224DB4C - _0224DB2C - 2 ; case 2
	.short _0224DB58 - _0224DB2C - 2 ; case 3
_0224DB34:
	mov r0, #2
	ldr r1, [sp, #0x24]
	lsl r0, r0, #0xe
	sub r0, r1, r0
	str r0, [sp, #0x24]
	b _0224DB62
_0224DB40:
	mov r0, #2
	ldr r1, [sp, #0x24]
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [sp, #0x24]
	b _0224DB62
_0224DB4C:
	mov r0, #2
	ldr r1, [sp, #0x1c]
	lsl r0, r0, #0xe
	sub r0, r1, r0
	str r0, [sp, #0x1c]
	b _0224DB62
_0224DB58:
	mov r0, #2
	ldr r1, [sp, #0x1c]
	lsl r0, r0, #0xe
	add r0, r1, r0
	str r0, [sp, #0x1c]
_0224DB62:
	mov r0, #0x41
	lsl r0, r0, #2
	add r3, sp, #0x1c
	add r2, r4, r0
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldr r0, _0224DB84 ; =SEQ_SE_GS_ZUTUKI
	bl PlaySE
	ldr r0, _0224DB88 ; =0x00000113
	mov r1, #0
	strb r1, [r4, r0]
	add sp, #0x28
	pop {r3, r4, r5, pc}
	nop
_0224DB84: .word SEQ_SE_GS_ZUTUKI
_0224DB88: .word 0x00000113
	thumb_func_end ov02_0224DAA4

	thumb_func_start ov02_0224DB8C
ov02_0224DB8C: ; 0x0224DB8C
	ldr r3, _0224DB98 ; =ov02_0224D144
	add r0, r2, #0
	add r2, #0xdc
	add r1, r2, #0
	bx r3
	nop
_0224DB98: .word ov02_0224D144
	thumb_func_end ov02_0224DB8C

	thumb_func_start ov02_0224DB9C
ov02_0224DB9C: ; 0x0224DB9C
	push {r3, r4, r5, lr}
	add r5, r1, #0
	ldr r1, _0224DC50 ; =0x00000113
	add r4, r2, #0
	ldrb r0, [r4, r1]
	cmp r0, #0
	beq _0224DBB0
	cmp r0, #1
	beq _0224DC38
	pop {r3, r4, r5, pc}
_0224DBB0:
	sub r0, r1, #1
	ldrb r0, [r4, r0]
	cmp r0, #2
	bhs _0224DC1C
	sub r0, r1, #3
	ldrsb r0, [r4, r0]
	cmp r0, #0
	bgt _0224DC12
	mov r2, #1
	sub r0, r1, #3
	strb r2, [r4, r0]
	sub r0, r1, #2
	ldrb r0, [r4, r0]
	add r0, r0, #1
	lsr r2, r0, #0x1f
	lsl r1, r0, #0x1f
	sub r1, r1, r2
	mov r0, #0x1f
	ror r1, r0
	add r2, r2, r1
	add r1, r0, #0
	add r1, #0xf2
	strb r2, [r4, r1]
	add r1, r0, #0
	add r1, #0xf2
	ldrb r1, [r4, r1]
	cmp r1, #0
	beq _0224DBF4
	add r0, #0xe5
	ldr r1, [r5, #0x24]
	add r0, r4, r0
	bl Camera_OffsetLookAtPosAndTarget
	b _0224DC1C
_0224DBF4:
	add r0, r4, #0
	ldr r1, [r5, #0x24]
	add r0, #0xf8
	bl Camera_SetLookAtCamTarget
	add r0, r4, #0
	ldr r1, [r5, #0x24]
	add r0, #0xec
	bl Camera_SetLookAtCamPos
	ldr r0, _0224DC54 ; =0x00000112
	ldrb r1, [r4, r0]
	add r1, r1, #1
	strb r1, [r4, r0]
	b _0224DC1C
_0224DC12:
	sub r0, r1, #3
	ldrsb r0, [r4, r0]
	sub r2, r0, #1
	sub r0, r1, #3
	strb r2, [r4, r0]
_0224DC1C:
	add r0, r4, #0
	bl ov02_0224D178
	cmp r0, #1
	bne _0224DC4C
	add r0, r4, #0
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	ldr r0, _0224DC50 ; =0x00000113
	ldrb r1, [r4, r0]
	add r1, r1, #1
	strb r1, [r4, r0]
	pop {r3, r4, r5, pc}
_0224DC38:
	add r0, r4, #0
	ldr r1, [r5, #0x24]
	add r0, #0xf8
	bl Camera_SetLookAtCamTarget
	add r4, #0xec
	ldr r1, [r5, #0x24]
	add r0, r4, #0
	bl Camera_SetLookAtCamPos
_0224DC4C:
	pop {r3, r4, r5, pc}
	nop
_0224DC50: .word 0x00000113
_0224DC54: .word 0x00000112
	thumb_func_end ov02_0224DB9C

	thumb_func_start ov02_0224DC58
ov02_0224DC58: ; 0x0224DC58
	ldr r3, _0224DC60 ; =ov02_0224D1DC
	add r0, r2, #0
	bx r3
	nop
_0224DC60: .word ov02_0224D1DC
	thumb_func_end ov02_0224DC58

	thumb_func_start ov02_0224DC64
ov02_0224DC64: ; 0x0224DC64
	ldr r0, [r0, #4]
	ldr r3, _0224DC70 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224DC74 ; =ov02_022539A4
	bx r3
	nop
_0224DC70: .word Field3dObjectTaskManager_CreateTask
_0224DC74: .word ov02_022539A4
	thumb_func_end ov02_0224DC64

	thumb_func_start ov02_0224DC78
ov02_0224DC78: ; 0x0224DC78
	ldr r0, [r0, #4]
	ldr r3, _0224DC84 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224DC88 ; =ov02_0225392C
	bx r3
	nop
_0224DC84: .word Field3dObjectTaskManager_CreateTask
_0224DC88: .word ov02_0225392C
	thumb_func_end ov02_0224DC78

	thumb_func_start ov02_0224DC8C
ov02_0224DC8C: ; 0x0224DC8C
	ldr r3, _0224DC90 ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224DC90: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224DC8C

	thumb_func_start ov02_0224DC94
ov02_0224DC94: ; 0x0224DC94
	push {r3, lr}
	bl Field3dObjectTask_GetData
	ldr r1, _0224DCAC ; =0x00000113
	ldrb r0, [r0, r1]
	cmp r0, #1
	bne _0224DCA6
	mov r0, #1
	pop {r3, pc}
_0224DCA6:
	mov r0, #0
	pop {r3, pc}
	nop
_0224DCAC: .word 0x00000113
	thumb_func_end ov02_0224DC94

	thumb_func_start ov02_0224DCB0
ov02_0224DCB0: ; 0x0224DCB0
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	add r6, r2, #0
	str r1, [sp, #4]
	ldr r2, _0224DD28 ; =0x00000E9C
	add r0, r6, #0
	mov r1, #0
	bl memset
	ldr r0, _0224DD2C ; =0x00000E88
	mov r1, #4
	add r0, r6, r0
	mov r2, #0x20
	bl HeapExp_FndInitAllocator
	add r0, r6, #0
	mov r1, #0x86
	mov r2, #8
	mov r3, #4
	bl Field3dModel_LoadFromFilesystem
	ldr r7, _0224DD30 ; =0x00000E68
	mov r4, #0
	add r5, r6, #0
_0224DCE0:
	mov r0, #0
	str r0, [sp]
	mov r0, #0x86
	add r1, r4, #4
	mov r2, #0
	mov r3, #4
	bl GfGfxLoader_LoadFromNarc
	str r0, [r5, r7]
	add r4, r4, #1
	add r5, r5, #4
	cmp r4, #4
	blt _0224DCE0
	add r4, r6, #0
	ldr r7, _0224DD30 ; =0x00000E68
	mov r5, #0
	add r4, #0x10
_0224DD02:
	ldr r2, _0224DD2C ; =0x00000E88
	add r0, r4, #0
	add r1, r6, #0
	add r2, r6, r2
	add r3, r6, r7
	bl ov02_0224DEA8
	add r5, r5, #1
	add r4, #0xcc
	cmp r5, #0x12
	blt _0224DD02
	ldr r1, _0224DD34 ; =0x00000E78
	ldr r0, [sp, #4]
	str r0, [r6, r1]
	mov r0, #0
	add r1, #0x20
	strh r0, [r6, r1]
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224DD28: .word 0x00000E9C
_0224DD2C: .word 0x00000E88
_0224DD30: .word 0x00000E68
_0224DD34: .word 0x00000E78
	thumb_func_end ov02_0224DCB0

	thumb_func_start ov02_0224DD38
ov02_0224DD38: ; 0x0224DD38
	push {r4, lr}
	add r4, r2, #0
	bl ov02_0224DCB0
	ldr r0, _0224DD48 ; =0x00000E9A
	mov r1, #1
	strh r1, [r4, r0]
	pop {r4, pc}
	.balign 4, 0
_0224DD48: .word 0x00000E9A
	thumb_func_end ov02_0224DD38

	thumb_func_start ov02_0224DD4C
ov02_0224DD4C: ; 0x0224DD4C
	push {r3, r4, r5, r6, r7, lr}
	add r5, r2, #0
	add r4, r5, #0
	ldr r7, _0224DD84 ; =0x00000E88
	mov r6, #0
	add r4, #0x10
_0224DD58:
	add r0, r4, #0
	add r1, r5, r7
	bl ov02_0224DEF4
	add r6, r6, #1
	add r4, #0xcc
	cmp r6, #0x12
	blt _0224DD58
	add r0, r5, #0
	bl Field3dModel_Unload
	ldr r6, _0224DD88 ; =0x00000E68
	mov r4, #0
_0224DD72:
	ldr r0, [r5, r6]
	bl Heap_Free
	add r4, r4, #1
	add r5, r5, #4
	cmp r4, #4
	blt _0224DD72
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224DD84: .word 0x00000E88
_0224DD88: .word 0x00000E68
	thumb_func_end ov02_0224DD4C

	thumb_func_start ov02_0224DD8C
ov02_0224DD8C: ; 0x0224DD8C
	push {r4, lr}
	ldr r1, _0224DDC4 ; =0x00000E98
	add r4, r2, #0
	ldrh r0, [r4, r1]
	cmp r0, #0
	bne _0224DDC2
	add r0, r1, #0
	sub r0, #0x1c
	ldr r0, [r4, r0]
	sub r2, r0, #1
	add r0, r1, #0
	sub r0, #0x1c
	str r2, [r4, r0]
	add r0, r1, #0
	sub r0, #0x1c
	ldr r0, [r4, r0]
	cmp r0, #0
	bge _0224DDBC
	mov r0, #4
	sub r1, #0x1c
	str r0, [r4, r1]
	add r0, r4, #0
	bl ov02_0224DF1C
_0224DDBC:
	add r0, r4, #0
	bl ov02_0224E008
_0224DDC2:
	pop {r4, pc}
	.balign 4, 0
_0224DDC4: .word 0x00000E98
	thumb_func_end ov02_0224DD8C

	thumb_func_start ov02_0224DDC8
ov02_0224DDC8: ; 0x0224DDC8
	push {r3, r4, r5, lr}
	add r5, r2, #0
	mov r4, #0
	add r5, #0x10
_0224DDD0:
	add r0, r5, #0
	bl Field3dObject_Draw
	add r4, r4, #1
	add r5, #0xcc
	cmp r4, #0x12
	blt _0224DDD0
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224DDC8

	thumb_func_start ov02_0224DDE0
ov02_0224DDE0: ; 0x0224DDE0
	ldr r0, [r0, #4]
	ldr r3, _0224DDEC ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224DDF0 ; =ov02_022539D4
	bx r3
	nop
_0224DDEC: .word Field3dObjectTaskManager_CreateTask
_0224DDF0: .word ov02_022539D4
	thumb_func_end ov02_0224DDE0

	thumb_func_start ov02_0224DDF4
ov02_0224DDF4: ; 0x0224DDF4
	ldr r0, [r0, #4]
	ldr r3, _0224DE00 ; =Field3dObjectTaskManager_CreateTask
	ldr r0, [r0, #4]
	ldr r1, _0224DE04 ; =ov02_022539EC
	bx r3
	nop
_0224DE00: .word Field3dObjectTaskManager_CreateTask
_0224DE04: .word ov02_022539EC
	thumb_func_end ov02_0224DDF4

	thumb_func_start ov02_0224DE08
ov02_0224DE08: ; 0x0224DE08
	ldr r3, _0224DE0C ; =Field3dObjectTask_Delete
	bx r3
	.balign 4, 0
_0224DE0C: .word Field3dObjectTask_Delete
	thumb_func_end ov02_0224DE08

	thumb_func_start ov02_0224DE10
ov02_0224DE10: ; 0x0224DE10
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	add r0, #0xc8
	ldr r0, [r0]
	add r4, r1, #0
	add r5, r2, #0
	add r6, r3, #0
	cmp r0, #0
	beq _0224DE26
	bl GF_AssertFail
_0224DE26:
	ldr r2, [r4, #4]
	ldr r3, [r4, #8]
	ldr r1, [r4]
	add r0, r7, #0
	add r2, r2, r5
	add r3, r3, r6
	bl Field3dObject_SetPosEx
	add r0, r7, #0
	mov r4, #0
	add r5, r7, #0
	mov r1, #1
	add r0, #0xc8
	str r1, [r0]
	add r5, #0x78
	add r6, r4, #0
_0224DE46:
	add r0, r5, #0
	add r1, r6, #0
	bl Field3dModelAnimation_FrameSet
	add r4, r4, #1
	add r5, #0x14
	cmp r4, #4
	blt _0224DE46
	add r0, r7, #0
	mov r1, #1
	bl Field3dObject_SetActiveFlag
	ldr r0, _0224DE68 ; =SEQ_SE_DP_UG_023
	bl PlaySE
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224DE68: .word SEQ_SE_DP_UG_023
	thumb_func_end ov02_0224DE10

	thumb_func_start ov02_0224DE6C
ov02_0224DE6C: ; 0x0224DE6C
	push {r3, r4, r5, r6, r7, lr}
	str r0, [sp]
	add r0, #0xc8
	ldr r0, [r0]
	cmp r0, #0
	beq _0224DEA6
	ldr r5, [sp]
	mov r4, #1
	mov r6, #0
	add r5, #0x78
	lsl r7, r4, #0xc
_0224DE82:
	add r0, r5, #0
	add r1, r7, #0
	bl Field3dModelAnimation_FrameAdvanceAndCheck
	add r6, r6, #1
	and r4, r0
	add r5, #0x14
	cmp r6, #4
	blt _0224DE82
	cmp r4, #1
	bne _0224DEA6
	ldr r0, [sp]
	mov r1, #0
	add r0, #0xc8
	str r1, [r0]
	ldr r0, [sp]
	bl Field3dObject_SetActiveFlag
_0224DEA6:
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224DE6C

	thumb_func_start ov02_0224DEA8
ov02_0224DEA8: ; 0x0224DEA8
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	str r1, [sp]
	str r2, [sp, #4]
	mov r1, #0
	mov r2, #0xcc
	add r7, r0, #0
	add r5, r3, #0
	bl memset
	ldr r1, [sp]
	add r0, r7, #0
	bl Field3dObject_InitFromModel
	add r4, r7, #0
	mov r6, #0
	add r4, #0x78
_0224DECA:
	ldr r1, [sp]
	ldr r2, [r5]
	ldr r3, [sp, #4]
	add r0, r4, #0
	bl ov01_021FBE70
	add r0, r7, #0
	add r1, r4, #0
	bl Field3dObject_AddAnimation
	add r6, r6, #1
	add r5, r5, #4
	add r4, #0x14
	cmp r6, #4
	blt _0224DECA
	add r0, r7, #0
	mov r1, #0
	bl Field3dObject_SetActiveFlag
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224DEA8

	thumb_func_start ov02_0224DEF4
ov02_0224DEF4: ; 0x0224DEF4
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	add r5, r7, #0
	add r6, r1, #0
	mov r4, #0
	add r5, #0x78
_0224DF00:
	add r0, r5, #0
	add r1, r6, #0
	bl Field3dModelAnimation_Unload
	add r4, r4, #1
	add r5, #0x14
	cmp r4, #4
	blt _0224DF00
	add r0, r7, #0
	mov r1, #0
	mov r2, #0xcc
	bl memset
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224DEF4

	thumb_func_start ov02_0224DF1C
ov02_0224DF1C: ; 0x0224DF1C
	push {r3, r4, r5, lr}
	sub sp, #0x18
	add r4, r0, #0
	mov r0, #1
	mov r1, #0x3a
	mov r2, #3
	lsl r0, r0, #0xc
	lsl r1, r1, #6
	str r0, [r4, r1]
	add r0, r1, #4
	lsl r2, r2, #0xc
	sub r1, #8
	str r2, [r4, r0]
	ldr r0, [r4, r1]
	add r1, sp, #0xc
	ldr r0, [r0, #0x40]
	bl PlayerAvatar_CopyPositionVector
	ldr r0, _0224E004 ; =0x00000E9A
	ldrh r1, [r4, r0]
	cmp r1, #0
	beq _0224DFC6
	sub r0, #0x22
	ldr r0, [r4, r0]
	bl FollowMon_GetMapObject
	add r1, sp, #0
	bl MapObject_CopyPositionVector
	mov r5, #0
	add r1, r4, #0
_0224DF5A:
	add r0, r1, #0
	add r0, #0xd8
	ldr r0, [r0]
	cmp r0, #0
	bne _0224DF80
	mov r3, #0x3a
	lsl r3, r3, #6
	add r1, r4, #0
	mov r0, #0xcc
	ldr r2, [r4, r3]
	add r3, r3, #4
	add r1, #0x10
	mul r0, r5
	add r0, r1, r0
	ldr r3, [r4, r3]
	add r1, sp, #0xc
	bl ov02_0224DE10
	b _0224DF88
_0224DF80:
	add r5, r5, #1
	add r1, #0xcc
	cmp r5, #0x12
	blt _0224DF5A
_0224DF88:
	cmp r5, #0x12
	bne _0224DF90
	bl GF_AssertFail
_0224DF90:
	mov r0, #0
	add r2, r4, #0
_0224DF94:
	add r1, r2, #0
	add r1, #0xd8
	ldr r1, [r1]
	cmp r1, #0
	bne _0224DFBC
	add r2, r4, #0
	mov r1, #0xcc
	mov r3, #0x3a
	add r2, #0x10
	mul r1, r0
	add r0, r2, r1
	lsl r3, r3, #6
	ldr r2, [r4, r3]
	add r3, r3, #4
	ldr r3, [r4, r3]
	add r1, sp, #0
	bl ov02_0224DE10
	add sp, #0x18
	pop {r3, r4, r5, pc}
_0224DFBC:
	add r0, r0, #1
	add r2, #0xcc
	cmp r0, #0x12
	blt _0224DF94
	b _0224DFFA
_0224DFC6:
	mov r0, #0
	add r2, r4, #0
_0224DFCA:
	add r1, r2, #0
	add r1, #0xd8
	ldr r1, [r1]
	cmp r1, #0
	bne _0224DFF2
	add r2, r4, #0
	mov r1, #0xcc
	mov r3, #0x3a
	add r2, #0x10
	mul r1, r0
	add r0, r2, r1
	lsl r3, r3, #6
	ldr r2, [r4, r3]
	add r3, r3, #4
	ldr r3, [r4, r3]
	add r1, sp, #0xc
	bl ov02_0224DE10
	add sp, #0x18
	pop {r3, r4, r5, pc}
_0224DFF2:
	add r0, r0, #1
	add r2, #0xcc
	cmp r0, #0x12
	blt _0224DFCA
_0224DFFA:
	bl GF_AssertFail
	add sp, #0x18
	pop {r3, r4, r5, pc}
	nop
_0224E004: .word 0x00000E9A
	thumb_func_end ov02_0224DF1C

	thumb_func_start ov02_0224E008
ov02_0224E008: ; 0x0224E008
	push {r3, r4, r5, lr}
	add r5, r0, #0
	mov r4, #0
	add r5, #0x10
_0224E010:
	add r0, r5, #0
	bl ov02_0224DE6C
	add r4, r4, #1
	add r5, #0xcc
	cmp r4, #0x12
	blt _0224E010
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224E008

	thumb_func_start ov02_0224E020
ov02_0224E020: ; 0x0224E020
	push {r3, r4, r5, lr}
	add r4, r1, #0
	add r5, r0, #0
	ldr r0, [r4, #8]
	cmp r0, #0
	beq _0224E032
	cmp r0, #1
	beq _0224E04A
	pop {r3, r4, r5, pc}
_0224E032:
	ldr r1, [r4, #0xc]
	ldr r0, [r4]
	lsl r2, r1, #2
	ldr r1, _0224E06C ; =ov02_02253A34
	ldr r1, [r1, r2]
	blx r1
	cmp r0, #1
	bne _0224E068
	ldr r0, [r4, #8]
	add r0, r0, #1
	str r0, [r4, #8]
	pop {r3, r4, r5, pc}
_0224E04A:
	ldr r1, [r4, #0xc]
	ldr r0, [r4]
	lsl r2, r1, #2
	ldr r1, _0224E070 ; =ov02_02253A04
	ldr r1, [r1, r2]
	blx r1
	ldr r0, [r4, #4]
	mov r1, #1
	strh r1, [r0]
	add r0, r4, #0
	bl Heap_Free
	add r0, r5, #0
	bl SysTask_Destroy
_0224E068:
	pop {r3, r4, r5, pc}
	nop
_0224E06C: .word ov02_02253A34
_0224E070: .word ov02_02253A04
	thumb_func_end ov02_0224E020

	thumb_func_start ov02_0224E074
ov02_0224E074: ; 0x0224E074
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	add r5, r1, #0
	add r0, r3, #0
	mov r1, #0x10
	add r4, r2, #0
	bl Heap_Alloc
	add r6, r0, #0
	add r2, r6, #0
	mov r1, #0x10
	mov r0, #0
_0224E08C:
	strb r0, [r2]
	add r2, r2, #1
	sub r1, r1, #1
	bne _0224E08C
	ldr r1, _0224E0B4 ; =ov02_02253A1C
	lsl r2, r4, #2
	ldr r1, [r1, r2]
	add r0, r7, #0
	blx r1
	str r0, [r6]
	str r5, [r6, #4]
	ldr r0, _0224E0B8 ; =ov02_0224E020
	str r4, [r6, #0xc]
	mov r2, #0
	add r1, r6, #0
	strh r2, [r5]
	bl SysTask_CreateOnMainQueue
	pop {r3, r4, r5, r6, r7, pc}
	nop
_0224E0B4: .word ov02_02253A1C
_0224E0B8: .word ov02_0224E020
	thumb_func_end ov02_0224E074

	thumb_func_start ov02_0224E0BC
ov02_0224E0BC: ; 0x0224E0BC
	push {r4, lr}
	add r4, r2, #0
	bl ov02_0224E0D4
	add r2, r0, #0
	ldr r1, _0224E0D0 ; =ov02_0224E0EC
	add r0, r4, #0
	bl TaskManager_Call
	pop {r4, pc}
	.balign 4, 0
_0224E0D0: .word ov02_0224E0EC
	thumb_func_end ov02_0224E0BC

	thumb_func_start ov02_0224E0D4
ov02_0224E0D4: ; 0x0224E0D4
	push {r3, r4, r5, lr}
	add r5, r0, #0
	add r4, r1, #0
	mov r0, #4
	mov r1, #0x20
	bl Heap_AllocAtEnd
	mov r1, #0
	str r1, [r0]
	str r5, [r0, #4]
	str r4, [r0, #8]
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224E0D4

	thumb_func_start ov02_0224E0EC
ov02_0224E0EC: ; 0x0224E0EC
	push {r4, r5, r6, lr}
	add r4, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r4, #0
	bl TaskManager_GetEnvironment
	add r4, r0, #0
	ldr r0, [r4]
	mov r5, #0
	cmp r0, #5
	bls _0224E108
	b _0224E21E
_0224E108:
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224E114: ; jump table
	.short _0224E120 - _0224E114 - 2 ; case 0
	.short _0224E130 - _0224E114 - 2 ; case 1
	.short _0224E156 - _0224E114 - 2 ; case 2
	.short _0224E1AA - _0224E114 - 2 ; case 3
	.short _0224E1C6 - _0224E114 - 2 ; case 4
	.short _0224E1F6 - _0224E114 - 2 ; case 5
_0224E120:
	add r0, r6, #0
	bl FollowMon_GetMapObject
	bl MapObject_UnpauseMovement
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_0224E130:
	ldr r0, [r4, #4]
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _0224E21E
	ldr r0, [r4, #8]
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _0224E21E
	add r0, r6, #0
	bl FollowMon_GetMapObject
	bl MapObject_PauseMovement
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _0224E21E
_0224E156:
	ldr r0, [r4, #4]
	bl MapObject_GetXCoord
	str r0, [r4, #0xc]
	ldr r0, [r4, #4]
	bl MapObject_GetZCoord
	str r0, [r4, #0x10]
	ldr r0, [r4, #4]
	bl MapObject_GetFacingDirection
	str r0, [r4, #0x14]
	ldr r0, [r4, #8]
	bl MapObject_GetXCoord
	str r0, [r4, #0x18]
	ldr r0, [r4, #8]
	bl MapObject_GetZCoord
	str r0, [r4, #0x1c]
	add r0, r4, #0
	add r1, r4, #0
	add r0, #0xc
	add r1, #0x18
	bl ov02_0224E224
	add r6, r0, #0
	ldr r0, [r4, #4]
	add r1, r6, #0
	bl MapObject_SetHeldMovement
	add r0, r6, #0
	bl ov02_0224E2D4
	add r1, r0, #0
	ldr r0, [r4, #8]
	bl MapObject_SetHeldMovement
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _0224E21E
_0224E1AA:
	ldr r0, [r4, #4]
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _0224E21E
	ldr r0, [r4, #8]
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _0224E21E
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _0224E21E
_0224E1C6:
	ldr r0, [r4, #4]
	bl MapObject_GetFacingDirection
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	bl ov02_0224E2A0
	add r1, r0, #0
	ldr r0, [r4, #4]
	bl MapObject_SetHeldMovement
	ldr r0, [r4, #0x14]
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	bl ov02_0224E26C
	add r1, r0, #0
	ldr r0, [r4, #8]
	bl MapObject_SetHeldMovement
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _0224E21E
_0224E1F6:
	ldr r0, [r4, #4]
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _0224E21E
	ldr r0, [r4, #8]
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _0224E21E
	ldr r0, [r4, #4]
	bl MapObject_ClearHeldMovementIfActive
	ldr r0, [r4, #8]
	bl MapObject_ClearHeldMovementIfActive
	add r0, r4, #0
	mov r5, #1
	bl Heap_Free
_0224E21E:
	add r0, r5, #0
	pop {r4, r5, r6, pc}
	.balign 4, 0
	thumb_func_end ov02_0224E0EC

	thumb_func_start ov02_0224E224
ov02_0224E224: ; 0x0224E224
	push {r3, r4, r5, lr}
	ldr r5, [r1]
	ldr r3, [r0]
	mov r4, #0xd
	cmp r3, r5
	bne _0224E246
	ldr r1, [r1, #4]
	ldr r0, [r0, #4]
	cmp r0, r1
	ble _0224E23C
	mov r4, #0xc
	b _0224E268
_0224E23C:
	cmp r0, r1
	blt _0224E268
	bl GF_AssertFail
	b _0224E268
_0224E246:
	ldr r2, [r0, #4]
	ldr r0, [r1, #4]
	cmp r2, r0
	bne _0224E264
	cmp r3, r5
	ble _0224E256
	mov r4, #0xe
	b _0224E268
_0224E256:
	cmp r3, r5
	bge _0224E25E
	mov r4, #0xf
	b _0224E268
_0224E25E:
	bl GF_AssertFail
	b _0224E268
_0224E264:
	bl GF_AssertFail
_0224E268:
	add r0, r4, #0
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224E224

	thumb_func_start ov02_0224E26C
ov02_0224E26C: ; 0x0224E26C
	push {r3, lr}
	cmp r0, #3
	bhi _0224E296
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224E27E: ; jump table
	.short _0224E286 - _0224E27E - 2 ; case 0
	.short _0224E28A - _0224E27E - 2 ; case 1
	.short _0224E28E - _0224E27E - 2 ; case 2
	.short _0224E292 - _0224E27E - 2 ; case 3
_0224E286:
	mov r0, #0
	pop {r3, pc}
_0224E28A:
	mov r0, #1
	pop {r3, pc}
_0224E28E:
	mov r0, #2
	pop {r3, pc}
_0224E292:
	mov r0, #3
	pop {r3, pc}
_0224E296:
	bl GF_AssertFail
	mov r0, #0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224E26C

	thumb_func_start ov02_0224E2A0
ov02_0224E2A0: ; 0x0224E2A0
	push {r3, lr}
	cmp r0, #3
	bhi _0224E2CA
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224E2B2: ; jump table
	.short _0224E2BA - _0224E2B2 - 2 ; case 0
	.short _0224E2BE - _0224E2B2 - 2 ; case 1
	.short _0224E2C2 - _0224E2B2 - 2 ; case 2
	.short _0224E2C6 - _0224E2B2 - 2 ; case 3
_0224E2BA:
	mov r0, #1
	pop {r3, pc}
_0224E2BE:
	mov r0, #0
	pop {r3, pc}
_0224E2C2:
	mov r0, #3
	pop {r3, pc}
_0224E2C6:
	mov r0, #2
	pop {r3, pc}
_0224E2CA:
	bl GF_AssertFail
	mov r0, #0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224E2A0

	thumb_func_start ov02_0224E2D4
ov02_0224E2D4: ; 0x0224E2D4
	push {r3, lr}
	sub r0, #0xc
	cmp r0, #3
	bhi _0224E300
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224E2E8: ; jump table
	.short _0224E2F0 - _0224E2E8 - 2 ; case 0
	.short _0224E2F4 - _0224E2E8 - 2 ; case 1
	.short _0224E2F8 - _0224E2E8 - 2 ; case 2
	.short _0224E2FC - _0224E2E8 - 2 ; case 3
_0224E2F0:
	mov r0, #0xd
	pop {r3, pc}
_0224E2F4:
	mov r0, #0xc
	pop {r3, pc}
_0224E2F8:
	mov r0, #0xf
	pop {r3, pc}
_0224E2FC:
	mov r0, #0xe
	pop {r3, pc}
_0224E300:
	bl GF_AssertFail
	mov r0, #0
	pop {r3, pc}
	thumb_func_end ov02_0224E2D4

	thumb_func_start ov02_0224E308
ov02_0224E308: ; 0x0224E308
	ldr r1, _0224E318 ; =0x00000165
	cmp r0, r1
	bne _0224E312
	mov r0, #1
	bx lr
_0224E312:
	mov r0, #0
	bx lr
	nop
_0224E318: .word 0x00000165
	thumb_func_end ov02_0224E308

/*
 * int ov02_0224E31C(int x, int z) {
 *     int ret  = ((x - 32) / 32) + (((z - 32) / 32) * 3);
 *     if (ret < 0 || ret >= 6) {
 *         ret = 0;
 *     }
 *     return ret;
 * }
 */
	thumb_func_start ov02_0224E31C
ov02_0224E31C: ; 0x0224E31C
	sub r0, #0x20
	asr r2, r0, #4
	lsr r2, r2, #0x1b
	add r2, r0, r2
	sub r1, #0x20
	asr r0, r1, #4
	lsr r0, r0, #0x1b
	add r0, r1, r0
	asr r1, r0, #5
	lsl r0, r1, #1
	asr r2, r2, #5
	add r0, r1, r0
	add r0, r2, r0
	bmi _0224E33C
	cmp r0, #6
	blt _0224E33E
_0224E33C:
	mov r0, #0
_0224E33E:
	bx lr
	thumb_func_end ov02_0224E31C

	thumb_func_start ov02_0224E340
ov02_0224E340: ; 0x0224E340
	push {r3, r4, r5, lr}
	add r5, r0, #0
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetXCoord
	add r4, r0, #0
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetZCoord
	add r1, r0, #0
	add r0, r4, #0
	bl ov02_0224E31C
	pop {r3, r4, r5, pc}
	thumb_func_end ov02_0224E340

	thumb_func_start ov02_0224E35C
ov02_0224E35C: ; 0x0224E35C
	push {r4, r5, r6, r7, lr}
	sub sp, #0x1c
	add r5, r0, #0
	ldr r0, [r5, #0xc]
	bl Save_VarsFlags_Get
	add r6, r0, #0
	ldr r0, [r5, #0xc]
	bl Save_LocalFieldData_Get
	bl LocalFieldData_GetCurrentPosition
	ldr r0, [r5, #0xc]
	bl Save_SafariZone_Get
	add r4, r0, #0
	ldr r0, [r5, #0x20]
	ldr r0, [r0]
	bl ov02_0224E308
	cmp r0, #0
	bne _0224E38E
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E38E:
	add r0, r6, #0
	bl Save_VarsFlags_CheckSafariSysFlag
	cmp r0, #0
	bne _0224E39E
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E39E:
	add r0, r4, #0
	bl sub_0202F620
	cmp r0, #0
	beq _0224E3AE
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E3AE:
	add r0, r4, #0
	bl SafariZone_GetObjectUnlockLevel
	cmp r0, #0
	bne _0224E3BE
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E3BE:
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetFacingDirection
	add r7, r0, #0
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetXCoord
	add r4, r0, #0
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetZCoord
	str r0, [sp, #8]
	add r0, r7, #0
	bl GetDeltaXByFacingDirection
	add r6, r4, r0
	add r0, r7, #0
	bl GetDeltaYByFacingDirection
	ldr r1, [sp, #8]
	add r4, r1, r0
	cmp r6, #0x20
	blt _0224E3F8
	cmp r6, #0x80
	bge _0224E3F8
	cmp r4, #0x20
	blt _0224E3F8
	cmp r4, #0x60
	blt _0224E3FE
_0224E3F8:
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E3FE:
	cmp r6, #0x20
	blt _0224E40E
	cmp r6, #0x80
	bge _0224E40E
	cmp r4, #0x20
	blt _0224E40E
	cmp r4, #0x60
	blt _0224E414
_0224E40E:
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E414:
	ldr r0, [r5, #0x40]
	add r1, sp, #0x10
	bl PlayerAvatar_CopyPositionVector
	add r0, sp, #0xc
	str r0, [sp]
	ldr r1, [sp, #0x14]
	ldr r2, [sp, #0x10]
	ldr r3, [sp, #0x18]
	add r0, r5, #0
	bl sub_02054774
	add r7, r0, #0
	add r0, sp, #0xc
	ldrb r0, [r0]
	cmp r0, #1
	beq _0224E43C
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E43C:
	lsl r0, r4, #4
	add r0, #8
	cmp r0, #0
	ble _0224E458
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #4]
	b _0224E468
_0224E458:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #4]
_0224E468:
	lsl r0, r6, #4
	add r0, #8
	cmp r0, #0
	ble _0224E482
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224E490
_0224E482:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224E490:
	bl _ffix
	add r4, r0, #0
	ldr r0, [sp, #4]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0xc
	str r0, [sp]
	ldr r1, [sp, #0x14]
	add r0, r5, #0
	add r2, r4, #0
	bl sub_02054774
	add r1, sp, #0xc
	ldrb r1, [r1]
	cmp r1, #1
	beq _0224E4BA
	add sp, #0x1c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224E4BA:
	cmp r7, r0
	bne _0224E4C4
	add sp, #0x1c
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224E4C4:
	mov r0, #0
	add sp, #0x1c
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224E35C

	thumb_func_start ov02_0224E4CC
ov02_0224E4CC: ; 0x0224E4CC
	push {r3, lr}
	cmp r1, #0
	beq _0224E4D6
	mov r0, #0
	pop {r3, pc}
_0224E4D6:
	bl sub_0205BAD0
	pop {r3, pc}
	thumb_func_end ov02_0224E4CC

	thumb_func_start ov02_0224E4DC
ov02_0224E4DC: ; 0x0224E4DC
	push {r3, lr}
	cmp r1, #0
	beq _0224E4E6
	mov r0, #0
	pop {r3, pc}
_0224E4E6:
	bl MetatileBehavior_IsSurfableWater_thunk
	pop {r3, pc}
	thumb_func_end ov02_0224E4DC

	thumb_func_start SafariDecoration_CreateArgs
SafariDecoration_CreateArgs: ; 0x0224E4EC
	push {r4, r5, r6, r7, lr}
	sub sp, #0x2c
	add r5, r0, #0
	add r0, r1, #0
	mov r1, #0x24
	bl Heap_AllocAtEnd
	mov r1, #0
	mov r2, #0x24
	add r4, r0, #0
	bl MI_CpuFill8
	add r0, r5, #0
	bl FieldSystem_GetSaveData
	str r0, [r4]
	mov r0, #0x43
	lsl r0, r0, #2
	add r1, r5, r0
	add r0, r0, #5
	str r1, [r4, #4]
	add r0, r5, r0
	str r0, [r4, #0x20]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetState
	cmp r0, #2
	bne _0224E528
	mov r0, #1
	b _0224E52A
_0224E528:
	mov r0, #0
_0224E52A:
	lsl r0, r0, #0x18
	lsr r6, r0, #0x18
	strb r6, [r4, #0x18]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetFacingDirection
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	str r0, [sp, #0x10]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetXCoord
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0x14]
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetZCoord
	lsl r0, r0, #0x10
	asr r7, r0, #0x10
	ldr r0, [r5, #0x40]
	add r1, sp, #0x20
	bl PlayerAvatar_CopyPositionVector
	ldr r0, [sp, #0x14]
	add r1, r7, #0
	bl ov02_0224E31C
	strb r0, [r4, #0x19]
	add r0, sp, #0x18
	str r0, [sp]
	ldr r1, [sp, #0x24]
	ldr r2, [sp, #0x20]
	ldr r3, [sp, #0x28]
	add r0, r5, #0
	bl sub_02054774
	str r0, [sp, #0x24]
	add r1, sp, #0x18
	ldrb r1, [r1]
	cmp r1, #1
	beq _0224E584
	add sp, #0x2c
	add r0, r4, #0
	pop {r4, r5, r6, r7, pc}
_0224E584:
	asr r0, r0, #0xc
	strb r0, [r4, #0x1a]
	ldr r0, [sp, #0x10]
	bl GetDeltaXByFacingDirection
	ldr r1, [sp, #0x14]
	add r0, r1, r0
	strb r0, [r4, #9]
	ldr r0, [sp, #0x10]
	bl GetDeltaYByFacingDirection
	add r0, r7, r0
	strb r0, [r4, #0xb]
	mov r0, #1
	strb r0, [r4, #8]
	ldr r0, [sp, #0x24]
	add r2, r7, #0
	str r0, [sp]
	add r0, sp, #0x1c
	str r0, [sp, #4]
	add r0, sp, #0x18
	add r0, #2
	str r0, [sp, #8]
	str r6, [sp, #0xc]
	ldr r1, [sp, #0x14]
	ldr r3, [sp, #0x10]
	add r0, r5, #0
	bl ov02_0224E828
	cmp r0, #0
	beq _0224E5D4
	add r1, sp, #0x18
	mov r0, #4
	ldrsh r0, [r1, r0]
	strb r0, [r4, #0xd]
	mov r0, #2
	ldrsh r0, [r1, r0]
	strb r0, [r4, #0xf]
	mov r0, #1
	strb r0, [r4, #0xc]
_0224E5D4:
	ldr r0, [sp, #0x24]
	add r2, r7, #0
	str r0, [sp]
	add r0, sp, #0x1c
	str r0, [sp, #4]
	add r0, sp, #0x18
	add r0, #2
	str r0, [sp, #8]
	str r6, [sp, #0xc]
	ldr r1, [sp, #0x14]
	ldr r3, [sp, #0x10]
	add r0, r5, #0
	bl ov02_0224EB48
	cmp r0, #0
	beq _0224E606
	add r1, sp, #0x18
	mov r0, #4
	ldrsh r0, [r1, r0]
	strb r0, [r4, #0x11]
	mov r0, #2
	ldrsh r0, [r1, r0]
	strb r0, [r4, #0x13]
	mov r0, #1
	strb r0, [r4, #0x10]
_0224E606:
	ldr r0, [sp, #0x24]
	add r2, r7, #0
	str r0, [sp]
	add r0, sp, #0x1c
	str r0, [sp, #4]
	add r0, sp, #0x18
	add r0, #2
	str r0, [sp, #8]
	str r6, [sp, #0xc]
	ldr r1, [sp, #0x14]
	ldr r3, [sp, #0x10]
	add r0, r5, #0
	bl ov02_0224EE4C
	cmp r0, #0
	beq _0224E638
	add r1, sp, #0x18
	mov r0, #4
	ldrsh r0, [r1, r0]
	strb r0, [r4, #0x15]
	mov r0, #2
	ldrsh r0, [r1, r0]
	strb r0, [r4, #0x17]
	mov r0, #1
	strb r0, [r4, #0x14]
_0224E638:
	add r0, r4, #0
	add sp, #0x2c
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end SafariDecoration_CreateArgs

	thumb_func_start ov02_0224E640
ov02_0224E640: ; 0x0224E640
	push {r3, r4, r5, lr}
	add r4, r0, #0
	bl Save_PlayerData_GetProfile
	bl PlayerProfile_GetTrainerID
	add r5, r0, #0
	add r0, r4, #0
	bl Save_SafariZone_Get
	bl SafariZone_GetObjectUnlockLevel
	add r4, r0, #0
	add r0, r5, #0
	mov r1, #0xa
	bl _u32_div_f
	lsl r0, r1, #0x18
	lsr r0, r0, #0x18
	cmp r0, #6
	bhs _0224E672
	mov r1, #3
	bl _s32_div_f
	b _0224E67C
_0224E672:
	sub r1, r0, #6
	lsr r0, r1, #0x1f
	add r0, r1, r0
	asr r0, r0, #1
	add r0, r0, #2
_0224E67C:
	lsl r0, r0, #0x18
	lsr r1, r0, #0x18
	mov r0, #3
	sub r0, r0, r1
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	add r0, r0, #1
	cmp r4, r0
	blt _0224E692
	mov r0, #1
	pop {r3, r4, r5, pc}
_0224E692:
	mov r0, #0
	pop {r3, r4, r5, pc}
	.balign 4, 0
	thumb_func_end ov02_0224E640

	thumb_func_start ov02_0224E698
ov02_0224E698: ; 0x0224E698
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x20
	add r5, r0, #0
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetFacingDirection
	lsl r0, r0, #0x18
	lsr r7, r0, #0x18
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetXCoord
	lsl r0, r0, #0x10
	asr r6, r0, #0x10
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetZCoord
	lsl r0, r0, #0x10
	asr r4, r0, #0x10
	ldr r0, [r5, #0x40]
	add r1, sp, #0x14
	bl PlayerAvatar_CopyPositionVector
	ldr r0, [r5, #0xc]
	bl Save_SafariZone_Get
	mov r1, #0
	bl SafariZone_GetAreaSet
	add r2, r0, #0
	add r0, r6, #0
	sub r0, #0x20
	asr r1, r0, #4
	lsr r1, r1, #0x1b
	add r1, r0, r1
	add r0, r4, #0
	sub r0, #0x20
	asr r3, r0, #4
	lsr r3, r3, #0x1b
	add r3, r0, r3
	asr r3, r3, #5
	lsl r0, r3, #1
	asr r1, r1, #5
	add r0, r3, r0
	add r0, r1, r0
	lsl r0, r0, #0x18
	lsr r1, r0, #0x18
	mov r0, #0x7a
	mul r0, r1
	add r0, r2, r0
	ldrb r0, [r0, #1]
	cmp r0, #0x1e
	blo _0224E706
	add sp, #0x20
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0224E706:
	ldr r0, [r5, #0x40]
	bl PlayerAvatar_GetState
	cmp r0, #2
	beq _0224E716
	add sp, #0x20
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224E716:
	ldr r0, [r5, #0xc]
	bl ov02_0224E640
	cmp r0, #0
	bne _0224E726
	add sp, #0x20
	mov r0, #2
	pop {r3, r4, r5, r6, r7, pc}
_0224E726:
	ldr r0, [sp, #0x18]
	add r1, r6, #0
	str r0, [sp]
	add r0, sp, #0x10
	add r0, #2
	str r0, [sp, #4]
	add r0, sp, #0x10
	str r0, [sp, #8]
	mov r0, #1
	str r0, [sp, #0xc]
	add r0, r5, #0
	add r2, r4, #0
	add r3, r7, #0
	bl ov02_0224EE4C
	cmp r0, #0
	beq _0224E74E
	add sp, #0x20
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224E74E:
	mov r0, #3
	add sp, #0x20
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224E698

	thumb_func_start ov02_0224E754
ov02_0224E754: ; 0x0224E754
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x10
	add r4, r0, #0
	ldr r0, [r4, #0x40]
	str r1, [sp]
	bl PlayerAvatar_GetFacingDirection
	add r6, r0, #0
	ldr r0, [r4, #0x40]
	bl PlayerAvatar_GetXCoord
	add r5, r0, #0
	add r0, r6, #0
	bl GetDeltaXByFacingDirection
	add r7, r5, r0
	ldr r0, [r4, #0x40]
	bl PlayerAvatar_GetZCoord
	add r5, r0, #0
	add r0, r6, #0
	bl GetDeltaYByFacingDirection
	add r6, r5, r0
	ldr r0, [r4, #0xc]
	bl Save_PlayerData_GetProfile
	bl PlayerProfile_GetTrainerGender
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	str r0, [sp, #4]
	add r0, r7, #0
	add r1, r6, #0
	bl ov02_0224E31C
	add r5, r0, #0
	lsr r1, r7, #0x1f
	lsl r0, r7, #0x1b
	sub r0, r0, r1
	mov r2, #0x1b
	ror r0, r2
	add r7, r1, r0
	lsr r1, r6, #0x1f
	lsl r0, r6, #0x1b
	sub r0, r0, r1
	ror r0, r2
	add r6, r1, r0
	ldr r0, [r4, #0xc]
	bl Save_SafariZone_Get
	mov r1, #0
	bl SafariZone_GetAreaSet
	mov r1, #0x7a
	mul r1, r5
	add r0, r0, r1
	str r0, [sp, #8]
	ldrb r0, [r0, #1]
	mov r4, #0
	cmp r0, #0
	ble _0224E81C
	ldr r0, [sp, #8]
	add r5, r0, #2
_0224E7D4:
	ldrb r1, [r5]
	ldr r2, [sp, #4]
	add r0, sp, #0xc
	bl GetSafariObjectConfig
	ldrb r1, [r5, #1]
	cmp r7, r1
	blt _0224E810
	ldrb r0, [r5, #3]
	cmp r6, r0
	bgt _0224E810
	add r2, sp, #0xc
	ldrb r2, [r2, #1]
	lsl r3, r2, #0x1c
	lsr r3, r3, #0x1d
	add r1, r1, r3
	cmp r7, r1
	bge _0224E810
	lsl r1, r2, #0x19
	lsr r1, r1, #0x1d
	sub r0, r0, r1
	cmp r6, r0
	ble _0224E810
	ldr r0, [sp]
	cmp r0, #0
	beq _0224E80A
	strh r4, [r0]
_0224E80A:
	add sp, #0x10
	ldrb r0, [r5]
	pop {r3, r4, r5, r6, r7, pc}
_0224E810:
	ldr r0, [sp, #8]
	add r4, r4, #1
	ldrb r0, [r0, #1]
	add r5, r5, #4
	cmp r4, r0
	blt _0224E7D4
_0224E81C:
	ldr r0, [sp]
	mov r1, #0
	strh r1, [r0]
	mov r0, #0xff
	add sp, #0x10
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end ov02_0224E754

	thumb_func_start ov02_0224E828
ov02_0224E828: ; 0x0224E828
	push {r4, r5, r6, r7, lr}
	sub sp, #0x6c
	add r4, r0, #0
	add r5, r1, #0
	ldr r0, [sp, #0x84]
	str r2, [sp, #4]
	ldr r1, _0224EB44 ; =ov02_02253A4C
	str r0, [sp, #0x84]
	ldr r0, [sp, #0x88]
	ldrb r2, [r1, #2]
	str r0, [sp, #0x88]
	ldrb r1, [r1, #3]
	str r3, [sp, #8]
	add r0, sp, #0x68
	strb r2, [r0, #1]
	strb r1, [r0, #2]
	ldr r1, [sp, #0x84]
	ldr r6, [sp, #0x80]
	strh r5, [r1]
	ldr r2, [sp, #4]
	ldr r1, [sp, #0x88]
	strh r2, [r1]
	ldr r1, [sp, #8]
	cmp r1, #3
	bls _0224E85C
	b _0224EB3E
_0224E85C:
	add r1, r1, r1
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0224E868: ; jump table
	.short _0224E870 - _0224E868 - 2 ; case 0
	.short _0224E870 - _0224E868 - 2 ; case 1
	.short _0224E992 - _0224E868 - 2 ; case 2
	.short _0224E992 - _0224E868 - 2 ; case 3
_0224E870:
	mov r0, #0
	str r0, [sp, #0x50]
	ldr r0, [sp, #8]
	cmp r0, #0
	beq _0224E87E
	mov r0, #1
	b _0224E880
_0224E87E:
	ldr r0, [sp, #0x50]
_0224E880:
	lsl r0, r0, #0x18
	lsr r1, r0, #0x18
	mov r0, #0
	str r0, [sp, #0x54]
	add r0, sp, #0x68
	add r0, #1
	ldrsb r0, [r0, r1]
	ldr r7, [sp, #0x54]
	str r0, [sp, #0x38]
	add r0, sp, #0x70
	ldrb r0, [r0, #0x1c]
	str r0, [sp, #0x48]
	lsl r0, r5, #4
	str r0, [sp, #0x44]
	add r0, #8
	str r0, [sp, #0x44]
	lsl r0, r0, #0xc
	str r0, [sp, #0x40]
_0224E8A4:
	ldr r0, [sp, #0x38]
	add r1, r7, r0
	ldr r0, [sp, #4]
	add r0, r0, r1
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0x3c]
	ldr r2, [sp, #0x3c]
	add r0, r4, #0
	add r1, r5, #0
	bl GetMetatileBehavior
	str r0, [sp, #0x58]
	ldr r2, [sp, #0x3c]
	add r0, r4, #0
	add r1, r5, #0
	bl sub_020548C0
	add r1, r0, #0
	ldr r0, [sp, #0x58]
	ldr r2, [sp, #0x48]
	bl ov02_0224EF6C
	cmp r0, #0
	beq _0224E95C
	ldr r0, [sp, #0x3c]
	lsl r0, r0, #4
	add r0, #8
	cmp r0, #0
	ble _0224E8F4
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #0x14]
	b _0224E904
_0224E8F4:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #0x14]
_0224E904:
	ldr r0, [sp, #0x44]
	cmp r0, #0
	ble _0224E91C
	ldr r0, [sp, #0x40]
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224E92A
_0224E91C:
	ldr r0, [sp, #0x40]
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224E92A:
	bl _ffix
	str r0, [sp, #0x5c]
	ldr r0, [sp, #0x14]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0x68
	str r0, [sp]
	ldr r2, [sp, #0x5c]
	add r0, r4, #0
	add r1, r6, #0
	bl sub_02054774
	add r1, sp, #0x68
	ldrb r1, [r1]
	cmp r1, #1
	bne _0224E95C
	cmp r0, r6
	bne _0224E95C
	ldr r0, [sp, #0x50]
	add r0, r0, #1
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	str r0, [sp, #0x50]
_0224E95C:
	ldr r0, [sp, #0x38]
	add r7, r7, r0
	ldr r0, [sp, #0x54]
	add r0, r0, #1
	str r0, [sp, #0x54]
	cmp r0, #2
	blt _0224E8A4
	ldr r0, [sp, #0x50]
	cmp r0, #2
	beq _0224E972
	b _0224EB3E
_0224E972:
	ldr r0, [sp, #0x84]
	strh r5, [r0]
	ldr r0, [sp, #8]
	cmp r0, #0
	bne _0224E984
	ldr r0, [sp, #4]
	sub r1, r0, #1
	ldr r0, [sp, #0x88]
	b _0224E98A
_0224E984:
	ldr r0, [sp, #4]
	add r1, r0, #2
	ldr r0, [sp, #0x88]
_0224E98A:
	strh r1, [r0]
	add sp, #0x6c
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224E992:
	ldr r1, [sp, #8]
	cmp r1, #2
	bne _0224E99C
	mov r1, #1
	b _0224E99E
_0224E99C:
	mov r1, #2
_0224E99E:
	ldrsb r0, [r0, r1]
	ldr r2, [sp, #4]
	add r0, r5, r0
	lsl r0, r0, #0x10
	asr r5, r0, #0x10
	add r0, r4, #0
	add r1, r5, #0
	bl GetMetatileBehavior
	str r0, [sp, #0x20]
	ldr r2, [sp, #4]
	add r0, r4, #0
	add r1, r5, #0
	bl sub_020548C0
	str r0, [sp, #0x18]
	ldr r0, [sp, #4]
	lsl r0, r0, #4
	add r0, #8
	cmp r0, #0
	ble _0224E9DC
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #0x10]
	b _0224E9EC
_0224E9DC:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #0x10]
_0224E9EC:
	lsl r0, r5, #4
	str r0, [sp, #0x2c]
	add r0, #8
	str r0, [sp, #0x2c]
	cmp r0, #0
	ble _0224EA0A
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224EA18
_0224EA0A:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224EA18:
	bl _ffix
	add r7, r0, #0
	ldr r0, [sp, #0x10]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0x68
	str r0, [sp]
	add r0, r4, #0
	add r1, r6, #0
	add r2, r7, #0
	bl sub_02054774
	add r7, r0, #0
	add r0, sp, #0x70
	ldrb r0, [r0, #0x1c]
	ldr r1, [sp, #0x18]
	str r0, [sp, #0x34]
	ldr r0, [sp, #0x20]
	ldr r2, [sp, #0x34]
	bl ov02_0224EF6C
	cmp r0, #0
	beq _0224EA56
	add r0, sp, #0x68
	ldrb r0, [r0]
	cmp r0, #1
	bne _0224EA56
	cmp r7, r6
	beq _0224EA5C
_0224EA56:
	add sp, #0x6c
	mov r0, #0
	pop {r4, r5, r6, r7, pc}
_0224EA5C:
	mov r0, #0
	str r0, [sp, #0x28]
	ldr r0, [sp, #0x2c]
	add r7, sp, #0x68
	lsl r0, r0, #0xc
	add r7, #1
	str r0, [sp, #0x4c]
_0224EA6A:
	mov r0, #0
	ldrsb r1, [r7, r0]
	ldr r0, [sp, #4]
	add r0, r0, r1
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0x30]
	ldr r2, [sp, #0x30]
	add r0, r4, #0
	add r1, r5, #0
	bl GetMetatileBehavior
	str r0, [sp, #0x24]
	ldr r2, [sp, #0x30]
	add r0, r4, #0
	add r1, r5, #0
	bl sub_020548C0
	str r0, [sp, #0x1c]
	ldr r0, [sp, #0x30]
	lsl r0, r0, #4
	add r0, #8
	cmp r0, #0
	ble _0224EAAE
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #0xc]
	b _0224EABE
_0224EAAE:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #0xc]
_0224EABE:
	ldr r0, [sp, #0x2c]
	cmp r0, #0
	ble _0224EAD6
	ldr r0, [sp, #0x4c]
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224EAE4
_0224EAD6:
	ldr r0, [sp, #0x4c]
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224EAE4:
	bl _ffix
	str r0, [sp, #0x60]
	ldr r0, [sp, #0xc]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0x68
	str r0, [sp]
	ldr r2, [sp, #0x60]
	add r0, r4, #0
	add r1, r6, #0
	bl sub_02054774
	str r0, [sp, #0x64]
	ldr r0, [sp, #0x24]
	ldr r1, [sp, #0x1c]
	ldr r2, [sp, #0x34]
	bl ov02_0224EF6C
	cmp r0, #0
	beq _0224EB32
	add r0, sp, #0x68
	ldrb r0, [r0]
	cmp r0, #1
	bne _0224EB32
	ldr r0, [sp, #0x64]
	cmp r0, r6
	bne _0224EB32
	ldr r0, [sp, #0x84]
	strh r5, [r0]
	ldr r1, [sp, #4]
	ldr r0, [sp, #0x28]
	add r1, r1, r0
	ldr r0, [sp, #0x88]
	add sp, #0x6c
	strh r1, [r0]
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224EB32:
	ldr r0, [sp, #0x28]
	add r7, r7, #1
	add r0, r0, #1
	str r0, [sp, #0x28]
	cmp r0, #2
	blt _0224EA6A
_0224EB3E:
	mov r0, #0
	add sp, #0x6c
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
_0224EB44: .word ov02_02253A4C
	thumb_func_end ov02_0224E828

	thumb_func_start ov02_0224EB48
ov02_0224EB48: ; 0x0224EB48
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x68
	add r4, r0, #0
	ldr r0, [sp, #0x84]
	str r1, [sp, #4]
	str r0, [sp, #0x84]
	ldr r0, [sp, #0x88]
	ldr r1, _0224EE48 ; =ov02_02253A4C
	str r0, [sp, #0x88]
	add r5, r2, #0
	add r2, r3, #0
	ldrb r0, [r1]
	add r3, sp, #0x64
	ldr r6, [sp, #0x80]
	strb r0, [r3, #1]
	ldrb r0, [r1, #1]
	cmp r2, #3
	strb r0, [r3, #2]
	ldr r1, [sp, #4]
	ldr r0, [sp, #0x84]
	strh r1, [r0]
	ldr r0, [sp, #0x88]
	strh r5, [r0]
	bls _0224EB7A
	b _0224EE42
_0224EB7A:
	add r0, r2, r2
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224EB86: ; jump table
	.short _0224EB8E - _0224EB86 - 2 ; case 0
	.short _0224EB8E - _0224EB86 - 2 ; case 1
	.short _0224ED3A - _0224EB86 - 2 ; case 2
	.short _0224ED3A - _0224EB86 - 2 ; case 3
_0224EB8E:
	cmp r2, #0
	bne _0224EB96
	mov r0, #1
	b _0224EB98
_0224EB96:
	mov r0, #2
_0224EB98:
	ldrsb r0, [r3, r0]
	ldr r1, [sp, #4]
	add r0, r5, r0
	lsl r0, r0, #0x10
	asr r5, r0, #0x10
	add r0, r4, #0
	add r2, r5, #0
	bl GetMetatileBehavior
	str r0, [sp, #0x50]
	ldr r1, [sp, #4]
	add r0, r4, #0
	add r2, r5, #0
	bl sub_020548C0
	str r0, [sp, #0x4c]
	lsl r0, r5, #4
	str r0, [sp, #0x24]
	add r0, #8
	str r0, [sp, #0x24]
	cmp r0, #0
	ble _0224EBD8
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #0x14]
	b _0224EBE8
_0224EBD8:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #0x14]
_0224EBE8:
	ldr r0, [sp, #4]
	lsl r0, r0, #4
	add r0, #8
	cmp r0, #0
	ble _0224EC04
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224EC12
_0224EC04:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224EC12:
	bl _ffix
	add r7, r0, #0
	ldr r0, [sp, #0x14]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0x64
	str r0, [sp]
	add r0, r4, #0
	add r1, r6, #0
	add r2, r7, #0
	bl sub_02054774
	add r7, r0, #0
	add r0, sp, #0x70
	ldrb r0, [r0, #0x1c]
	ldr r1, [sp, #0x4c]
	str r0, [sp, #0x30]
	ldr r0, [sp, #0x50]
	ldr r2, [sp, #0x30]
	bl ov02_0224EF6C
	cmp r0, #0
	beq _0224EC50
	add r0, sp, #0x64
	ldrb r0, [r0]
	cmp r0, #1
	bne _0224EC50
	cmp r7, r6
	beq _0224EC56
_0224EC50:
	add sp, #0x68
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224EC56:
	mov r0, #0
	str r0, [sp, #0x48]
	ldr r0, [sp, #0x24]
	add r7, sp, #0x64
	lsl r0, r0, #0xc
	add r7, #1
	str r0, [sp, #0x34]
_0224EC64:
	mov r0, #0
	ldrsb r1, [r7, r0]
	ldr r0, [sp, #4]
	add r2, r5, #0
	sub r0, r0, r1
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0x2c]
	ldr r1, [sp, #0x2c]
	add r0, r4, #0
	bl GetMetatileBehavior
	str r0, [sp, #0x20]
	ldr r1, [sp, #0x2c]
	add r0, r4, #0
	add r2, r5, #0
	bl sub_020548C0
	str r0, [sp, #0x1c]
	ldr r0, [sp, #0x24]
	cmp r0, #0
	ble _0224ECA4
	ldr r0, [sp, #0x34]
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #0x10]
	b _0224ECB4
_0224ECA4:
	ldr r0, [sp, #0x34]
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #0x10]
_0224ECB4:
	ldr r0, [sp, #0x2c]
	lsl r0, r0, #4
	add r0, #8
	cmp r0, #0
	ble _0224ECD0
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224ECDE
_0224ECD0:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224ECDE:
	bl _ffix
	str r0, [sp, #0x54]
	ldr r0, [sp, #0x10]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0x64
	str r0, [sp]
	ldr r2, [sp, #0x54]
	add r0, r4, #0
	add r1, r6, #0
	bl sub_02054774
	str r0, [sp, #0x58]
	ldr r0, [sp, #0x20]
	ldr r1, [sp, #0x1c]
	ldr r2, [sp, #0x30]
	bl ov02_0224EF6C
	cmp r0, #0
	beq _0224ED2C
	add r0, sp, #0x64
	ldrb r0, [r0]
	cmp r0, #1
	bne _0224ED2C
	ldr r0, [sp, #0x58]
	cmp r0, r6
	bne _0224ED2C
	ldr r1, [sp, #4]
	ldr r0, [sp, #0x48]
	sub r1, r1, r0
	ldr r0, [sp, #0x84]
	strh r1, [r0]
	ldr r0, [sp, #0x88]
	add sp, #0x68
	strh r5, [r0]
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0224ED2C:
	ldr r0, [sp, #0x48]
	add r7, r7, #1
	add r0, r0, #1
	str r0, [sp, #0x48]
	cmp r0, #2
	blt _0224EC64
	b _0224EE42
_0224ED3A:
	mov r0, #0
	str r0, [sp, #0x44]
	cmp r2, #2
	bne _0224ED4E
	ldr r0, [sp, #4]
	sub r0, r0, #2
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0xc]
	b _0224ED58
_0224ED4E:
	ldr r0, [sp, #4]
	add r0, r0, #1
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0xc]
_0224ED58:
	mov r0, #0
	str r0, [sp, #0x18]
	add r0, sp, #0x70
	ldrb r0, [r0, #0x1c]
	ldr r7, [sp, #0xc]
	str r0, [sp, #0x40]
	lsl r0, r5, #4
	str r0, [sp, #0x3c]
	add r0, #8
	str r0, [sp, #0x3c]
	lsl r0, r0, #0xc
	str r0, [sp, #0x38]
_0224ED70:
	lsl r0, r7, #0x10
	asr r0, r0, #0x10
	str r0, [sp, #0x28]
	ldr r1, [sp, #0x28]
	add r0, r4, #0
	add r2, r5, #0
	bl GetMetatileBehavior
	str r0, [sp, #0x5c]
	ldr r1, [sp, #0x28]
	add r0, r4, #0
	add r2, r5, #0
	bl sub_020548C0
	add r1, r0, #0
	ldr r0, [sp, #0x5c]
	ldr r2, [sp, #0x40]
	bl ov02_0224EF6C
	cmp r0, #0
	beq _0224EE20
	ldr r0, [sp, #0x3c]
	cmp r0, #0
	ble _0224EDB4
	ldr r0, [sp, #0x38]
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	str r0, [sp, #8]
	b _0224EDC4
_0224EDB4:
	ldr r0, [sp, #0x38]
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
	str r0, [sp, #8]
_0224EDC4:
	ldr r0, [sp, #0x28]
	lsl r0, r0, #4
	add r0, #8
	cmp r0, #0
	ble _0224EDE0
	lsl r0, r0, #0xc
	bl _fflt
	add r1, r0, #0
	mov r0, #0x3f
	lsl r0, r0, #0x18
	bl _fadd
	b _0224EDEE
_0224EDE0:
	lsl r0, r0, #0xc
	bl _fflt
	mov r1, #0x3f
	lsl r1, r1, #0x18
	bl _fsub
_0224EDEE:
	bl _ffix
	str r0, [sp, #0x60]
	ldr r0, [sp, #8]
	bl _ffix
	add r3, r0, #0
	add r0, sp, #0x64
	str r0, [sp]
	ldr r2, [sp, #0x60]
	add r0, r4, #0
	add r1, r6, #0
	bl sub_02054774
	add r1, sp, #0x64
	ldrb r1, [r1]
	cmp r1, #1
	bne _0224EE20
	cmp r0, r6
	bne _0224EE20
	ldr r0, [sp, #0x44]
	add r0, r0, #1
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	str r0, [sp, #0x44]
_0224EE20:
	ldr r0, [sp, #0x18]
	add r7, r7, #1
	add r0, r0, #1
	str r0, [sp, #0x18]
	cmp r0, #2
	blt _0224ED70
	ldr r0, [sp, #0x44]
	cmp r0, #2
	bne _0224EE42
	ldr r1, [sp, #0xc]
	ldr r0, [sp, #0x84]
	strh r1, [r0]
	ldr r0, [sp, #0x88]
	add sp, #0x68
	strh r5, [r0]
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0224EE42:
	mov r0, #0
	add sp, #0x68
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224EE48: .word ov02_02253A4C
	thumb_func_end ov02_0224EB48

	thumb_func_start ov02_0224EE4C
ov02_0224EE4C: ; 0x0224EE4C
	push {r4, r5, r6, r7, lr}
	sub sp, #0x24
	str r1, [sp, #0x14]
	str r2, [sp, #0x18]
	ldr r4, [sp, #0x38]
	str r3, [sp, #0x1c]
	str r4, [sp, #0x38]
	ldr r4, [sp, #0x44]
	ldr r6, [sp, #0x3c]
	str r4, [sp, #0x44]
	ldr r4, _0224EF68 ; =ov02_02253A4C
	ldr r7, [sp, #0x40]
	ldrb r5, [r4, #4]
	add r4, sp, #0x20
	str r0, [sp, #0x10]
	strb r5, [r4]
	ldr r4, _0224EF68 ; =ov02_02253A4C
	ldrb r5, [r4, #5]
	add r4, sp, #0x20
	strb r5, [r4, #1]
	ldr r4, [sp, #0x14]
	strh r4, [r6]
	ldr r4, [sp, #0x18]
	strh r4, [r7]
	ldr r4, [sp, #0x1c]
	cmp r4, #3
	bhi _0224EF60
	add r4, r4, r4
	add r4, pc
	ldrh r4, [r4, #6]
	lsl r4, r4, #0x10
	asr r4, r4, #0x10
	add pc, r4
_0224EE8E: ; jump table
	.short _0224EE96 - _0224EE8E - 2 ; case 0
	.short _0224EE96 - _0224EE8E - 2 ; case 1
	.short _0224EEFC - _0224EE8E - 2 ; case 2
	.short _0224EEFC - _0224EE8E - 2 ; case 3
_0224EE96:
	ldr r4, [sp, #0x38]
	str r4, [sp]
	str r6, [sp, #4]
	str r7, [sp, #8]
	ldr r4, [sp, #0x44]
	str r4, [sp, #0xc]
	bl ov02_0224E828
	cmp r0, #0
	beq _0224EF60
	mov r4, #0
	add r5, sp, #0x20
_0224EEAE:
	ldr r0, [sp, #0x38]
	mov r1, #0
	str r0, [sp]
	str r6, [sp, #4]
	str r7, [sp, #8]
	ldr r0, [sp, #0x44]
	str r0, [sp, #0xc]
	ldrsb r2, [r5, r1]
	ldr r1, [sp, #0x14]
	ldr r0, [sp, #0x10]
	add r1, r1, r2
	lsl r1, r1, #0x10
	ldr r2, [sp, #0x18]
	ldr r3, [sp, #0x1c]
	asr r1, r1, #0x10
	bl ov02_0224E828
	cmp r0, #0
	beq _0224EEF2
	ldr r0, [sp, #0x14]
	sub r0, r0, r4
	strh r0, [r6]
	ldr r0, [sp, #0x1c]
	cmp r0, #0
	bne _0224EEE6
	ldr r0, [sp, #0x18]
	sub r0, r0, #1
	b _0224EEEA
_0224EEE6:
	ldr r0, [sp, #0x18]
	add r0, r0, #2
_0224EEEA:
	add sp, #0x24
	strh r0, [r7]
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224EEF2:
	add r4, r4, #1
	add r5, r5, #1
	cmp r4, #2
	blt _0224EEAE
	b _0224EF60
_0224EEFC:
	ldr r4, [sp, #0x38]
	str r4, [sp]
	str r6, [sp, #4]
	str r7, [sp, #8]
	ldr r4, [sp, #0x44]
	str r4, [sp, #0xc]
	bl ov02_0224EB48
	cmp r0, #0
	beq _0224EF60
	mov r5, #0
	add r4, sp, #0x20
_0224EF14:
	ldr r0, [sp, #0x38]
	mov r2, #0
	str r0, [sp]
	str r6, [sp, #4]
	str r7, [sp, #8]
	ldr r0, [sp, #0x44]
	str r0, [sp, #0xc]
	ldrsb r3, [r4, r2]
	ldr r2, [sp, #0x18]
	ldr r0, [sp, #0x10]
	sub r2, r2, r3
	lsl r2, r2, #0x10
	ldr r1, [sp, #0x14]
	ldr r3, [sp, #0x1c]
	asr r2, r2, #0x10
	bl ov02_0224EB48
	cmp r0, #0
	beq _0224EF58
	ldr r0, [sp, #0x1c]
	cmp r0, #2
	bne _0224EF46
	ldr r0, [sp, #0x14]
	sub r0, r0, #2
	b _0224EF4A
_0224EF46:
	ldr r0, [sp, #0x14]
	add r0, r0, #1
_0224EF4A:
	strh r0, [r6]
	ldr r0, [sp, #0x18]
	add sp, #0x24
	add r0, r0, r5
	strh r0, [r7]
	mov r0, #1
	pop {r4, r5, r6, r7, pc}
_0224EF58:
	add r5, r5, #1
	add r4, r4, #1
	cmp r5, #2
	blt _0224EF14
_0224EF60:
	mov r0, #0
	add sp, #0x24
	pop {r4, r5, r6, r7, pc}
	nop
_0224EF68: .word ov02_02253A4C
	thumb_func_end ov02_0224EE4C

	thumb_func_start ov02_0224EF6C
ov02_0224EF6C: ; 0x0224EF6C
	push {r3, lr}
	cmp r2, #0
	bne _0224EF78
	bl ov02_0224E4CC
	pop {r3, pc}
_0224EF78:
	bl ov02_0224E4DC
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224EF6C

	thumb_func_start FieldSystem_FollowMonInteract
FieldSystem_FollowMonInteract: ; 0x0224EF80
	ldr r3, _0224EF8C ; =TaskManager_Call
	ldr r0, [r0, #0x10]
	ldr r1, _0224EF90 ; =Task_FollowMonInteract
	mov r2, #0
	bx r3
	nop
_0224EF8C: .word TaskManager_Call
_0224EF90: .word Task_FollowMonInteract
	thumb_func_end FieldSystem_FollowMonInteract

	thumb_func_start ov02_0224EF94
ov02_0224EF94: ; 0x0224EF94
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #0x1b0
	add r7, r0, #0
	ldr r0, [r7, #0x20]
	ldr r0, [r0]
	bl MapHeader_GetMapSec
	add r2, r0, #0
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r7, r0]
	mov r1, #0xde
	add r0, #0x14
	add r2, r2, #1
	bl ReadWholeNarcMemberByIdPair
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r7, r0]
	mov r0, #0x9b
	lsl r0, r0, #2
	add r0, r1, r0
	mov r1, #0xde
	mov r2, #0
	bl ReadWholeNarcMemberByIdPair
	add r0, r7, #0
	add r1, sp, #4
	bl ov02_0224F058
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r7, r0]
	add r3, sp, #0x20
	str r0, [sp]
	add r0, #0x14
	str r0, [sp]
	mov r0, #0
	add r2, r0, #0
_0224EFE2:
	add r1, r2, #0
	add r1, #0x1e
	add r2, r2, #1
	add r0, r0, #1
	stmia r3!, {r1}
	cmp r2, #0xc
	blt _0224EFE2
	add r2, sp, #0x20
	lsl r1, r0, #2
	mov r3, #0
	add r1, r2, r1
_0224EFF8:
	stmia r1!, {r3}
	add r3, r3, #1
	add r0, r0, #1
	cmp r3, #0x1e
	blt _0224EFF8
	add r2, sp, #0x20
	lsl r1, r0, #2
	mov r3, #0x2a
	add r1, r2, r1
_0224F00A:
	stmia r1!, {r3}
	add r3, r3, #1
	add r0, r0, #1
	cmp r3, #0x64
	blt _0224F00A
	mov r5, #0
	add r4, sp, #0x20
_0224F018:
	ldr r1, [r4]
	mov r0, #0x14
	add r2, r1, #0
	mul r2, r0
	ldr r0, [sp]
	add r6, r0, r2
	ldrh r0, [r6, #0xa]
	lsl r0, r0, #0x10
	lsr r0, r0, #0x16
	beq _0224F044
	add r0, r7, #0
	add r1, r6, #0
	add r2, sp, #4
	bl ov02_0224F108
	cmp r0, #0
	beq _0224F044
	ldrh r0, [r6, #0xa]
	add sp, #0x1b0
	lsl r0, r0, #0x10
	lsr r0, r0, #0x16
	pop {r3, r4, r5, r6, r7, pc}
_0224F044:
	add r5, r5, #1
	add r4, r4, #4
	cmp r5, #0x64
	blt _0224F018
	bl GF_AssertFail
	mov r0, #0
	add sp, #0x1b0
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224EF94

	thumb_func_start ov02_0224F058
ov02_0224F058: ; 0x0224F058
	push {r4, r5, r6, lr}
	add r5, r0, #0
	ldr r0, [r5, #0xc]
	add r4, r1, #0
	bl SaveArray_Party_Get
	bl GetFirstAliveMonInParty_CrashIfNone
	mov r1, #5
	mov r2, #0
	add r6, r0, #0
	bl GetMonData
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r2, [r5, r1]
	ldr r1, _0224F100 ; =0x0000087E
	strh r0, [r2, r1]
	add r0, r6, #0
	mov r1, #0x70
	mov r2, #0
	bl GetMonData
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r2, [r5, r1]
	ldr r1, _0224F104 ; =0x0000087D
	strb r0, [r2, r1]
	add r0, r6, #0
	add r1, r4, #0
	bl ov02_0224F324
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F4BC
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F580
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F5D0
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F5FC
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F644
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F64C
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F698
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r3, [r5, r0]
	ldr r2, _0224F100 ; =0x0000087E
	add r0, r5, #0
	ldrh r1, [r3, r2]
	sub r2, r2, #1
	ldrb r2, [r3, r2]
	add r3, r4, #0
	bl ov02_0224F6AC
	add r0, r5, #0
	add r1, r4, #0
	bl ov02_0224F728
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r5, r0]
	ldr r0, _0224F100 ; =0x0000087E
	ldrh r0, [r1, r0]
	add r1, r4, #0
	bl ov02_0224F76C
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224F100: .word 0x0000087E
_0224F104: .word 0x0000087D
	thumb_func_end ov02_0224F058

	thumb_func_start ov02_0224F108
ov02_0224F108: ; 0x0224F108
	push {r3, r4, r5, r6, r7, lr}
	add r6, r0, #0
	add r5, r1, #0
	add r4, r2, #0
	bl LCRandom
	mov r1, #0x64
	bl _s32_div_f
	ldrb r0, [r5, #0x11]
	cmp r1, r0
	blt _0224F124
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F124:
	ldrh r7, [r5, #0x12]
	cmp r7, #0
	beq _0224F13E
	ldr r0, [r6, #0xc]
	bl Save_VarsFlags_Get
	add r1, r7, #0
	bl Save_VarsFlags_CheckFlagInArray
	cmp r0, #0
	bne _0224F13E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F13E:
	ldrb r0, [r5, #3]
	lsl r0, r0, #0x1b
	lsr r1, r0, #0x1b
	beq _0224F15E
	cmp r1, #9
	bne _0224F154
	ldrb r0, [r4]
	cmp r0, #0
	bne _0224F15E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F154:
	ldrb r0, [r4, #1]
	cmp r1, r0
	beq _0224F15E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F15E:
	ldrb r1, [r5]
	cmp r1, #0
	beq _0224F16E
	ldrb r0, [r4, #2]
	cmp r1, r0
	beq _0224F16E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F16E:
	ldrb r0, [r5, #2]
	lsl r0, r0, #0x18
	lsr r1, r0, #0x1d
	beq _0224F19C
	cmp r1, #7
	ldrb r0, [r4, #3]
	bne _0224F194
	cmp r0, #2
	beq _0224F19C
	cmp r0, #3
	beq _0224F19C
	cmp r0, #4
	beq _0224F19C
	cmp r0, #5
	beq _0224F19C
	cmp r0, #8
	beq _0224F19C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F194:
	cmp r1, r0
	beq _0224F19C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F19C:
	ldrh r0, [r5, #0xa]
	lsl r0, r0, #0x1d
	lsr r1, r0, #0x1d
	beq _0224F1BA
	cmp r1, #5
	ldrb r0, [r4, #0xc]
	bne _0224F1B2
	cmp r0, #5
	bhs _0224F1BA
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F1B2:
	cmp r1, r0
	beq _0224F1BA
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F1BA:
	ldrb r0, [r5, #0x10]
	lsl r0, r0, #0x18
	lsr r1, r0, #0x1d
	beq _0224F1D8
	cmp r1, #4
	ldrb r0, [r4, #0xd]
	bne _0224F1D0
	cmp r0, #4
	bhs _0224F1D8
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F1D0:
	cmp r1, r0
	beq _0224F1D8
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F1D8:
	ldrb r0, [r5, #0x10]
	lsl r0, r0, #0x1d
	lsr r1, r0, #0x1e
	beq _0224F1EA
	ldrb r0, [r4, #4]
	cmp r1, r0
	beq _0224F1EA
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F1EA:
	ldrb r0, [r5, #0x10]
	lsl r0, r0, #0x1b
	lsr r1, r0, #0x1e
	beq _0224F212
	cmp r1, #3
	bne _0224F200
	ldrb r0, [r4, #0xe]
	cmp r0, #0
	bne _0224F200
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F200:
	cmp r1, #1
	bne _0224F20E
	ldrb r0, [r4, #0xf]
	cmp r0, #0
	bne _0224F20E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F20E:
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F212:
	ldrb r0, [r5, #4]
	lsl r0, r0, #0x1b
	lsr r1, r0, #0x1b
	beq _0224F22A
	ldrb r0, [r4, #5]
	cmp r1, r0
	beq _0224F22A
	ldrb r0, [r4, #6]
	cmp r1, r0
	beq _0224F22A
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F22A:
	ldrh r0, [r5, #8]
	lsl r0, r0, #0x1d
	lsr r1, r0, #0x1d
	beq _0224F23C
	ldrb r0, [r4, #0x11]
	cmp r1, r0
	beq _0224F23C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F23C:
	ldrh r1, [r5, #0xe]
	cmp r1, #0
	beq _0224F24C
	ldrb r0, [r4, #0x12]
	cmp r1, r0
	beq _0224F24C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F24C:
	ldrb r1, [r5, #5]
	cmp r1, #0
	beq _0224F25C
	ldrb r0, [r4, #0x13]
	cmp r1, r0
	beq _0224F25C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F25C:
	ldrh r0, [r5, #0xc]
	cmp r0, #0
	beq _0224F26E
	sub r1, r0, #1
	ldrh r0, [r4, #0x1a]
	cmp r1, r0
	beq _0224F26E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F26E:
	ldrh r0, [r5, #0xa]
	lsl r0, r0, #0x1a
	lsr r1, r0, #0x1d
	beq _0224F280
	ldrb r0, [r4, #0x14]
	cmp r1, r0
	beq _0224F280
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F280:
	ldrb r0, [r5, #1]
	lsl r0, r0, #0x1c
	lsr r0, r0, #0x1c
	beq _0224F298
	mov r1, #0x15
	ldrsb r1, [r4, r1]
	bl ov02_02250628
	cmp r0, #0
	bne _0224F298
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F298:
	ldrb r0, [r5, #4]
	lsl r0, r0, #0x18
	lsr r1, r0, #0x1d
	beq _0224F2AA
	ldrb r0, [r4, #0x16]
	cmp r1, r0
	beq _0224F2AA
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F2AA:
	ldrb r0, [r5, #1]
	lsl r0, r0, #0x18
	lsr r0, r0, #0x1c
	beq _0224F2C0
	ldrb r1, [r4, #7]
	bl ov02_02250594
	cmp r0, #0
	bne _0224F2C0
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F2C0:
	ldrb r0, [r5, #2]
	lsl r0, r0, #0x1d
	lsr r1, r0, #0x1d
	beq _0224F2D2
	ldrb r0, [r4, #8]
	cmp r1, r0
	beq _0224F2D2
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F2D2:
	ldrb r0, [r5, #6]
	cmp r0, #0
	beq _0224F2E6
	ldrb r1, [r4, #0xa]
	bl ov02_022506D4
	cmp r0, #0
	bne _0224F2E6
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F2E6:
	ldrb r0, [r5, #7]
	cmp r0, #0
	beq _0224F2FA
	ldrb r1, [r4, #0xb]
	bl ov02_02250738
	cmp r0, #0
	bne _0224F2FA
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F2FA:
	ldrb r0, [r5, #2]
	lsl r0, r0, #0x1b
	lsr r1, r0, #0x1e
	beq _0224F30C
	ldrb r0, [r4, #9]
	cmp r1, r0
	beq _0224F30C
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F30C:
	ldrh r0, [r5, #8]
	lsl r0, r0, #0x10
	lsr r1, r0, #0x1d
	beq _0224F31E
	ldrb r0, [r4, #0x17]
	cmp r1, r0
	beq _0224F31E
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
_0224F31E:
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F108

	thumb_func_start ov02_0224F324
ov02_0224F324: ; 0x0224F324
	push {r4, r5, r6, r7, lr}
	sub sp, #0x14
	add r5, r1, #0
	mov r1, #6
	mov r2, #0
	add r7, r0, #0
	bl GetMonData
	cmp r0, #0
	beq _0224F34E
	mov r1, #1
	lsl r0, r0, #0x10
	strb r1, [r5]
	lsr r0, r0, #0x10
	mov r1, #5
	mov r2, #0xb
	bl GetItemAttr
	bl ov02_0224F820
	b _0224F354
_0224F34E:
	mov r0, #0
	strb r0, [r5]
	mov r0, #8
_0224F354:
	strb r0, [r5, #1]
	add r0, r7, #0
	mov r1, #0xa3
	mov r2, #0
	bl GetMonData
	add r4, r0, #0
	add r0, r7, #0
	mov r1, #0xa4
	mov r2, #0
	bl GetMonData
	add r1, r0, #0
	mov r0, #0x64
	mul r0, r4
	bl _s32_div_f
	cmp r0, #0x64
	bne _0224F380
	mov r0, #1
	strb r0, [r5, #2]
	b _0224F3A2
_0224F380:
	cmp r0, #0x4b
	blt _0224F38A
	mov r0, #2
	strb r0, [r5, #2]
	b _0224F3A2
_0224F38A:
	cmp r0, #0x32
	blt _0224F394
	mov r0, #3
	strb r0, [r5, #2]
	b _0224F3A2
_0224F394:
	cmp r0, #0x19
	blt _0224F39E
	mov r0, #4
	strb r0, [r5, #2]
	b _0224F3A2
_0224F39E:
	mov r0, #5
	strb r0, [r5, #2]
_0224F3A2:
	add r0, r7, #0
	mov r1, #0xa0
	mov r2, #0
	bl GetMonData
	mov r1, #0x88
	tst r1, r0
	beq _0224F3B8
	mov r0, #5
	strb r0, [r5, #3]
	b _0224F3FA
_0224F3B8:
	mov r1, #7
	tst r1, r0
	beq _0224F3C4
	mov r0, #8
	strb r0, [r5, #3]
	b _0224F3FA
_0224F3C4:
	mov r1, #0x10
	tst r1, r0
	beq _0224F3D0
	mov r0, #2
	strb r0, [r5, #3]
	b _0224F3FA
_0224F3D0:
	mov r1, #0x20
	tst r1, r0
	beq _0224F3DC
	mov r0, #3
	strb r0, [r5, #3]
	b _0224F3FA
_0224F3DC:
	mov r1, #0x40
	tst r1, r0
	beq _0224F3E8
	mov r0, #4
	strb r0, [r5, #3]
	b _0224F3FA
_0224F3E8:
	cmp r0, #0
	bne _0224F3F2
	mov r0, #1
	strb r0, [r5, #3]
	b _0224F3FA
_0224F3F2:
	bl GF_AssertFail
	mov r0, #1
	strb r0, [r5, #3]
_0224F3FA:
	add r0, r7, #0
	mov r1, #0xa1
	mov r2, #0
	bl GetMonData
	add r1, r0, #2
	cmp r1, #0x32
	blt _0224F410
	mov r0, #4
	strb r0, [r5, #4]
	b _0224F420
_0224F410:
	sub r0, r0, #2
	cmp r0, #0x32
	bgt _0224F41C
	mov r0, #6
	strb r0, [r5, #4]
	b _0224F420
_0224F41C:
	mov r0, #5
	strb r0, [r5, #4]
_0224F420:
	add r0, r7, #0
	mov r1, #0xb1
	mov r2, #0
	bl GetMonData
	add r4, r0, #0
	add r0, r7, #0
	mov r1, #0xb2
	mov r2, #0
	bl GetMonData
	add r6, r0, #0
	add r0, r4, #0
	bl ov02_0224F79C
	strb r0, [r5, #5]
	add r0, r6, #0
	bl ov02_0224F79C
	strb r0, [r5, #6]
	add r0, r7, #0
	mov r1, #9
	mov r2, #0
	bl GetMonData
	strb r0, [r5, #7]
	add r0, r7, #0
	bl GetMonNature
	lsl r1, r0, #2
	ldr r0, _0224F4B4 ; =ov02_02253AC0
	mov r2, #0
	ldr r0, [r0, r1]
	mov r1, #0x6f
	strb r0, [r5, #8]
	add r0, r7, #0
	bl GetMonData
	cmp r0, #0
	bne _0224F474
	mov r0, #1
	b _0224F476
_0224F474:
	mov r0, #2
_0224F476:
	ldr r3, _0224F4B8 ; =ov02_02253A5C
	strb r0, [r5, #9]
	ldmia r3!, {r0, r1}
	add r2, sp, #0
	add r6, r2, #0
	stmia r2!, {r0, r1}
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	mov r4, #0
	str r0, [r2]
	strb r4, [r5, #0xb]
	add r5, #0xb
_0224F490:
	ldr r1, [r6]
	add r0, r7, #0
	mov r2, #0
	bl GetMonData
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	lsl r0, r4
	ldrb r1, [r5]
	add r4, r4, #1
	add r6, r6, #4
	orr r0, r1
	strb r0, [r5]
	cmp r4, #5
	blt _0224F490
	add sp, #0x14
	pop {r4, r5, r6, r7, pc}
	nop
_0224F4B4: .word ov02_02253AC0
_0224F4B8: .word ov02_02253A5C
	thumb_func_end ov02_0224F324

	thumb_func_start ov02_0224F4BC
ov02_0224F4BC: ; 0x0224F4BC
	push {r4, r5, r6, r7, lr}
	sub sp, #0x14
	add r4, r0, #0
	add r5, r1, #0
	mov r0, #0
	strb r0, [r5, #0xc]
	strb r0, [r5, #0xe]
	strb r0, [r5, #0xf]
	strb r0, [r5, #0x10]
	ldr r0, [r4, #0x40]
	bl PlayerAvatar_GetXCoord
	str r0, [sp, #4]
	ldr r0, [r4, #0x40]
	bl PlayerAvatar_GetZCoord
	str r0, [sp]
	ldr r0, [r4, #0x3c]
	bl MapObjectManager_GetObjectCount
	str r0, [sp, #8]
	ldr r0, [r4, #0x3c]
	bl MapObjectManager_GetObjects
	str r0, [sp, #0x10]
	mov r0, #0
	str r0, [sp, #0xc]
	ldr r0, [sp, #8]
	cmp r0, #0
	ble _0224F57A
	add r7, r5, #0
	add r7, #0xc
_0224F4FC:
	ldr r0, [sp, #0x10]
	bl MapObject_CheckActive
	cmp r0, #1
	bne _0224F568
	ldr r0, [sp, #0x10]
	bl MapObject_GetXCoord
	add r4, r0, #0
	ldr r0, [sp, #0x10]
	bl MapObject_GetZCoord
	ldr r1, [sp, #4]
	sub r6, r1, r4
	ldr r1, [sp]
	sub r4, r1, r0
	ldr r0, [sp, #0x10]
	bl MapObject_GetSpriteID
	cmp r0, #0x54
	bne _0224F52C
	mov r0, #1
	strb r0, [r5, #0xf]
	b _0224F568
_0224F52C:
	cmp r0, #0x55
	bne _0224F536
	mov r0, #1
	strb r0, [r5, #0xe]
	b _0224F568
_0224F536:
	cmp r0, #0x56
	bne _0224F540
	mov r0, #1
	strb r0, [r5, #0x10]
	b _0224F568
_0224F540:
	mov r0, #0
	mvn r0, r0
	cmp r6, r0
	blt _0224F568
	cmp r6, #1
	bgt _0224F568
	cmp r4, r0
	blt _0224F568
	cmp r4, #1
	bgt _0224F568
	ldr r0, [sp, #0x10]
	bl MapObject_GetID
	cmp r0, #0xfd
	beq _0224F568
	cmp r0, #0xff
	beq _0224F568
	ldrb r0, [r7]
	add r0, r0, #1
	strb r0, [r7]
_0224F568:
	add r0, sp, #0x10
	bl MapObjectArray_NextObject2
	ldr r0, [sp, #0xc]
	add r1, r0, #1
	ldr r0, [sp, #8]
	str r1, [sp, #0xc]
	cmp r1, r0
	blt _0224F4FC
_0224F57A:
	add sp, #0x14
	pop {r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F4BC

	thumb_func_start ov02_0224F580
ov02_0224F580: ; 0x0224F580
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	str r0, [sp]
	str r1, [sp, #4]
	mov r4, #0
	bl Field_GetBgEvents
	add r5, r0, #0
	ldr r0, [sp]
	bl Field_GetNumBgEvents
	add r7, r0, #0
	beq _0224F5C6
	cmp r5, #0
	beq _0224F5C6
	add r6, r4, #0
	cmp r7, #0
	ble _0224F5C6
_0224F5A4:
	ldrh r0, [r5, #2]
	cmp r0, #2
	bne _0224F5BE
	ldrh r0, [r5]
	bl HiddenItemScriptNoToFlagId
	add r1, r0, #0
	ldr r0, [sp]
	bl FieldSystem_FlagCheck
	cmp r0, #0
	bne _0224F5BE
	add r4, r4, #1
_0224F5BE:
	add r6, r6, #1
	add r5, #0x14
	cmp r6, r7
	blt _0224F5A4
_0224F5C6:
	ldr r0, [sp, #4]
	strb r4, [r0, #0xd]
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F580

	thumb_func_start ov02_0224F5D0
ov02_0224F5D0: ; 0x0224F5D0
	push {r4, lr}
	ldr r0, [r0, #0xc]
	add r4, r1, #0
	bl Save_LocalFieldData_Get
	bl LocalFieldData_GetWeatherType
	cmp r0, #0
	beq _0224F5E8
	cmp r0, #1
	beq _0224F5EE
	b _0224F5F4
_0224F5E8:
	mov r0, #1
	strb r0, [r4, #0x11]
	pop {r4, pc}
_0224F5EE:
	mov r0, #3
	strb r0, [r4, #0x11]
	pop {r4, pc}
_0224F5F4:
	mov r0, #0
	strb r0, [r4, #0x11]
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F5D0

	thumb_func_start ov02_0224F5FC
ov02_0224F5FC: ; 0x0224F5FC
	push {r4, r5, r6, lr}
	add r5, r0, #0
	add r4, r1, #0
	bl FollowMon_GetMapObject
	bl MapObject_GetXCoord
	add r6, r0, #0
	add r0, r5, #0
	bl FollowMon_GetMapObject
	bl MapObject_GetZCoord
	add r2, r0, #0
	add r0, r5, #0
	add r1, r6, #0
	bl GetMetatileBehavior
	mov r1, #0x12
	strb r0, [r4, #0x12]
	lsl r1, r1, #4
	ldr r2, [r5, r1]
	ldr r1, _0224F640 ; =0x00000882
	strh r0, [r2, r1]
	bl MetatileBehavior_CanGenerateWalkingEncounters
	cmp r0, #0
	beq _0224F63A
	mov r0, #1
	strb r0, [r4, #0x13]
	pop {r4, r5, r6, pc}
_0224F63A:
	mov r0, #2
	strb r0, [r4, #0x13]
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224F640: .word 0x00000882
	thumb_func_end ov02_0224F5FC

	thumb_func_start ov02_0224F644
ov02_0224F644: ; 0x0224F644
	ldr r0, [r0, #0x20]
	ldr r0, [r0]
	strh r0, [r1, #0x1a]
	bx lr
	thumb_func_end ov02_0224F644

	thumb_func_start ov02_0224F64C
ov02_0224F64C: ; 0x0224F64C
	push {r4, lr}
	add r4, r1, #0
	bl Field_GetTimeOfDay
	cmp r0, #4
	bhi _0224F68C
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224F664: ; jump table
	.short _0224F66E - _0224F664 - 2 ; case 0
	.short _0224F674 - _0224F664 - 2 ; case 1
	.short _0224F67A - _0224F664 - 2 ; case 2
	.short _0224F680 - _0224F664 - 2 ; case 3
	.short _0224F686 - _0224F664 - 2 ; case 4
_0224F66E:
	mov r0, #1
	strb r0, [r4, #0x14]
	pop {r4, pc}
_0224F674:
	mov r0, #2
	strb r0, [r4, #0x14]
	pop {r4, pc}
_0224F67A:
	mov r0, #3
	strb r0, [r4, #0x14]
	pop {r4, pc}
_0224F680:
	mov r0, #4
	strb r0, [r4, #0x14]
	pop {r4, pc}
_0224F686:
	mov r0, #5
	strb r0, [r4, #0x14]
	pop {r4, pc}
_0224F68C:
	bl GF_AssertFail
	mov r0, #0
	strb r0, [r4, #0x14]
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F64C

	thumb_func_start ov02_0224F698
ov02_0224F698: ; 0x0224F698
	push {r4, lr}
	add r4, r1, #0
	mov r1, #0x42
	lsl r1, r1, #2
	ldr r0, [r0, r1]
	bl FieldSystem_UnkSub108_GetMonMood
	strb r0, [r4, #0x15]
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F698

	thumb_func_start ov02_0224F6AC
ov02_0224F6AC: ; 0x0224F6AC
	push {r4, r5, r6, lr}
	sub sp, #0x10
	ldr r0, [r0, #0xc]
	add r5, r3, #0
	bl SaveArray_Party_Get
	add r4, r0, #0
	bl GetIdxOfFirstAliveMonInParty_CrashIfNone
	add r6, r0, #0
	add r0, r4, #0
	add r1, sp, #8
	add r2, r6, #0
	bl Party_GetMonAprijuiceModifiers
	add r0, r4, #0
	add r1, r6, #0
	bl Party_GetMonByIndex
	add r1, r0, #0
	add r0, sp, #0
	add r2, sp, #8
	mov r3, #0xb
	bl CalcMonPokeathlonStars
	add r0, sp, #0
	ldrh r2, [r0]
	lsl r0, r2, #0x1d
	lsl r2, r2, #0x11
	lsr r1, r0, #0x1d
	lsr r2, r2, #0x1d
	mov r0, #1
	cmp r1, r2
	bhs _0224F6F4
	add r1, r2, #0
	mov r0, #2
_0224F6F4:
	add r2, sp, #0
	ldrh r2, [r2]
	lsl r2, r2, #0x14
	lsr r2, r2, #0x1d
	cmp r1, r2
	bhs _0224F704
	add r1, r2, #0
	mov r0, #4
_0224F704:
	add r2, sp, #0
	ldrh r2, [r2]
	lsl r2, r2, #0x1a
	lsr r2, r2, #0x1d
	cmp r1, r2
	bhs _0224F714
	add r1, r2, #0
	mov r0, #3
_0224F714:
	add r2, sp, #0
	ldrh r2, [r2]
	lsl r2, r2, #0x17
	lsr r2, r2, #0x1d
	cmp r1, r2
	bhs _0224F722
	mov r0, #5
_0224F722:
	strb r0, [r5, #0x16]
	add sp, #0x10
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_0224F6AC

	thumb_func_start ov02_0224F728
ov02_0224F728: ; 0x0224F728
	push {r4, lr}
	add r0, #0xe4
	ldr r0, [r0]
	add r4, r1, #0
	bl MapObject_GetFacingDirection
	cmp r0, #3
	bhi _0224F764
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224F744: ; jump table
	.short _0224F74C - _0224F744 - 2 ; case 0
	.short _0224F752 - _0224F744 - 2 ; case 1
	.short _0224F758 - _0224F744 - 2 ; case 2
	.short _0224F75E - _0224F744 - 2 ; case 3
_0224F74C:
	mov r0, #3
	strb r0, [r4, #0x17]
	pop {r4, pc}
_0224F752:
	mov r0, #4
	strb r0, [r4, #0x17]
	pop {r4, pc}
_0224F758:
	mov r0, #2
	strb r0, [r4, #0x17]
	pop {r4, pc}
_0224F75E:
	mov r0, #1
	strb r0, [r4, #0x17]
	pop {r4, pc}
_0224F764:
	mov r0, #0
	strb r0, [r4, #0x17]
	pop {r4, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F728

	thumb_func_start ov02_0224F76C
ov02_0224F76C: ; 0x0224F76C
	push {r3, r4, r5, lr}
	add r5, r0, #0
	add r4, r1, #0
	cmp r5, #0
	ble _0224F77C
	ldr r0, _0224F798 ; =0x000001ED
	cmp r5, r0
	ble _0224F782
_0224F77C:
	bl GF_AssertFail
	pop {r3, r4, r5, pc}
_0224F782:
	mov r0, #0xe9
	mov r1, #0
	mov r2, #0xb
	bl AllocAtEndAndReadWholeNarcMemberByIdPair
	sub r1, r5, #1
	ldrb r1, [r0, r1]
	strb r1, [r4, #0xa]
	bl Heap_Free
	pop {r3, r4, r5, pc}
	.balign 4, 0
_0224F798: .word 0x000001ED
	thumb_func_end ov02_0224F76C

	thumb_func_start ov02_0224F79C
ov02_0224F79C: ; 0x0224F79C
	push {r3, lr}
	cmp r0, #0x11
	bhi _0224F816
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224F7AE: ; jump table
	.short _0224F7D2 - _0224F7AE - 2 ; case 0
	.short _0224F7D6 - _0224F7AE - 2 ; case 1
	.short _0224F7DA - _0224F7AE - 2 ; case 2
	.short _0224F7DE - _0224F7AE - 2 ; case 3
	.short _0224F7E2 - _0224F7AE - 2 ; case 4
	.short _0224F7E6 - _0224F7AE - 2 ; case 5
	.short _0224F7EA - _0224F7AE - 2 ; case 6
	.short _0224F7EE - _0224F7AE - 2 ; case 7
	.short _0224F7F2 - _0224F7AE - 2 ; case 8
	.short _0224F816 - _0224F7AE - 2 ; case 9
	.short _0224F7F6 - _0224F7AE - 2 ; case 10
	.short _0224F7FA - _0224F7AE - 2 ; case 11
	.short _0224F7FE - _0224F7AE - 2 ; case 12
	.short _0224F802 - _0224F7AE - 2 ; case 13
	.short _0224F806 - _0224F7AE - 2 ; case 14
	.short _0224F80A - _0224F7AE - 2 ; case 15
	.short _0224F80E - _0224F7AE - 2 ; case 16
	.short _0224F812 - _0224F7AE - 2 ; case 17
_0224F7D2:
	mov r0, #1
	pop {r3, pc}
_0224F7D6:
	mov r0, #7
	pop {r3, pc}
_0224F7DA:
	mov r0, #0xa
	pop {r3, pc}
_0224F7DE:
	mov r0, #8
	pop {r3, pc}
_0224F7E2:
	mov r0, #9
	pop {r3, pc}
_0224F7E6:
	mov r0, #0xd
	pop {r3, pc}
_0224F7EA:
	mov r0, #0xc
	pop {r3, pc}
_0224F7EE:
	mov r0, #0xe
	pop {r3, pc}
_0224F7F2:
	mov r0, #0x11
	pop {r3, pc}
_0224F7F6:
	mov r0, #2
	pop {r3, pc}
_0224F7FA:
	mov r0, #3
	pop {r3, pc}
_0224F7FE:
	mov r0, #5
	pop {r3, pc}
_0224F802:
	mov r0, #4
	pop {r3, pc}
_0224F806:
	mov r0, #0xb
	pop {r3, pc}
_0224F80A:
	mov r0, #6
	pop {r3, pc}
_0224F80E:
	mov r0, #0xf
	pop {r3, pc}
_0224F812:
	mov r0, #0x10
	pop {r3, pc}
_0224F816:
	bl GF_AssertFail
	mov r0, #0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_0224F79C

	thumb_func_start ov02_0224F820
ov02_0224F820: ; 0x0224F820
	push {r3, lr}
	cmp r0, #6
	bhi _0224F85C
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224F832: ; jump table
	.short _0224F840 - _0224F832 - 2 ; case 0
	.short _0224F844 - _0224F832 - 2 ; case 1
	.short _0224F848 - _0224F832 - 2 ; case 2
	.short _0224F84C - _0224F832 - 2 ; case 3
	.short _0224F850 - _0224F832 - 2 ; case 4
	.short _0224F854 - _0224F832 - 2 ; case 5
	.short _0224F858 - _0224F832 - 2 ; case 6
_0224F840:
	mov r0, #4
	pop {r3, pc}
_0224F844:
	mov r0, #2
	pop {r3, pc}
_0224F848:
	mov r0, #1
	pop {r3, pc}
_0224F84C:
	mov r0, #7
	pop {r3, pc}
_0224F850:
	mov r0, #6
	pop {r3, pc}
_0224F854:
	mov r0, #5
	pop {r3, pc}
_0224F858:
	mov r0, #3
	pop {r3, pc}
_0224F85C:
	bl GF_AssertFail
	mov r0, #8
	pop {r3, pc}
	thumb_func_end ov02_0224F820

	thumb_func_start ov02_0224F864
ov02_0224F864: ; 0x0224F864
	push {r4, lr}
	ldr r1, _0224F87C ; =0x00000884
	bl Heap_Alloc
	ldr r2, _0224F87C ; =0x00000884
	mov r1, #0
	add r4, r0, #0
	bl MI_CpuFill8
	add r0, r4, #0
	pop {r4, pc}
	nop
_0224F87C: .word 0x00000884
	thumb_func_end ov02_0224F864

	thumb_func_start ov02_0224F880
ov02_0224F880: ; 0x0224F880
	push {r3, r4, r5, lr}
	add r4, r0, #0
	add r2, r1, #0
	ldr r0, _0224F8E4 ; =0x000007E4
	mov r1, #0xdf
	add r0, r4, r0
	sub r2, r2, #1
	bl ReadWholeNarcMemberByIdPair
	ldr r0, _0224F8E8 ; =0x00000868
	mov r1, #0
	strb r1, [r4, r0]
	add r2, r0, #1
	strb r1, [r4, r2]
	add r2, r0, #3
	strb r1, [r4, r2]
	add r2, r0, #4
	ldrb r3, [r4, r2]
	mov r2, #0xf
	add r5, r4, #0
	bic r3, r2
	add r2, r0, #4
	strb r3, [r4, r2]
	add r2, r0, #2
	strb r1, [r4, r2]
	add r2, r0, #5
	strb r1, [r4, r2]
	add r0, r0, #6
	strh r1, [r4, r0]
	ldr r0, _0224F8E4 ; =0x000007E4
	ldr r2, _0224F8EC ; =0x0000FFFF
_0224F8BE:
	ldrh r3, [r5, r0]
	cmp r3, r2
	beq _0224F8CC
	add r1, r1, #1
	add r5, #8
	cmp r1, #5
	blt _0224F8BE
_0224F8CC:
	ldr r3, _0224F8F0 ; =0x0000086C
	lsl r1, r1, #0x18
	ldrb r0, [r4, r3]
	lsr r1, r1, #0x18
	mov r2, #0xf0
	lsl r1, r1, #0x1c
	bic r0, r2
	lsr r1, r1, #0x18
	orr r0, r1
	strb r0, [r4, r3]
	pop {r3, r4, r5, pc}
	nop
_0224F8E4: .word 0x000007E4
_0224F8E8: .word 0x00000868
_0224F8EC: .word 0x0000FFFF
_0224F8F0: .word 0x0000086C
	thumb_func_end ov02_0224F880

	thumb_func_start ov02_0224F8F4
ov02_0224F8F4: ; 0x0224F8F4
	ldr r3, _0224F8F8 ; =Heap_Free
	bx r3
	.balign 4, 0
_0224F8F8: .word Heap_Free
	thumb_func_end ov02_0224F8F4

	thumb_func_start ov02_0224F8FC
ov02_0224F8FC: ; 0x0224F8FC
	push {r3, r4, r5, r6, r7, lr}
	ldr r2, _0224FB2C ; =0x0000086C
	add r4, r1, #0
	ldrb r3, [r4, r2]
	add r5, r0, #0
	lsl r2, r3, #0x1c
	lsr r2, r2, #0x1c
	mov ip, r2
	cmp r2, #5
	blo _0224F93E
	bl ov02_02250504
	ldr r1, _0224FB30 ; =0x0000080C
	ldr r0, [r4, r1]
	cmp r0, #0
	beq _0224F920
	mov r0, #2
	pop {r3, r4, r5, r6, r7, pc}
_0224F920:
	add r0, r1, #0
	add r0, #0xa
	ldrb r0, [r4, r0]
	cmp r0, #0
	beq _0224F92E
	mov r0, #3
	pop {r3, r4, r5, r6, r7, pc}
_0224F92E:
	add r1, #0xb
	ldrb r0, [r4, r1]
	cmp r0, #0
	beq _0224F93A
	mov r0, #4
	pop {r3, r4, r5, r6, r7, pc}
_0224F93A:
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0224F93E:
	ldr r2, _0224FB2C ; =0x0000086C
	sub r2, #0x88
	add r7, r4, r2
	mov r2, ip
	lsl r2, r2, #3
	add r6, r7, r2
	ldrh r7, [r7, r2]
	ldr r2, _0224FB34 ; =0x0000FFFF
	cmp r7, r2
	bne _0224F980
	bl ov02_02250504
	ldr r1, _0224FB30 ; =0x0000080C
	ldr r0, [r4, r1]
	cmp r0, #0
	beq _0224F962
	mov r0, #2
	pop {r3, r4, r5, r6, r7, pc}
_0224F962:
	add r0, r1, #0
	add r0, #0xa
	ldrb r0, [r4, r0]
	cmp r0, #0
	beq _0224F970
	mov r0, #3
	pop {r3, r4, r5, r6, r7, pc}
_0224F970:
	add r1, #0xb
	ldrb r0, [r4, r1]
	cmp r0, #0
	beq _0224F97C
	mov r0, #4
	pop {r3, r4, r5, r6, r7, pc}
_0224F97C:
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0224F980:
	ldr r2, _0224FB2C ; =0x0000086C
	sub r2, r2, #3
	ldrb r2, [r4, r2]
	cmp r2, #7
	bls _0224F98C
	b _0224FB28
_0224F98C:
	add r2, r2, r2
	add r2, pc
	ldrh r2, [r2, #6]
	lsl r2, r2, #0x10
	asr r2, r2, #0x10
	add pc, r2
_0224F998: ; jump table
	.short _0224F9A8 - _0224F998 - 2 ; case 0
	.short _0224F9CA - _0224F998 - 2 ; case 1
	.short _0224F9E8 - _0224F998 - 2 ; case 2
	.short _0224FA06 - _0224F998 - 2 ; case 3
	.short _0224FA1A - _0224F998 - 2 ; case 4
	.short _0224FA3E - _0224F998 - 2 ; case 5
	.short _0224FA50 - _0224F998 - 2 ; case 6
	.short _0224FAEE - _0224F998 - 2 ; case 7
_0224F9A8:
	add r0, r4, #0
	add r1, r6, #0
	bl ov02_0224FB44
	cmp r0, #0
	beq _0224F9CA
	add r5, #0xe4
	ldr r0, [r5]
	bl MapObject_UnpauseMovement
	ldr r0, _0224FB38 ; =0x00000868
	mov r1, #0
	strb r1, [r4, r0]
	mov r1, #5
	add r0, r0, #1
	strb r1, [r4, r0]
	b _0224FB28
_0224F9CA:
	add r0, r5, #0
	add r1, r4, #0
	add r2, r6, #0
	bl ov02_0224FB54
	cmp r0, #0
	beq _0224F9E8
	add r5, #0xe4
	ldr r0, [r5]
	bl MapObject_UnpauseMovement
	ldr r0, _0224FB3C ; =0x00000869
	mov r1, #2
	strb r1, [r4, r0]
	b _0224FB28
_0224F9E8:
	add r0, r5, #0
	add r1, r4, #0
	add r2, r6, #0
	bl FollowMon_TryPrintInteractionMessage
	cmp r0, #0
	beq _0224FA06
	add r5, #0xe4
	ldr r0, [r5]
	bl MapObject_PauseMovement
	ldr r0, _0224FB3C ; =0x00000869
	mov r1, #6
	strb r1, [r4, r0]
	b _0224FB28
_0224FA06:
	add r0, r4, #0
	add r1, r6, #0
	bl ov02_0224FC74
	cmp r0, #0
	beq _0224FA1A
	ldr r0, _0224FB3C ; =0x00000869
	mov r1, #7
	strb r1, [r4, r0]
	b _0224FB28
_0224FA1A:
	ldr r2, _0224FB2C ; =0x0000086C
	mov r1, #0xf
	ldrb r3, [r4, r2]
	add r0, r3, #0
	bic r0, r1
	lsl r1, r3, #0x1c
	lsr r1, r1, #0x1c
	add r1, r1, #1
	lsl r1, r1, #0x18
	lsr r3, r1, #0x18
	mov r1, #0xf
	and r1, r3
	orr r0, r1
	strb r0, [r4, r2]
	mov r1, #0
	sub r0, r2, #3
	strb r1, [r4, r0]
	b _0224FB28
_0224FA3E:
	add r2, r7, #0
	bl ov02_02250004
	cmp r0, #0
	beq _0224FB28
	ldr r0, _0224FB3C ; =0x00000869
	mov r1, #1
	strb r1, [r4, r0]
	b _0224FB28
_0224FA50:
	ldr r0, _0224FB2C ; =0x0000086C
	add r0, r0, #2
	ldrh r0, [r4, r0]
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	bl DialogBox_IsPrintFinished
	cmp r0, #1
	bne _0224FB28
	ldr r1, _0224FB2C ; =0x0000086C
	ldrb r2, [r4, r1]
	lsl r0, r2, #0x18
	lsl r2, r2, #0x1c
	lsr r2, r2, #0x1c
	lsr r0, r0, #0x1c
	add r2, r2, #1
	cmp r0, r2
	ble _0224FAA8
	ldr r0, _0224FB40 ; =gSystem
	ldr r1, [r0, #0x48]
	mov r0, #3
	tst r0, r1
	beq _0224FB28
	add r0, r4, #0
	mov r1, #0
	bl ClearFrameAndWindow2
	add r0, r4, #0
	bl RemoveWindow
	ldr r0, [r4, #0x10]
	bl String_Delete
	add r0, r5, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	add r5, #0xd2
	bic r1, r0
	strb r1, [r5]
	ldr r0, _0224FB3C ; =0x00000869
	mov r1, #3
	strb r1, [r4, r0]
	b _0224FB28
_0224FAA8:
	add r0, r1, #0
	sub r0, #0x60
	ldr r0, [r4, r0]
	cmp r0, #0
	beq _0224FABA
	mov r2, #3
	sub r0, r1, #3
	strb r2, [r4, r0]
	b _0224FB28
_0224FABA:
	ldr r0, _0224FB40 ; =gSystem
	ldr r1, [r0, #0x48]
	mov r0, #3
	tst r0, r1
	beq _0224FB28
	add r0, r4, #0
	mov r1, #0
	bl ClearFrameAndWindow2
	add r0, r4, #0
	bl RemoveWindow
	ldr r0, [r4, #0x10]
	bl String_Delete
	add r0, r5, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	add r5, #0xd2
	bic r1, r0
	strb r1, [r5]
	ldr r0, _0224FB3C ; =0x00000869
	mov r1, #3
	strb r1, [r4, r0]
	b _0224FB28
_0224FAEE:
	ldr r0, _0224FB2C ; =0x0000086C
	add r0, r0, #1
	ldrb r1, [r4, r0]
	ldrb r0, [r6, #7]
	cmp r1, r0
	blo _0224FB1A
	mov r0, #0xf
	bic r3, r0
	mov r0, ip
	add r0, r0, #1
	lsl r0, r0, #0x18
	lsr r1, r0, #0x18
	mov r0, #0xf
	and r0, r1
	add r1, r3, #0
	orr r1, r0
	ldr r0, _0224FB2C ; =0x0000086C
	strb r1, [r4, r0]
	mov r1, #0
	sub r0, r0, #3
	strb r1, [r4, r0]
	b _0224FB28
_0224FB1A:
	ldr r0, _0224FB2C ; =0x0000086C
	add r0, r0, #1
	ldrb r0, [r4, r0]
	add r1, r0, #1
	ldr r0, _0224FB2C ; =0x0000086C
	add r0, r0, #1
	strb r1, [r4, r0]
_0224FB28:
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
_0224FB2C: .word 0x0000086C
_0224FB30: .word 0x0000080C
_0224FB34: .word 0x0000FFFF
_0224FB38: .word 0x00000868
_0224FB3C: .word 0x00000869
_0224FB40: .word gSystem
	thumb_func_end ov02_0224F8FC

	thumb_func_start ov02_0224FB44
ov02_0224FB44: ; 0x0224FB44
	ldrh r0, [r1]
	cmp r0, #0
	beq _0224FB4E
	mov r0, #1
	bx lr
_0224FB4E:
	mov r0, #0
	bx lr
	.balign 4, 0
	thumb_func_end ov02_0224FB44

	thumb_func_start ov02_0224FB54
ov02_0224FB54: ; 0x0224FB54
	push {r3, r4, r5, lr}
	add r5, r0, #0
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r5, r0]
	ldr r0, _0224FB98 ; =0x00000882
	add r4, r2, #0
	ldrh r0, [r1, r0]
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	bl sub_0205BB04
	cmp r0, #0
	beq _0224FB74
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224FB74:
	ldrb r2, [r4, #6]
	cmp r2, #0
	beq _0224FB92
	cmp r2, #0xe
	bls _0224FB82
	mov r0, #0
	pop {r3, r4, r5, pc}
_0224FB82:
	add r0, r5, #0
	add r5, #0xe4
	ldr r1, [r5]
	sub r2, r2, #1
	bl ov01_02203AB4
	mov r0, #1
	pop {r3, r4, r5, pc}
_0224FB92:
	mov r0, #0
	pop {r3, r4, r5, pc}
	nop
_0224FB98: .word 0x00000882
	thumb_func_end ov02_0224FB54

	thumb_func_start FollowMon_TryPrintInteractionMessage
FollowMon_TryPrintInteractionMessage: ; 0x0224FB9C
	push {r4, r5, r6, lr}
	add r6, r2, #0
	add r5, r0, #0
	ldrh r0, [r6, #2]
	add r4, r1, #0
	cmp r0, #0
	beq _0224FC00
	mov r0, #1
	lsl r0, r0, #0xa
	mov r1, #0xb
	bl String_New
	str r0, [r4, #0x10]
	ldr r0, [r5, #8]
	add r1, r4, #0
	mov r2, #3
	bl DialogBox_AddWindowToLayer3
	ldrh r3, [r6, #2]
	ldr r1, [r4, #0x10]
	add r0, r5, #0
	mov r2, #0xb
	sub r3, r3, #1
	bl FollowMon_ExpandInteractionMessage
	ldr r0, [r5, #0xc]
	bl Save_PlayerData_GetOptionsAddr
	add r6, r0, #0
	add r0, r4, #0
	add r1, r6, #0
	bl DialogBox_LoadFrame
	ldr r1, [r4, #0x10]
	add r0, r4, #0
	add r2, r6, #0
	mov r3, #1
	bl DialogBox_PrintMessage
	ldr r1, _0224FC04 ; =0x0000086E
	strh r0, [r4, r1]
	add r0, r5, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	add r5, #0xd2
	orr r0, r1
	strb r0, [r5]
	mov r0, #1
	pop {r4, r5, r6, pc}
_0224FC00:
	mov r0, #0
	pop {r4, r5, r6, pc}
	.balign 4, 0
_0224FC04: .word 0x0000086E
	thumb_func_end FollowMon_TryPrintInteractionMessage

	thumb_func_start ov02_0224FC08
ov02_0224FC08: ; 0x0224FC08
	push {r3, r4, r5, r6, lr}
	sub sp, #4
	add r5, r0, #0
	mov r0, #1
	add r4, r1, #0
	lsl r0, r0, #0xa
	mov r1, #0xb
	add r6, r2, #0
	bl String_New
	str r0, [r4, #0x10]
	ldr r0, [r5, #8]
	add r1, r4, #0
	mov r2, #3
	bl DialogBox_AddWindowToLayer3
	ldr r0, _0224FC6C ; =0x00000816
	mov r2, #0xb
	ldrb r0, [r4, r0]
	add r3, r6, #0
	str r0, [sp]
	ldr r1, [r4, #0x10]
	add r0, r5, #0
	bl ov02_0224FCE0
	ldr r0, [r5, #0xc]
	bl Save_PlayerData_GetOptionsAddr
	add r6, r0, #0
	add r0, r4, #0
	add r1, r6, #0
	bl DialogBox_LoadFrame
	ldr r1, [r4, #0x10]
	add r0, r4, #0
	add r2, r6, #0
	mov r3, #1
	bl DialogBox_PrintMessage
	ldr r1, _0224FC70 ; =0x0000086E
	strh r0, [r4, r1]
	add r0, r5, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	add r5, #0xd2
	orr r0, r1
	strb r0, [r5]
	add sp, #4
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
_0224FC6C: .word 0x00000816
_0224FC70: .word 0x0000086E
	thumb_func_end ov02_0224FC08

	thumb_func_start ov02_0224FC74
ov02_0224FC74: ; 0x0224FC74
	ldr r2, _0224FC88 ; =0x0000086D
	mov r3, #0
	strb r3, [r0, r2]
	ldrb r0, [r1, #7]
	cmp r0, #0
	beq _0224FC82
	mov r3, #1
_0224FC82:
	add r0, r3, #0
	bx lr
	nop
_0224FC88: .word 0x0000086D
	thumb_func_end ov02_0224FC74

	thumb_func_start FollowMon_ExpandInteractionMessage
FollowMon_ExpandInteractionMessage: ; 0x0224FC8C
	push {r3, r4, r5, r6, r7, lr}
	str r1, [sp]
	mov r1, #0x1b
	add r4, r2, #0
	add r2, r1, #0
	add r6, r0, #0
	add r7, r3, #0
	mov r0, #0
	add r2, #0xee
	add r3, r4, #0
	bl NewMsgDataFromNarc
	add r5, r0, #0
	add r0, r4, #0
	bl MessageFormat_New
	add r4, r0, #0
	add r0, r6, #0
	add r1, r4, #0
	bl FollowMon_PlaceholdersSet
	add r0, r5, #0
	add r1, r7, #0
	bl NewString_ReadMsgData
	add r6, r0, #0
	ldr r1, [sp]
	add r0, r4, #0
	add r2, r6, #0
	bl StringExpandPlaceholders
	add r0, r6, #0
	bl String_Delete
	add r0, r4, #0
	bl MessageFormat_Delete
	add r0, r5, #0
	bl DestroyMsgData
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end FollowMon_ExpandInteractionMessage

	thumb_func_start ov02_0224FCE0
ov02_0224FCE0: ; 0x0224FCE0
	push {r3, r4, r5, r6, r7, lr}
	sub sp, #8
	add r4, r2, #0
	add r5, r0, #0
	str r1, [sp]
	add r6, r3, #0
	mov r0, #0
	mov r1, #0x1b
	mov r2, #0x28
	add r3, r4, #0
	bl NewMsgDataFromNarc
	add r7, r0, #0
	add r0, r4, #0
	bl MessageFormat_New
	add r4, r0, #0
	mov r0, #2
	tst r0, r6
	ldr r0, [r5, #0xc]
	beq _0224FD3E
	bl Save_PlayerData_GetProfile
	add r2, r0, #0
	add r0, r4, #0
	mov r1, #0
	bl BufferPlayersName
	mov r1, #1
	add r0, r6, #0
	tst r0, r1
	add r2, sp, #0x10
	beq _0224FD30
	ldrb r2, [r2, #0x10]
	add r0, r4, #0
	sub r2, r2, #1
	bl BufferFashionName
	mov r1, #0x20
	b _0224FD72
_0224FD30:
	ldrb r2, [r2, #0x10]
	add r0, r4, #0
	sub r2, r2, #1
	bl BufferFashionNameWithArticle
	mov r1, #0x5f
	b _0224FD72
_0224FD3E:
	bl SaveArray_Party_Get
	bl GetFirstAliveMonInParty_CrashIfNone
	bl Mon_GetBoxMon
	str r0, [sp, #4]
	ldr r0, [r5, #0xc]
	bl Save_PlayerData_GetProfile
	add r2, r0, #0
	add r0, r4, #0
	mov r1, #0
	bl BufferPlayersName
	ldr r2, [sp, #4]
	add r0, r4, #0
	mov r1, #1
	bl BufferBoxMonNickname
	mov r0, #1
	tst r0, r6
	beq _0224FD70
	mov r1, #0x61
	b _0224FD72
_0224FD70:
	mov r1, #0x62
_0224FD72:
	add r0, r7, #0
	bl NewString_ReadMsgData
	add r5, r0, #0
	ldr r1, [sp]
	add r0, r4, #0
	add r2, r5, #0
	bl StringExpandPlaceholders
	add r0, r5, #0
	bl String_Delete
	add r0, r4, #0
	bl MessageFormat_Delete
	add r0, r7, #0
	bl DestroyMsgData
	add sp, #8
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224FCE0

	thumb_func_start ov02_0224FD9C
ov02_0224FD9C: ; 0x0224FD9C
	push {r4, r5, lr}
	sub sp, #0xc
	add r4, r1, #0
	add r5, r0, #0
	add r0, r4, #0
	add r1, sp, #0
	bl MapObject_CopyPositionVector
	mov r0, #2
	ldrsb r0, [r5, r0]
	cmp r0, #0
	beq _0224FDBC
	ldr r1, [sp]
	lsl r0, r0, #0xc
	add r0, r1, r0
	str r0, [sp]
_0224FDBC:
	mov r0, #3
	ldrsb r0, [r5, r0]
	cmp r0, #0
	beq _0224FDDC
	add r0, r4, #0
	bl FollowMon_GetSpecies
	cmp r0, #0x32
	beq _0224FDDC
	cmp r0, #0x33
	beq _0224FDDC
	mov r1, #3
	ldrsb r1, [r5, r1]
	add r0, r4, #0
	bl ov01_021F8F74
_0224FDDC:
	mov r0, #4
	ldrsb r0, [r5, r0]
	cmp r0, #0
	beq _0224FDEC
	ldr r1, [sp, #8]
	lsl r0, r0, #0xc
	add r0, r1, r0
	str r0, [sp, #8]
_0224FDEC:
	add r0, r4, #0
	add r1, sp, #0
	bl MapObject_SetPositionVector
	add sp, #0xc
	pop {r4, r5, pc}
	thumb_func_end ov02_0224FD9C

	thumb_func_start ov02_0224FDF8
ov02_0224FDF8: ; 0x0224FDF8
	push {r4, lr}
	sub sp, #8
	ldrb r0, [r0, #5]
	cmp r0, #0
	beq _0224FE32
	cmp r1, #0
	beq _0224FE32
	ldr r0, _0224FE38 ; =SEQ_SE_END
	cmp r1, r0
	bls _0224FE2C
	add r0, r0, #1
	cmp r1, r0
	bne _0224FE16
	mov r0, #0
	b _0224FE18
_0224FE16:
	mov r0, #0xb
_0224FE18:
	ldr r4, _0224FE3C ; =0x000001FF
	add r1, r2, #0
	str r4, [sp]
	str r3, [sp, #4]
	add r2, r4, #0
	add r3, r4, #0
	bl PlayCryEx
	add sp, #8
	pop {r4, pc}
_0224FE2C:
	add r0, r1, #0
	bl PlaySE
_0224FE32:
	add sp, #8
	pop {r4, pc}
	nop
_0224FE38: .word SEQ_SE_END
_0224FE3C: .word 0x000001FF
	thumb_func_end ov02_0224FDF8

	thumb_func_start ov02_0224FE40
ov02_0224FE40: ; 0x0224FE40
	push {r3, r4, r5, r6, r7, lr}
	add r5, r1, #0
	add r7, r0, #0
	ldrb r0, [r5]
	add r4, r2, #0
	cmp r0, #0
	beq _0224FE6C
	add r0, r4, #0
	bl MapObject_GetFacingDirection
	ldrb r1, [r5]
	lsl r0, r0, #0x18
	lsr r6, r0, #0x18
	add r0, r4, #0
	sub r1, r1, #1
	bl MapObject_SetFacingDirectionDirect
	add r0, r7, #0
	add r1, r4, #0
	add r2, r6, #0
	bl ov02_0224FE70
_0224FE6C:
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224FE40

	thumb_func_start ov02_0224FE70
ov02_0224FE70: ; 0x0224FE70
	push {r3, r4, r5, r6, lr}
	sub sp, #0xc
	add r4, r1, #0
	add r5, r0, #0
	add r0, r4, #0
	add r6, r2, #0
	bl ov01_022055DC
	cmp r0, #0
	beq _0224FEFC
	add r0, r4, #0
	bl MapObject_GetFacingDirection
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	cmp r6, r0
	beq _0224FEFC
	ldr r0, _0224FF00 ; =0x0000087C
	ldrb r0, [r5, r0]
	cmp r0, #2
	beq _0224FE9E
	cmp r0, #3
	bne _0224FEFC
_0224FE9E:
	add r0, r4, #0
	bl MapObject_GetFieldSystem
	ldr r1, _0224FF00 ; =0x0000087C
	add r6, r0, #0
	ldrb r1, [r5, r1]
	add r0, r4, #0
	add r2, sp, #8
	add r3, sp, #4
	bl ov02_0224FF04
	ldr r1, [sp, #8]
	ldr r2, [sp, #4]
	add r0, r6, #0
	bl GetMetatileBehavior
	add r5, r0, #0
	lsl r0, r5, #0x18
	lsr r0, r0, #0x18
	bl MetatileBehavior_IsTallGrass
	cmp r0, #1
	bne _0224FEE0
	mov r0, #1
	str r0, [sp]
	ldr r2, [sp, #8]
	ldr r3, [sp, #4]
	add r0, r4, #0
	mov r1, #0
	bl ov01_021FF0E4
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
_0224FEE0:
	lsl r0, r5, #0x18
	lsr r0, r0, #0x18
	bl MetatileBehavior_IsVeryTallGrass
	cmp r0, #1
	bne _0224FEFC
	mov r0, #1
	str r0, [sp]
	ldr r2, [sp, #8]
	ldr r3, [sp, #4]
	add r0, r4, #0
	mov r1, #0
	bl ov01_021FF964
_0224FEFC:
	add sp, #0xc
	pop {r3, r4, r5, r6, pc}
	.balign 4, 0
_0224FF00: .word 0x0000087C
	thumb_func_end ov02_0224FE70

	thumb_func_start ov02_0224FF04
ov02_0224FF04: ; 0x0224FF04
	push {r3, r4, r5, r6, r7, lr}
	add r7, r0, #0
	add r4, r2, #0
	add r6, r1, #0
	add r5, r3, #0
	bl MapObject_GetXCoord
	str r0, [r4]
	add r0, r7, #0
	bl MapObject_GetZCoord
	str r0, [r5]
	cmp r6, #3
	bhi _0224FF54
	add r0, r6, r6
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_0224FF2C: ; jump table
	.short _0224FF34 - _0224FF2C - 2 ; case 0
	.short _0224FF3C - _0224FF2C - 2 ; case 1
	.short _0224FF44 - _0224FF2C - 2 ; case 2
	.short _0224FF4C - _0224FF2C - 2 ; case 3
_0224FF34:
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	pop {r3, r4, r5, r6, r7, pc}
_0224FF3C:
	ldr r0, [r5]
	sub r0, r0, #1
	str r0, [r5]
	pop {r3, r4, r5, r6, r7, pc}
_0224FF44:
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	pop {r3, r4, r5, r6, r7, pc}
_0224FF4C:
	ldr r0, [r4]
	sub r0, r0, #1
	str r0, [r4]
	pop {r3, r4, r5, r6, r7, pc}
_0224FF54:
	bl GF_AssertFail
	pop {r3, r4, r5, r6, r7, pc}
	.balign 4, 0
	thumb_func_end ov02_0224FF04

	thumb_func_start ov02_0224FF5C
ov02_0224FF5C: ; 0x0224FF5C
	push {r4, r5, r6, lr}
	ldr r3, _0224FFCC ; =0x00000818
	add r5, r0, #0
	add r2, r3, #0
	add r2, #0x53
	ldrb r2, [r5, r2]
	add r0, r5, r3
	add r3, #0x52
	lsl r2, r2, #3
	add r4, r0, r2
	ldrb r0, [r5, r3]
	add r6, r1, #0
	cmp r0, #0
	bne _0224FFA8
	add r0, r4, #0
	bl ov02_0224FD9C
	ldr r3, _0224FFD0 ; =0x0000086C
	add r0, r4, #0
	ldrb r1, [r5, r3]
	lsl r1, r1, #0x1c
	lsr r1, r1, #0x19
	add r2, r5, r1
	add r1, r3, #0
	sub r1, #0x84
	ldrh r1, [r2, r1]
	add r2, r3, #0
	add r2, #0x12
	add r3, #0x11
	ldrh r2, [r5, r2]
	ldrb r3, [r5, r3]
	bl ov02_0224FDF8
	add r0, r5, #0
	add r1, r4, #0
	add r2, r6, #0
	bl ov02_0224FE40
_0224FFA8:
	ldr r1, _0224FFD4 ; =0x0000086A
	ldrb r0, [r5, r1]
	add r0, r0, #1
	strb r0, [r5, r1]
	ldrb r2, [r5, r1]
	ldrb r0, [r4, #1]
	cmp r2, r0
	blo _0224FFC6
	add r0, r1, #1
	ldrb r0, [r5, r0]
	add r2, r0, #1
	add r0, r1, #1
	strb r2, [r5, r0]
	mov r0, #1
	pop {r4, r5, r6, pc}
_0224FFC6:
	mov r0, #0
	pop {r4, r5, r6, pc}
	nop
_0224FFCC: .word 0x00000818
_0224FFD0: .word 0x0000086C
_0224FFD4: .word 0x0000086A
	thumb_func_end ov02_0224FF5C

	thumb_func_start ov02_0224FFD8
ov02_0224FFD8: ; 0x0224FFD8
	ldr r2, _02250000 ; =0x0000086B
	ldrb r1, [r0, r2]
	cmp r1, #0xa
	blo _0224FFE4
	mov r0, #0
	bx lr
_0224FFE4:
	lsl r1, r1, #3
	add r3, r0, r1
	add r1, r2, #0
	sub r1, #0x53
	ldrb r1, [r3, r1]
	cmp r1, #0xff
	bne _0224FFF6
	mov r0, #0
	bx lr
_0224FFF6:
	mov r3, #0
	sub r1, r2, #1
	strb r3, [r0, r1]
	mov r0, #1
	bx lr
	.balign 4, 0
_02250000: .word 0x0000086B
	thumb_func_end ov02_0224FFD8

	thumb_func_start ov02_02250004
ov02_02250004: ; 0x02250004
	push {r4, r5, r6, lr}
	add r5, r0, #0
	add r4, r1, #0
	cmp r2, #0
	bne _02250016
	bl GF_AssertFail
	mov r0, #1
	pop {r4, r5, r6, pc}
_02250016:
	ldr r0, _02250108 ; =0x00000868
	ldrb r1, [r4, r0]
	cmp r1, #4
	bhi _02250102
	add r1, r1, r1
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_0225002A: ; jump table
	.short _02250034 - _0225002A - 2 ; case 0
	.short _02250040 - _0225002A - 2 ; case 1
	.short _02250082 - _0225002A - 2 ; case 2
	.short _02250098 - _0225002A - 2 ; case 3
	.short _022500AE - _0225002A - 2 ; case 4
_02250034:
	sub r0, #0x50
	add r0, r4, r0
	mov r1, #0xe0
	sub r2, r2, #1
	bl ReadWholeNarcMemberByIdPair
_02250040:
	add r0, r5, #0
	add r0, #0xe4
	mov r1, #0x87
	lsl r1, r1, #4
	ldr r0, [r0]
	add r1, r4, r1
	bl MapObject_CopyPositionVector
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	bl MapObject_GetFacingDirection
	ldr r1, _0225010C ; =0x0000087C
	strb r0, [r4, r1]
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	mov r1, #0
	bl ov01_021F8F68
	add r5, #0xe4
	ldr r0, [r5]
	mov r1, #1
	bl ov01_021F8F08
	ldr r0, _02250108 ; =0x00000868
	mov r1, #2
	strb r1, [r4, r0]
	mov r1, #0
	add r0, r0, #3
	strb r1, [r4, r0]
	b _02250102
_02250082:
	add r0, r4, #0
	bl ov02_0224FFD8
	cmp r0, #0
	ldr r0, _02250108 ; =0x00000868
	bne _02250094
	mov r1, #4
	strb r1, [r4, r0]
	b _02250102
_02250094:
	mov r1, #3
	strb r1, [r4, r0]
_02250098:
	add r5, #0xe4
	ldr r1, [r5]
	add r0, r4, #0
	bl ov02_0224FF5C
	cmp r0, #0
	beq _02250102
	ldr r0, _02250108 ; =0x00000868
	mov r1, #2
	strb r1, [r4, r0]
	b _02250102
_022500AE:
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	bl MapObject_GetFacingDirection
	lsl r0, r0, #0x18
	lsr r6, r0, #0x18
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	mov r1, #0
	bl ov01_021F8F68
	add r0, r5, #0
	add r0, #0xe4
	ldr r0, [r0]
	mov r1, #0
	bl ov01_021F8F08
	add r0, r5, #0
	add r0, #0xe4
	mov r1, #0x87
	lsl r1, r1, #4
	ldr r0, [r0]
	add r1, r4, r1
	bl MapObject_SetPositionVector
	ldr r1, _0225010C ; =0x0000087C
	add r0, r5, #0
	add r0, #0xe4
	ldrb r1, [r4, r1]
	ldr r0, [r0]
	bl MapObject_SetFacingDirectionDirect
	add r5, #0xe4
	ldr r1, [r5]
	add r0, r4, #0
	add r2, r6, #0
	bl ov02_0224FE70
	mov r0, #1
	pop {r4, r5, r6, pc}
_02250102:
	mov r0, #0
	pop {r4, r5, r6, pc}
	nop
_02250108: .word 0x00000868
_0225010C: .word 0x0000087C
	thumb_func_end ov02_02250004

	thumb_func_start Task_FollowMonInteract
Task_FollowMonInteract: ; 0x02250110
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	bl TaskManager_GetFieldSystem
	add r4, r0, #0
	add r0, r5, #0
	bl TaskManager_GetStatePtr
	add r6, r0, #0
	ldr r0, [r6]
	cmp r0, #5
	bls _0225012A
	b _0225047E
_0225012A:
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_02250136: ; jump table
	.short _02250142 - _02250136 - 2 ; case 0
	.short _0225015C - _02250136 - 2 ; case 1
	.short _022501A2 - _02250136 - 2 ; case 2
	.short _02250314 - _02250136 - 2 ; case 3
	.short _02250378 - _02250136 - 2 ; case 4
	.short _02250418 - _02250136 - 2 ; case 5
_02250142:
	add r0, r4, #0
	bl ov02_0224EF94
	add r1, r0, #0
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl ov02_0224F880
	ldr r0, [r6]
	add r0, r0, #1
	str r0, [r6]
	b _0225047E
_0225015C:
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	add r0, r4, #0
	bl ov02_0224F8FC
	cmp r0, #1
	bne _02250178
	add r4, #0xe4
	ldr r0, [r4]
	bl MapObject_PauseMovement
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_02250178:
	cmp r0, #2
	bne _0225018E
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250484 ; =0x00000869
	mov r2, #0xa
	strb r2, [r1, r0]
	mov r0, #2
	str r0, [r6]
	b _0225047E
_0225018E:
	cmp r0, #3
	bne _02250198
	mov r0, #3
	str r0, [r6]
	b _0225047E
_02250198:
	cmp r0, #4
	bne _02250270
	mov r0, #4
	str r0, [r6]
	b _0225047E
_022501A2:
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250484 ; =0x00000869
	ldrb r0, [r1, r0]
	sub r0, #0xa
	cmp r0, #3
	bhi _02250270
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_022501BE: ; jump table
	.short _022501C6 - _022501BE - 2 ; case 0
	.short _022501DE - _022501BE - 2 ; case 1
	.short _02250218 - _022501BE - 2 ; case 2
	.short _02250246 - _022501BE - 2 ; case 3
_022501C6:
	add r0, r4, #0
	mov r1, #3
	mov r2, #0
	bl ov01_021F6A9C
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250484 ; =0x00000869
	mov r2, #0xb
	strb r2, [r1, r0]
	b _0225047E
_022501DE:
	add r0, r4, #0
	bl ov01_021F6B00
	add r5, r0, #0
	add r0, r4, #0
	bl ov01_021F6B10
	cmp r5, #3
	bne _02250270
	cmp r0, #1
	bne _02250270
	mov r3, #0x12
	lsl r3, r3, #4
	ldr r5, [r4, r3]
	mov r3, #0x22
	mov r1, #3
	lsl r3, r3, #6
	add r0, r4, #0
	add r2, r1, #0
	add r3, r5, r3
	bl ov01_021F6ABC
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250484 ; =0x00000869
	mov r2, #0xc
	strb r2, [r1, r0]
	b _0225047E
_02250218:
	add r0, r4, #0
	bl ov01_021F6B00
	add r5, r0, #0
	add r0, r4, #0
	bl ov01_021F6AEC
	cmp r5, #3
	bne _02250270
	cmp r0, #6
	bne _02250270
	mov r1, #0
	add r0, r4, #0
	add r2, r1, #0
	bl ov01_021F6A9C
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250484 ; =0x00000869
	mov r2, #0xd
	strb r2, [r1, r0]
	b _0225047E
_02250246:
	add r0, r4, #0
	bl ov01_021F6B00
	add r5, r0, #0
	add r0, r4, #0
	bl ov01_021F6B10
	cmp r5, #0
	bne _02250270
	cmp r0, #1
	bne _02250270
	mov r0, #0x12
	lsl r0, r0, #4
	mov r1, #0x22
	ldr r0, [r4, r0]
	lsl r1, r1, #6
	ldrh r1, [r0, r1]
	cmp r1, #0
	beq _02250272
	cmp r1, #1
	beq _022502C4
_02250270:
	b _0225047E
_02250272:
	mov r1, #0
	bl ClearFrameAndWindow2
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl RemoveWindow
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	ldr r0, [r0, #0x10]
	bl String_Delete
	add r0, r4, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	bic r1, r0
	add r0, r4, #0
	add r0, #0xd2
	strb r1, [r0]
	mov r0, #0x12
	lsl r0, r0, #4
	mov r1, #0x81
	ldr r0, [r4, r0]
	lsl r1, r1, #4
	ldrh r1, [r0, r1]
	cmp r1, #0
	bne _022502BA
	add r4, #0xe4
	ldr r0, [r4]
	bl MapObject_PauseMovement
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_022502BA:
	bl ov02_0224F880
	mov r0, #1
	str r0, [r6]
	b _0225047E
_022502C4:
	mov r1, #0
	bl ClearFrameAndWindow2
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl RemoveWindow
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	ldr r0, [r0, #0x10]
	bl String_Delete
	add r0, r4, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	bic r1, r0
	add r0, r4, #0
	add r0, #0xd2
	strb r1, [r0]
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	ldr r1, _02250488 ; =0x00000812
	ldrh r1, [r0, r1]
	cmp r1, #0
	bne _0225030A
	add r4, #0xe4
	ldr r0, [r4]
	bl MapObject_PauseMovement
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0225030A:
	bl ov02_0224F880
	mov r0, #1
	str r0, [r6]
	b _0225047E
_02250314:
	ldr r0, [r4, #0xc]
	bl Save_FashionData_Get
	bl Save_FashionData_GetFashionCase
	add r7, r0, #0
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _0225048C ; =0x00000816
	ldrb r0, [r1, r0]
	sub r5, r0, #1
	bmi _02250332
	cmp r5, #0x64
	blt _02250336
_02250332:
	bl GF_AssertFail
_02250336:
	add r0, r7, #0
	add r1, r5, #0
	mov r2, #1
	bl sub_0202BA2C
	cmp r0, #0
	beq _02250364
	add r0, r7, #0
	add r1, r5, #0
	mov r2, #1
	bl FashionCase_GiveFashionItem
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	add r0, r4, #0
	mov r2, #3
	bl ov02_0224FC08
	ldr r0, _02250490 ; =SEQ_ME_ACCE
	bl PlayFanfare
	b _02250372
_02250364:
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	add r0, r4, #0
	mov r2, #2
	bl ov02_0224FC08
_02250372:
	mov r0, #5
	str r0, [r6]
	b _0225047E
_02250378:
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250494 ; =0x00000817
	ldrb r0, [r1, r0]
	cmp r0, #5
	bhi _022503B2
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_02250392: ; jump table
	.short _022503B2 - _02250392 - 2 ; case 0
	.short _0225039E - _02250392 - 2 ; case 1
	.short _022503A2 - _02250392 - 2 ; case 2
	.short _022503A6 - _02250392 - 2 ; case 3
	.short _022503AA - _02250392 - 2 ; case 4
	.short _022503AE - _02250392 - 2 ; case 5
_0225039E:
	mov r5, #MON_DATA_SHINY_LEAF_A
	b _022503BA
_022503A2:
	mov r5, #MON_DATA_SHINY_LEAF_B
	b _022503BA
_022503A6:
	mov r5, #MON_DATA_SHINY_LEAF_C
	b _022503BA
_022503AA:
	mov r5, #MON_DATA_SHINY_LEAF_D
	b _022503BA
_022503AE:
	mov r5, #MON_DATA_SHINY_LEAF_E
	b _022503BA
_022503B2:
	bl GF_AssertFail
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_022503BA:
	ldr r0, [r4, #0xc]
	bl SaveArray_Party_Get
	bl GetFirstAliveMonInParty_CrashIfNone
	add r1, r5, #0
	mov r2, #0
	add r7, r0, #0
	bl GetMonData
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	bne _02250404
	ldr r0, [r4, #0xc]
	bl Save_VarsFlags_Get
	bl SetFlag99C
	mov r1, #1
	add r0, sp, #0
	strb r1, [r0]
	add r0, r7, #0
	add r1, r5, #0
	add r2, sp, #0
	bl SetMonData
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	add r0, r4, #0
	mov r2, #1
	bl ov02_0224FC08
	ldr r0, _02250490 ; =SEQ_ME_ACCE
	bl PlayFanfare
	b _02250412
_02250404:
	mov r1, #0x12
	lsl r1, r1, #4
	ldr r1, [r4, r1]
	add r0, r4, #0
	mov r2, #0
	bl ov02_0224FC08
_02250412:
	mov r0, #5
	str r0, [r6]
	b _0225047E
_02250418:
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r1, [r4, r0]
	ldr r0, _02250498 ; =0x0000086E
	ldrh r0, [r1, r0]
	lsl r0, r0, #0x18
	lsr r0, r0, #0x18
	bl DialogBox_IsPrintFinished
	cmp r0, #1
	bne _0225047E
	bl IsFanfarePlaying
	cmp r0, #0
	bne _0225047E
	ldr r0, _0225049C ; =gSystem
	ldr r1, [r0, #0x48]
	mov r0, #3
	tst r0, r1
	beq _0225047E
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	mov r1, #0
	bl ClearFrameAndWindow2
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	bl RemoveWindow
	mov r0, #0x12
	lsl r0, r0, #4
	ldr r0, [r4, r0]
	ldr r0, [r0, #0x10]
	bl String_Delete
	add r0, r4, #0
	add r0, #0xd2
	ldrb r1, [r0]
	mov r0, #0x40
	bic r1, r0
	add r0, r4, #0
	add r0, #0xd2
	add r4, #0xe4
	strb r1, [r0]
	ldr r0, [r4]
	bl MapObject_PauseMovement
	mov r0, #1
	pop {r3, r4, r5, r6, r7, pc}
_0225047E:
	mov r0, #0
	pop {r3, r4, r5, r6, r7, pc}
	nop
_02250484: .word 0x00000869
_02250488: .word 0x00000812
_0225048C: .word 0x00000816
_02250490: .word SEQ_ME_ACCE
_02250494: .word 0x00000817
_02250498: .word 0x0000086E
_0225049C: .word gSystem
	thumb_func_end Task_FollowMonInteract

	thumb_func_start FollowMon_PlaceholdersSet
FollowMon_PlaceholdersSet: ; 0x022504A0
	push {r3, r4, r5, r6, r7, lr}
	add r5, r0, #0
	ldr r0, [r5, #0xc]
	add r4, r1, #0
	bl SaveArray_Party_Get
	bl GetFirstAliveMonInParty_CrashIfNone
	add r6, r0, #0
	bl Mon_GetBoxMon
	add r7, r0, #0
	add r0, r4, #0
	mov r1, #0
	add r2, r7, #0
	bl BufferBoxMonNickname
	add r0, r4, #0
	mov r1, #1
	add r2, r7, #0
	bl BufferBoxMonSpeciesName
	ldr r0, [r5, #0xc]
	bl Save_PlayerData_GetProfile
	add r2, r0, #0
	add r0, r4, #0
	mov r1, #2
	bl BufferPlayersName
	ldr r0, [r5, #0x20]
	ldr r0, [r0]
	bl MapHeader_GetMapSec
	add r2, r0, #0
	add r0, r4, #0
	mov r1, #3
	bl BufferLocationName
	add r0, r6, #0
	mov r1, #6
	mov r2, #0
	bl GetMonData
	add r2, r0, #0
	add r0, r4, #0
	mov r1, #4
	bl BufferItemName
	pop {r3, r4, r5, r6, r7, pc}
	thumb_func_end FollowMon_PlaceholdersSet

	thumb_func_start ov02_02250504
ov02_02250504: ; 0x02250504
	push {r3, r4, r5, lr}
	add r5, r0, #0
	ldr r0, [r5, #0xc]
	bl SaveArray_Party_Get
	bl GetFirstAliveMonInParty_CrashIfNone
	add r4, r0, #0
	mov r0, #0x42
	lsl r0, r0, #2
	ldr r0, [r5, r0]
	bl FieldSystem_UnkSub108_GetMonMood
	mov r1, #0x12
	str r0, [sp]
	lsl r1, r1, #4
	ldr r2, [r5, r1]
	ldr r1, _0225058C ; =0x00000815
	ldrsb r1, [r2, r1]
	add r1, r0, r1
	str r1, [sp]
	cmp r1, #0x7f
	ble _02250538
	mov r0, #0x7f
	str r0, [sp]
	b _02250542
_02250538:
	mov r0, #0x7e
	mvn r0, r0
	cmp r1, r0
	bge _02250542
	str r0, [sp]
_02250542:
	mov r0, #0x42
	ldr r1, [sp]
	lsl r0, r0, #2
	lsl r1, r1, #0x18
	ldr r0, [r5, r0]
	asr r1, r1, #0x18
	bl FieldSystem_UnkSub108_SetMonMood
	add r0, r4, #0
	mov r1, #9
	mov r2, #0
	bl GetMonData
	mov r1, #0x12
	str r0, [sp]
	lsl r1, r1, #4
	ldr r2, [r5, r1]
	ldr r1, _02250590 ; =0x00000814
	ldrsb r1, [r2, r1]
	add r0, r0, r1
	str r0, [sp]
	cmp r0, #0xff
	ble _02250576
	mov r0, #0xff
	str r0, [sp]
	b _0225057E
_02250576:
	cmp r0, #0
	bge _0225057E
	mov r0, #0
	str r0, [sp]
_0225057E:
	add r0, r4, #0
	mov r1, #9
	add r2, sp, #0
	bl SetMonData
	pop {r3, r4, r5, pc}
	nop
_0225058C: .word 0x00000815
_02250590: .word 0x00000814
	thumb_func_end ov02_02250504

	thumb_func_start ov02_02250594
ov02_02250594: ; 0x02250594
	cmp r0, #0xa
	bhi _02250622
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_022505A4: ; jump table
	.short _02250622 - _022505A4 - 2 ; case 0
	.short _022505BA - _022505A4 - 2 ; case 1
	.short _022505C2 - _022505A4 - 2 ; case 2
	.short _022505CE - _022505A4 - 2 ; case 3
	.short _022505DA - _022505A4 - 2 ; case 4
	.short _022505E6 - _022505A4 - 2 ; case 5
	.short _022505F2 - _022505A4 - 2 ; case 6
	.short _022505FE - _022505A4 - 2 ; case 7
	.short _0225060A - _022505A4 - 2 ; case 8
	.short _02250612 - _022505A4 - 2 ; case 9
	.short _0225061A - _022505A4 - 2 ; case 10
_022505BA:
	cmp r1, #0xff
	bne _02250622
	mov r0, #1
	bx lr
_022505C2:
	cmp r1, #0xc8
	blt _02250622
	cmp r1, #0xff
	bge _02250622
	mov r0, #1
	bx lr
_022505CE:
	cmp r1, #0x96
	blt _02250622
	cmp r1, #0xc8
	bge _02250622
	mov r0, #1
	bx lr
_022505DA:
	cmp r1, #0x5a
	blt _02250622
	cmp r1, #0x96
	bge _02250622
	mov r0, #1
	bx lr
_022505E6:
	cmp r1, #0x3c
	blt _02250622
	cmp r1, #0x5a
	bge _02250622
	mov r0, #1
	bx lr
_022505F2:
	cmp r1, #0x1e
	blt _02250622
	cmp r1, #0x3c
	bge _02250622
	mov r0, #1
	bx lr
_022505FE:
	cmp r1, #1
	blt _02250622
	cmp r1, #0x1e
	bge _02250622
	mov r0, #1
	bx lr
_0225060A:
	cmp r1, #0
	bne _02250622
	mov r0, #1
	bx lr
_02250612:
	cmp r1, #0x5a
	blt _02250622
	mov r0, #1
	bx lr
_0225061A:
	cmp r1, #0x3c
	bge _02250622
	mov r0, #1
	bx lr
_02250622:
	mov r0, #0
	bx lr
	.balign 4, 0
	thumb_func_end ov02_02250594

	thumb_func_start ov02_02250628
ov02_02250628: ; 0x02250628
	cmp r0, #0xa
	bhi _022506CE
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_02250638: ; jump table
	.short _022506CE - _02250638 - 2 ; case 0
	.short _0225064E - _02250638 - 2 ; case 1
	.short _02250656 - _02250638 - 2 ; case 2
	.short _02250662 - _02250638 - 2 ; case 3
	.short _0225066E - _02250638 - 2 ; case 4
	.short _0225067A - _02250638 - 2 ; case 5
	.short _0225068A - _02250638 - 2 ; case 6
	.short _0225069C - _02250638 - 2 ; case 7
	.short _022506AE - _02250638 - 2 ; case 8
	.short _022506BA - _02250638 - 2 ; case 9
	.short _022506C2 - _02250638 - 2 ; case 10
_0225064E:
	cmp r1, #0x7f
	bne _022506CE
	mov r0, #1
	bx lr
_02250656:
	cmp r1, #0x64
	blt _022506CE
	cmp r1, #0x7f
	bge _022506CE
	mov r0, #1
	bx lr
_02250662:
	cmp r1, #0x32
	blt _022506CE
	cmp r1, #0x64
	bge _022506CE
	mov r0, #1
	bx lr
_0225066E:
	cmp r1, #0x1e
	blt _022506CE
	cmp r1, #0x32
	bge _022506CE
	mov r0, #1
	bx lr
_0225067A:
	mov r0, #0x1d
	mvn r0, r0
	cmp r1, r0
	ble _022506CE
	cmp r1, #0x1e
	bge _022506CE
	mov r0, #1
	bx lr
_0225068A:
	mov r0, #0x31
	mvn r0, r0
	cmp r1, r0
	ble _022506CE
	add r0, #0x14
	cmp r1, r0
	bgt _022506CE
	mov r0, #1
	bx lr
_0225069C:
	mov r0, #0x7e
	mvn r0, r0
	cmp r1, r0
	ble _022506CE
	add r0, #0x4d
	cmp r1, r0
	bgt _022506CE
	mov r0, #1
	bx lr
_022506AE:
	mov r0, #0x7e
	mvn r0, r0
	cmp r1, r0
	bne _022506CE
	mov r0, #1
	bx lr
_022506BA:
	cmp r1, #0
	blt _022506CE
	mov r0, #1
	bx lr
_022506C2:
	mov r0, #0
	mvn r0, r0
	cmp r1, r0
	bgt _022506CE
	mov r0, #1
	bx lr
_022506CE:
	mov r0, #0
	bx lr
	.balign 4, 0
	thumb_func_end ov02_02250628

	thumb_func_start ov02_022506D4
ov02_022506D4: ; 0x022506D4
	push {r3, lr}
	cmp r0, #0xf9
	bhi _022506E2
	cmp r0, r1
	bne _02250732
	mov r0, #1
	pop {r3, pc}
_022506E2:
	sub r0, #0xfa
	cmp r0, #4
	bhi _0225072A
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_022506F4: ; jump table
	.short _022506FE - _022506F4 - 2 ; case 0
	.short _02250706 - _022506F4 - 2 ; case 1
	.short _0225070E - _022506F4 - 2 ; case 2
	.short _0225071A - _022506F4 - 2 ; case 3
	.short _02250722 - _022506F4 - 2 ; case 4
_022506FE:
	cmp r1, #0x13
	bhi _02250732
	mov r0, #1
	pop {r3, pc}
_02250706:
	cmp r1, #0x82
	bhi _02250732
	mov r0, #1
	pop {r3, pc}
_0225070E:
	cmp r1, #0x8c
	blo _02250732
	cmp r1, #0x95
	bhi _02250732
	mov r0, #1
	pop {r3, pc}
_0225071A:
	cmp r1, #0xa0
	blo _02250732
	mov r0, #1
	pop {r3, pc}
_02250722:
	cmp r1, #0xdc
	blo _02250732
	mov r0, #1
	pop {r3, pc}
_0225072A:
	bl GF_AssertFail
	mov r0, #0
	pop {r3, pc}
_02250732:
	mov r0, #0
	pop {r3, pc}
	.balign 4, 0
	thumb_func_end ov02_022506D4

	thumb_func_start ov02_02250738
ov02_02250738: ; 0x02250738
	push {r4, r5}
	sub sp, #8
	ldr r4, _0225077C ; =ov02_02253A54
	add r2, sp, #0
	ldrb r5, [r4]
	add r3, sp, #0
	add r0, r2, r0
	strb r5, [r3]
	ldrb r5, [r4, #1]
	sub r0, r0, #1
	strb r5, [r3, #1]
	ldrb r5, [r4, #2]
	strb r5, [r3, #2]
	ldrb r5, [r4, #3]
	ldrb r4, [r4, #4]
	strb r5, [r3, #3]
	strb r4, [r3, #4]
	ldrb r0, [r0]
	mov r3, #0
	and r0, r1
_02250760:
	cmp r0, #0
	bne _0225076C
	add sp, #8
	mov r0, #1
	pop {r4, r5}
	bx lr
_0225076C:
	add r3, r3, #1
	cmp r3, #5
	blt _02250760
	mov r0, #0
	add sp, #8
	pop {r4, r5}
	bx lr
	nop
_0225077C: .word ov02_02253A54
	thumb_func_end ov02_02250738

	thumb_func_start ov02_02250780
ov02_02250780: ; 0x02250780
	push {r4, r5, r6, lr}
	ldr r0, [r0, #0xc]
	add r5, r1, #0
	bl SaveArray_Party_Get
	bl GetFirstAliveMonInParty_CrashIfNone
	add r6, r0, #0
	mov r1, #0xb1
	mov r2, #0
	bl GetMonData
	add r4, r0, #0
	add r0, r6, #0
	mov r1, #0xb2
	mov r2, #0
	bl GetMonData
	cmp r4, r5
	beq _022507AC
	cmp r0, r5
	bne _022507B0
_022507AC:
	mov r0, #1
	pop {r4, r5, r6, pc}
_022507B0:
	mov r0, #0
	pop {r4, r5, r6, pc}
	thumb_func_end ov02_02250780

	thumb_func_start ov02_022507B4
ov02_022507B4: ; 0x022507B4
	push {r3, r4, r5, lr}
	add r5, r0, #0
	add r0, #0xe4
	ldr r0, [r0]
	add r4, r1, #0
	bl FollowMon_GetSpecies
	sub r0, #0x32
	cmp r0, #1
	bls _022507E0
	mov r0, #0xb
	mov r1, #8
	bl Heap_AllocAtEnd
	add r2, r0, #0
	strh r4, [r2]
	mov r0, #0
	strh r0, [r2, #2]
	ldr r0, [r5, #0x10]
	ldr r1, _022507E4 ; =ov02_022507E8
	bl TaskManager_Call
_022507E0:
	pop {r3, r4, r5, pc}
	nop
_022507E4: .word ov02_022507E8
	thumb_func_end ov02_022507B4

	thumb_func_start ov02_022507E8
ov02_022507E8: ; 0x022507E8
	push {r4, r5, r6, lr}
	add r4, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r4, #0
	bl TaskManager_GetEnvironment
	add r5, r0, #0
	add r0, r4, #0
	bl TaskManager_GetStatePtr
	add r4, r0, #0
	ldr r0, [r4]
	cmp r0, #4
	bhi _022508AA
	add r0, r0, r0
	add r0, pc
	ldrh r0, [r0, #6]
	lsl r0, r0, #0x10
	asr r0, r0, #0x10
	add pc, r0
_02250814: ; jump table
	.short _0225081E - _02250814 - 2 ; case 0
	.short _0225082E - _02250814 - 2 ; case 1
	.short _0225084C - _02250814 - 2 ; case 2
	.short _02250874 - _02250814 - 2 ; case 3
	.short _022508A0 - _02250814 - 2 ; case 4
_0225081E:
	add r0, r6, #0
	add r0, #0xe4
	ldr r0, [r0]
	bl MapObject_UnpauseMovement
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
_0225082E:
	add r0, r6, #0
	bl FollowMon_GetMapObject
	bl MapObject_AreBitsSetForMovementScriptInit
	cmp r0, #0
	beq _022508AA
	add r6, #0xe4
	ldr r0, [r6]
	bl MapObject_PauseMovement
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _022508AA
_0225084C:
	add r0, r6, #0
	add r0, #0xe4
	ldr r0, [r0]
	bl MapObject_GetFacingDirection
	lsl r0, r0, #0x18
	lsr r1, r0, #0x18
	add r6, #0xe4
	mov r2, #0x14
	ldr r3, _022508B0 ; =ov02_02253A70
	mul r2, r1
	ldr r0, [r6]
	add r1, r3, r2
	bl EventObjectMovementMan_Create
	str r0, [r5, #4]
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _022508AA
_02250874:
	ldr r0, [r5, #4]
	bl EventObjectMovementMan_IsFinish
	cmp r0, #1
	bne _022508AA
	ldr r0, [r5, #4]
	bl EventObjectMovementMan_Delete
	ldrh r0, [r5, #2]
	add r0, r0, #1
	strh r0, [r5, #2]
	ldrh r1, [r5, #2]
	ldrh r0, [r5]
	cmp r1, r0
	blo _0225089A
	ldr r0, [r4]
	add r0, r0, #1
	str r0, [r4]
	b _022508AA
_0225089A:
	mov r0, #0
	str r0, [r4]
	b _022508AA
_022508A0:
	add r0, r5, #0
	bl Heap_Free
	mov r0, #1
	pop {r4, r5, r6, pc}
_022508AA:
	mov r0, #0
	pop {r4, r5, r6, pc}
	nop
_022508B0: .word ov02_02253A70
	thumb_func_end ov02_022507E8

	thumb_func_start ov02_022508B4
ov02_022508B4: ; 0x022508B4
	push {r4, lr}
	add r4, r0, #0
	mov r0, #0xb
	mov r1, #4
	bl Heap_AllocAtEnd
	add r2, r0, #0
	mov r0, #0
	strh r0, [r2]
	strh r0, [r2, #2]
	ldr r0, [r4, #0x10]
	ldr r1, _022508D4 ; =ov02_022508D8
	bl TaskManager_Call
	mov r0, #1
	pop {r4, pc}
	.balign 4, 0
_022508D4: .word ov02_022508D8
	thumb_func_end ov02_022508B4

	thumb_func_start ov02_022508D8
ov02_022508D8: ; 0x022508D8
	push {r4, r5, r6, lr}
	sub sp, #0x18
	add r4, r0, #0
	bl TaskManager_GetFieldSystem
	add r6, r0, #0
	add r0, r4, #0
	bl TaskManager_GetStatePtr
	add r5, r0, #0
	add r0, r4, #0
	bl TaskManager_GetEnvironment
	ldr r1, [r5]
	add r4, r0, #0
	cmp r1, #3
	bls _022508FC
	b _02250A44
_022508FC:
	add r1, r1, r1
	add r1, pc
	ldrh r1, [r1, #6]
	lsl r1, r1, #0x10
	asr r1, r1, #0x10
	add pc, r1
_02250908: ; jump table
	.short _02250910 - _02250908 - 2 ; case 0
	.short _0225099A - _02250908 - 2 ; case 1
	.short _022509AE - _02250908 - 2 ; case 2
	.short _02250A3A - _02250908 - 2 ; case 3
_02250910:
	ldr r3, _02250A4C ; =ov02_02253B24
	add r2, sp, #0xc
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldrh r0, [r4, #2]
	add r0, r0, #1
	strh r0, [r4, #2]
	ldrh r0, [r4, #2]
	bl _dfltu
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A50 ; =0x40A00000
	mov r0, #0
	bl _dmul
	ldr r3, _02250A54 ; =0x40240000
	mov r2, #0
	bl _ddiv
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A58 ; =0x40B00000
	mov r0, #0
	bl _dadd
	bl _dfix
	str r0, [sp, #0xc]
	ldrh r0, [r4, #2]
	bl _dfltu
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A50 ; =0x40A00000
	mov r0, #0
	bl _dmul
	ldr r3, _02250A54 ; =0x40240000
	mov r2, #0
	bl _ddiv
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A58 ; =0x40B00000
	mov r0, #0
	bl _dadd
	bl _dfix
	str r0, [sp, #0x10]
	ldr r0, [r6, #0x3c]
	bl ov01_021F771C
	add r1, sp, #0xc
	bl sub_02023E78
	ldrh r0, [r4, #2]
	cmp r0, #0xa
	blo _02250A44
	mov r0, #0
	strh r0, [r4, #2]
	strh r0, [r4]
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	b _02250A44
_0225099A:
	ldrh r0, [r4]
	add r0, r0, #1
	strh r0, [r4]
	ldrh r0, [r4]
	cmp r0, #0xa
	blo _02250A44
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	b _02250A44
_022509AE:
	ldr r3, _02250A5C ; =ov02_02253B30
	add r2, sp, #0
	ldmia r3!, {r0, r1}
	stmia r2!, {r0, r1}
	ldr r0, [r3]
	str r0, [r2]
	ldrh r0, [r4, #2]
	add r0, r0, #1
	strh r0, [r4, #2]
	ldrh r1, [r4, #2]
	cmp r1, #0xa
	blo _022509CE
	ldr r0, [r5]
	add r0, r0, #1
	str r0, [r5]
	b _02250A2C
_022509CE:
	mov r0, #0xa
	sub r0, r0, r1
	bl _dflt
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A50 ; =0x40A00000
	mov r0, #0
	bl _dmul
	ldr r3, _02250A54 ; =0x40240000
	mov r2, #0
	bl _ddiv
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A58 ; =0x40B00000
	mov r0, #0
	bl _dadd
	bl _dfix
	str r0, [sp]
	ldrh r1, [r4, #2]
	mov r0, #0xa
	sub r0, r0, r1
	bl _dflt
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A50 ; =0x40A00000
	mov r0, #0
	bl _dmul
	ldr r3, _02250A54 ; =0x40240000
	mov r2, #0
	bl _ddiv
	add r3, r1, #0
	add r2, r0, #0
	ldr r1, _02250A58 ; =0x40B00000
	mov r0, #0
	bl _dadd
	bl _dfix
	str r0, [sp, #4]
_02250A2C:
	ldr r0, [r6, #0x3c]
	bl ov01_021F771C
	add r1, sp, #0
	bl sub_02023E78
	b _02250A44
_02250A3A:
	bl Heap_Free
	add sp, #0x18
	mov r0, #1
	pop {r4, r5, r6, pc}
_02250A44:
	mov r0, #0
	add sp, #0x18
	pop {r4, r5, r6, pc}
	nop
_02250A4C: .word ov02_02253B24
_02250A50: .word 0x40A00000
_02250A54: .word 0x40240000
_02250A58: .word 0x40B00000
_02250A5C: .word ov02_02253B30
	thumb_func_end ov02_022508D8

    .rodata

ov02_022532F8:
	.word ov02_02248E10

ov02_022532FC: ; 0x022532FC
	.byte 0x07, 0x00, 0x08, 0x00

ov02_02253300:
	.word ov02_0224AC28

ov02_02253304: ; 0x02253304
	.byte 0x11, 0x00, 0x14, 0x00, 0x17, 0x00

ov02_0225330A: ; 0x0225330A
	.byte 0x13, 0x00, 0x16, 0x00, 0x19, 0x00

ov02_02253310: ; 0x02253310
	.byte 0x12, 0x00, 0x15, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00

ov02_02253320: ; 0x02253320
	.word ov02_022532F8, ov02_022534D0, 0x01, 0x0F

ov02_02253330:
	.word ov02_0224ACE0, ov02_0224ADEC, 0x00, 0x06
	.byte 0x01, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00

ov02_02253348: ; 0x02253348
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x40, 0x05, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

ov02_02253354: ; 0x02253354
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x80, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_02253360: ; 0x02253360
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_0225336C: ; 0x0225336C
	.byte 0x00, 0x14, 0x00, 0x00
	.byte 0x00, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_02253378: ; 0x02253378
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

ov02_02253384: ; 0x02253384
	.byte 0x00, 0x80, 0x12, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_02253390: ; 0x02253390
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_0225339C: ; 0x0225339C
	.byte 0x00, 0x00, 0x08, 0x00
	.byte 0x00, 0xF0, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_022533A8: ; 0x022533A8
	.byte 0x00, 0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

ov02_022533B4: ; 0x022533B4
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_022533C0: ; 0x022533C0
	.word ov02_02253300
	.word ov02_02253330
	.word ov02_02253420

ov02_022533CC: ; 0x022533CC
	.byte 0x00, 0x20, 0x00, 0x00
	.byte 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_022533D8: ; 0x022533D8
	.byte 0x00, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x04, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

ov02_022533E4: ; 0x022533E4
	.byte 0x00, 0x80, 0x08, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_022533F0: ; 0x022533F0
	.byte 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_022533FC: ; 0x022533FC
	.byte 0x00, 0x00, 0x08, 0x00
	.byte 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_02253408: ; 0x02253408
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x06, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

ov02_02253414: ; 0x02253414
	.byte 0x00, 0x80, 0x12, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

ov02_02253420:
	.word ov02_0224AF70, ov02_0224B0E0, ov02_0224B158, ov02_0224B294

ov02_02253430: ; 0x02253430
	.byte 0x00, 0xC0, 0xFF, 0xFF, 0x00, 0xA0, 0xFF, 0xFF, 0x00, 0x90, 0xFF, 0xFF, 0x00, 0x80, 0xFF, 0xFF

ov02_02253440: ; 0x02253440
	.byte 0x08, 0x00, 0x00, 0x00
	.word ov02_0224B6D0
	.word sub_02068DD4
	.word ov02_0224B6E4
	.word sub_02068DD0

ov02_02253454: ; 0x02253454
	.byte 0x74, 0x00, 0x00, 0x00
	.word ov02_02248D98
	.word ov02_02248DE4
	.word ov02_02248DF0
	.word sub_02068DD0

ov02_02253468: ; 0x02253468
	.byte 0x24, 0x00, 0x00, 0x00
	.word ov02_0224AA80
	.word ov02_0224AAC8
	.word ov02_0224AAD4
	.word ov02_0224AB54

ov02_0225347C: ; 0x0225347C
	.byte 0x68, 0x00, 0x00, 0x00
	.word ov02_0224ABCC
	.word ov02_0224ABF8
	.word ov02_0224AC04
	.word ov02_0224AC24

ov02_02253490: ; 0x02253490
	.byte 0x0C, 0x00, 0x00, 0x00
	.word ov02_0224B7CC
	.word ov02_0224B804
	.word ov02_0224B808
	.word ov02_0224B87C

ov02_022534A4: ; 0x022534A4
	.byte 0x24, 0x00, 0x00, 0x00
	.word ov02_0224B350
	.word sub_02068DD4
	.word ov02_0224B3FC
	.word sub_02068DD0

ov02_022534B8: ; 0x022534B8
	.word ov02_0224B494
	.word ov02_0224B4AC
	.word ov02_0224B5F0
	.word ov02_0224B638
	.word ov02_0224B664
	.word ov02_0224B68C

ov02_022534D0:
	.word ov02_02248F88
	.word ov02_02249088
	.word ov02_022490BC
	.word ov02_022491A8
	.word ov02_022491CC
	.word ov02_02249290
	.word ov02_0224939C
	.word ov02_022493EC

ov02_022534F0: ; 0x022534F0
	.word ov02_022495D0
	.word ov02_02249A5C
	.word ov02_0224B938
	.word ov02_0224B964
	.word ov02_02249AD8
	.word ov02_02249AF0
	.word ov02_02249B80
	.word ov02_02249BA8
	.word ov02_02249C74
	.word ov02_02249CD8
	.word ov02_02249954
	.word ov02_0224997C

ov02_02253520: ; 0x02253520
	.byte 0x00, 0x40, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0xC0, 0xFE, 0xFF, 0x00, 0x80, 0xFE, 0xFF
	.byte 0x00, 0x60, 0xFE, 0xFF, 0x00, 0x40, 0xFE, 0xFF, 0x00, 0x40, 0xFE, 0xFF, 0x00, 0x40, 0xFE, 0xFF
	.byte 0x00, 0x60, 0xFE, 0xFF, 0x00, 0x80, 0xFE, 0xFF, 0x00, 0xA0, 0xFE, 0xFF, 0x00, 0xC0, 0xFE, 0xFF

ov02_02253550: ; 0x02253550
	.word ov02_022495B8
	.word ov02_022495E8
	.word ov02_02249658
	.word ov02_02249690
	.word ov02_022496D0
	.word ov02_02249754
	.word ov02_02249774
	.word ov02_022497C0
	.word ov02_02249838
	.word ov02_02249858
	.word ov02_022498BC
	.word ov02_02249940
	.word ov02_02249968
	.word ov02_0224997C

ov02_02253588: ; 0x02253588
	.word ov02_022495B8
	.word ov02_022499EC
	.word ov02_02249658
	.word ov02_02249690
	.word ov02_022496D0
	.word ov02_02249754
	.word ov02_02249774
	.word ov02_022497C0
	.word ov02_02249838
	.word ov02_02249858
	.word ov02_02249AC4
	.word ov02_02249AD8
	.word ov02_02249AF0
	.word ov02_02249B10
	.word ov02_02249B38
	.word ov02_02249B60
	.word ov02_02249BA8
	.word ov02_02249BD8
	.word ov02_02249C74
	.word ov02_02249CD8
	.word ov02_02249940
	.word ov02_02249968
	.word ov02_0224997C

ov02_022535E4: ; 0x022535E4
	.byte 0x00, 0xF0, 0x00, 0x00, 0x00, 0xF0, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0x04, 0x00, 0x00, 0x30, 0x04, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00
	.byte 0x00, 0xD0, 0x03, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x0F, 0x00, 0x00, 0x50, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x02, 0x00, 0x00, 0xE0, 0x04, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x80, 0x04, 0x00, 0x00, 0xB0, 0x05, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0D, 0x00
	.byte 0x00, 0x60, 0x05, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x80, 0x03, 0x00, 0x00, 0x40, 0x07, 0x00, 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0xF0, 0x05, 0x00, 0x00, 0xD0, 0x06, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0xF0, 0x09, 0x00, 0x00, 0x40, 0x06, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x00, 0xE0, 0x07, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0xC0, 0x08, 0x00, 0x00, 0xD0, 0x07, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0xD0, 0x0D, 0x00, 0x00, 0xC0, 0x07, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00

ov02_022536E8: ; 0x022536E8
	.byte 0x21, 0x00, 0x00, 0x00, 0x8A, 0x00, 0x00, 0x00

ov02_022536F0: ; 0x022536F0
	.word ov02_0224C234
	.word ov02_0224C2A8
	.word ov02_0224C2EC
	.word ov02_0224C338

ov02_02253700: ; 0x02253700
	.word ov02_0224C05C
	.word ov02_0224C0B0
	.word ov02_0224C14C
	.word ov02_0224C1B8

ov02_02253710: ; 0x02253710
	.word ov02_0224C87C
	.word ov02_0224C8D0
	.word ov02_0224C93C
	.word ov02_0224C9B8
	.word ov02_0224CA38

ov02_02253724: ; 0x02253724
	.word ov02_0224C4B4
	.word ov02_0224C4D8
	.word ov02_0224C71C
	.word ov02_0224C75C
	.word ov02_0224C7D4
	.word ov02_0224C840

ov02_0225373C: ; 0x0225373C
	.word ov02_0224C680
	.word ov02_0224C698
	.word ov02_0224C6DC
	.word ov02_0224C75C
	.word ov02_0224C7D4
	.word ov02_0224C840

ov02_02253754: ; 0x02253754
	.word ov02_0224C4B4
	.word ov02_0224C4D8
	.word ov02_0224C87C
	.word ov02_0224C8D0
	.word ov02_0224C93C
	.word ov02_0224C9B8
	.word ov02_0224CA38

ov02_02253770: ; 0x02253770
	.byte 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0xFE, 0x00, 0x00, 0x00

ov02_02253794: ; 0x02253794
	.byte 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
	.byte 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
	.byte 0x02, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

ov02_022537B8: ; 0x022537B8
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

ov02_022537DC: ; 0x022537DC
	.byte 0x01, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x01, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

ov02_02253820: ; 0x02253820
	.byte 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0xFE, 0x00, 0x00, 0x00

ov02_02253884: ; 0x02253884
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x04, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x05, 0x00, 0x01, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

ov02_022538EC: ; 0x022538EC
	.byte 0x10, 0x0F, 0x0E, 0x0B
	.byte 0x0C, 0x09, 0xB4, 0x00, 0x00, 0x00, 0x0E, 0x01, 0x5A, 0x00, 0x00, 0x00

ov02_022538FC: ; 0x022538FC
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word ov02_0224D310
	.word ov02_0224D3A4
	.word ov02_0224D3B4
	.word ov02_0224D3E8

ov02_02253914: ; 0x02253914
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word ov02_0224D5B4
	.word ov02_0224D648
	.word ov02_0224D658
	.word ov02_0224D670

ov02_0225392C: ; 0x0225392C
	.byte 0x00, 0x04, 0x00, 0x00, 0x14, 0x01, 0x00, 0x00
	.word ov02_0224DAA4
	.word ov02_0224DB8C
	.word ov02_0224DB9C
	.word ov02_0224DC58

ov02_02253944: ; 0x02253944
	.byte 0x00, 0x04, 0x00, 0x00, 0xCC, 0x01, 0x00, 0x00
	.word ov02_0224D43C
	.word ov02_0224D468
	.word ov02_0224D488
	.word ov02_0224D580

ov02_0225395C: ; 0x0225395C
	.byte 0x00, 0x04, 0x00, 0x00, 0x10, 0x0D, 0x00, 0x00
	.word ov02_0224D880
	.word ov02_0224D914
	.word ov02_0224D950
	.word ov02_0224D98C

ov02_02253974: ; 0x02253974
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word ov02_0224D1E4
	.word ov02_0224D278
	.word ov02_0224D288
	.word ov02_0224D2BC

ov02_0225398C: ; 0x0225398C
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word ov02_0224D358
	.word ov02_0224D3A4
	.word ov02_0224D3B4
	.word ov02_0224D3E8

ov02_022539A4: ; 0x022539A4
	.byte 0x00, 0x04, 0x00, 0x00, 0x14, 0x01, 0x00, 0x00
	.word ov02_0224D9C0
	.word ov02_0224DB8C
	.word ov02_0224DB9C
	.word ov02_0224DC58

ov02_022539BC: ; 0x022539BC
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word ov02_0224D22C
	.word ov02_0224D278
	.word ov02_0224D288
	.word ov02_0224D2BC

ov02_022539D4: ; 0x022539D4
	.byte 0x00, 0x04, 0x00, 0x00, 0x9C, 0x0E, 0x00, 0x00
	.word ov02_0224DCB0
	.word ov02_0224DD4C
	.word ov02_0224DD8C
	.word ov02_0224DDC8

ov02_022539EC: ; 0x022539EC
	.byte 0x00, 0x04, 0x00, 0x00, 0x9C, 0x0E, 0x00, 0x00
	.word ov02_0224DD38
	.word ov02_0224DD4C
	.word ov02_0224DD8C
	.word ov02_0224DDC8

ov02_02253A04: ; 0x02253A04
	.word ov02_0224D2F0
	.word ov02_0224D41C
	.word ov02_0224D41C
	.word ov02_0224D2F0
	.word ov02_0224DC8C
	.word ov02_0224DC8C

ov02_02253A1C: ; 0x02253A1C
	.word ov02_0224D2C8
	.word ov02_0224D3F4
	.word ov02_0224D408
	.word ov02_0224D2DC
	.word ov02_0224DC64
	.word ov02_0224DC78

ov02_02253A34: ; 0x02253A34
	.word ov02_0224D2F8
	.word ov02_0224D424
	.word ov02_0224D424
	.word ov02_0224D2F8
	.word ov02_0224DC94
	.word ov02_0224DC94

ov02_02253A4C: ; 0x02253A4C
	.byte 0xFF, 0x01, 0xFF, 0x01
	.byte 0x01, 0xFF, 0x00, 0x00

ov02_02253A54: ; 0x02253A54
	.byte 0x01, 0x02, 0x04, 0x08, 0x10, 0x00, 0x00, 0x00

ov02_02253A5C: ; 0x02253A5C
	.byte 0xB5, 0x00, 0x00, 0x00
	.byte 0xB6, 0x00, 0x00, 0x00, 0xB7, 0x00, 0x00, 0x00, 0xB8, 0x00, 0x00, 0x00, 0xB9, 0x00, 0x00, 0x00

ov02_02253A70: ; 0x02253A70
	.byte 0x49, 0x00, 0x01, 0x00, 0x30, 0x00, 0x01, 0x00, 0x3E, 0x00, 0x01, 0x00, 0x4A, 0x00, 0x01, 0x00
	.byte 0xFE, 0x00, 0x00, 0x00, 0x49, 0x00, 0x01, 0x00, 0x31, 0x00, 0x01, 0x00, 0x3E, 0x00, 0x01, 0x00
	.byte 0x4A, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00, 0x49, 0x00, 0x01, 0x00, 0x32, 0x00, 0x01, 0x00
	.byte 0x3E, 0x00, 0x01, 0x00, 0x4A, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00, 0x49, 0x00, 0x01, 0x00
	.byte 0x33, 0x00, 0x01, 0x00, 0x3E, 0x00, 0x01, 0x00, 0x4A, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

ov02_02253AC0: ; 0x02253AC0
	.byte 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00

ov02_02253B24: ; 0x02253B24
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00

ov02_02253B30: ; 0x02253B30
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00

	.data

ov02_02253D90: ; 0x02253D90
	.byte 0x00, 0xB8, 0xFF, 0xFF

ov02_02253D94: ; 0x02253D94
	.byte 0x00, 0xC0, 0x00, 0x00

ov02_02253D98: ; 0x02253D98
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0x48, 0x00, 0x00
	.byte 0x00, 0xC0, 0x00, 0x00, 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00
	.byte 0x00, 0xC0, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00

ov02_02253DD8: ; 0x02253DD8
	.byte 0x00, 0xB8, 0xFF, 0xFF

ov02_02253DDC: ; 0x02253DDC
	.byte 0x00, 0xC0, 0x00, 0x00

ov02_02253DE0: ; 0x02253DE0
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0x48, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0xB8, 0xFF, 0xFF
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00
	.byte 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00
	.byte 0x00, 0x48, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00
_02253E20:
